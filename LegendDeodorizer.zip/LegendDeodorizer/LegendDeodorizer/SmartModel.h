//
//  SmartModel.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/10.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SmartModel : NSObject
@property (copy,nonatomic) NSNumber *modeType;
@property (copy,nonatomic) NSArray *setList ;
@property (copy,nonatomic) NSString *threshold;
@property (copy,nonatomic) NSString *week ;
@end
