



//
//  GrouppageController.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/28.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "GrouppageController.h"
#import "GroupCell.h"
#import "DeviceDetailController.h"
#import "DeviceControlController.h"
#import "DeviceManage.h"
#import "UINavigationController+FDFullscreenPopGesture.h"
#import "MainDevice.h"
#import "MJRefresh.h"

static const NSInteger backTag           =5;//右侧按钮tag

@interface GrouppageController (){

    UITableView *mainTableView;
    NSMutableArray *devicelistByGroupArr;
}

@end

@implementation GrouppageController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    [self getDeviceListByGroup];
    self.fd_prefersNavigationBarHidden = YES;
    self.view.backgroundColor = WHITECOLOR;
    AppDelegate *app =(AppDelegate *)[UIApplication sharedApplication].delegate;
    app.root.tabBar.hidden = YES;
    app.root.button.hidden = YES;
    
    [self addNaviView];
    [self addTableView];
    [self.view addSubview:self.notingView];
    
    //修改了分组列表
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(getDeviceListByGroup)
                                                 name:@"RefreshGroupList" object:nil];
    
//    if ([self.tableView respondsToSelector:@selector(setSeparatorInset:)]) {
//        [self.tableView setSeparatorInset:UIEdgeInsetsMake(0, 80 *NewBasicHeight, 0, 0)];
//    }
    
//    if ([self.tableView respondsToSelector:@selector(setLayoutMargins:)]) {
//        [self.tableView setLayoutMargins:UIEdgeInsetsZero];
//    }
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSData *_dData = [[NSUserDefaults standardUserDefaults] objectForKey:@"devicelistByGroupArr"];
    
    NSMutableArray *_cArr = [NSKeyedUnarchiver unarchiveObjectWithData:_dData];
    if(_cArr.count>0){
        devicelistByGroupArr = [_cArr mutableCopy];
    }

    [mainTableView reloadData];
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark ===================action===================
-(void)getDeviceListByGroup{
    devicelistByGroupArr = [[NSMutableArray alloc]initWithCapacity:8];
//    if(![self isInternetConnect]){
//        [HelpMsg showMessage:@"刷新失败,请检查你的网络" inView:[[UIApplication sharedApplication].delegate window]];
//        NSData *_dData = [[NSUserDefaults standardUserDefaults] objectForKey:@"devicelistByGroupArr"];
//        
//        NSMutableArray *_cArr = [NSKeyedUnarchiver unarchiveObjectWithData:_dData];
//        if(_cArr.count>0){
//            devicelistByGroupArr = [_cArr mutableCopy];
//        }
//        NSLog(@"失败");
//        [mainTableView reloadData];
//    }else{
        DeviceManage *deviceManage = [DeviceManage sharedInstance];
        [deviceManage getDevicelistByGroupGid:self.groupModel.gid Success:^(NSMutableArray *devicelist) {
            
            /**
             <__NSArrayM 0x14e52270>(
             {
             deviceAddress = "\U4e2d\U56fd\U5e7f\U4e1c\U7701\U6df1\U5733\U5e02\U5357\U5c71\U533a\U79d1\U6280\U5357\U5341\U4e8c\U8def10-\U4e1c\U95e8\U5728\U65b9\U5927\U5927\U53a6\U9644\U8fd1";
             deviceBind =     {
             authUserId = F979A0FBF25C92E3D844ECF9380EF96E;
             bindTime = "2017-04-07 09:40:39";
             controlType = 1;
             deviceBrandId = 50449;
             deviceBrandName = "\U9664\U81ed\U673a";
             deviceCode = 0000c51100070f01;
             deviceId = 247118CA9A587D5A17E898E76B8718F6;
             deviceName = "\U9664\U81ed\U673a";
             deviceSubtypeId = 15;
             deviceSubtypeName = "\U9664\U81ed\U673a";
             deviceTypeId = 7;
             deviceTypeName = "\U7a7a\U6c14\U51c0\U5316\U5668";
             deviceVersion = "<null>";
             macAddress = 000EC608A9C3;
             moduleId = 6;
             moduleName = "\U65b0\U529b\U7ef4 NL6621";
             moduleType = 1;
             onlineStatus = 2;
             prodBrandFullName = "<null>";
             prodBrandId = "<null>";
             prodBrandLogo = "<null>";
             prodBrandShortName = "<null>";
             productCode = "Z408-A17005A";
             productIcon = "http://fileserver1.clife.net:8080/group1/M00/0B/0A/CvtlhlilPeSAeeaXAAElL5kMKGQ0244176";
             productId = 2134;
             productName = "\U9664\U81ed\U673a";
             radiocastName = "<null>";
             roomId = 71625;
             roomName = "\U4e3b\U5367";
             share = 2;
             userKey = 64A74F3AEA01963BA008352515A1041E;
             };
             deviceIcon = "http://fileserver1.clife.net:8080/group1/M00/02/F3/Cvtlp1ilPPyAA-a6AAAHmeG6iTA339.png";
             deviceId = 247118CA9A587D5A17E898E76B8718F6;
             deviceName = "\U9664\U81ed\U673a";
             identify = "LD-AIWNS0-0801";
             mac = 000EC608A9C3;
             onlineStatus = 0;
             }
             )
             **/
            
            [mainTableView.header endRefreshing];
            devicelistByGroupArr = devicelist;
            
            if (devicelistByGroupArr.count == 0) {
                self.notingView.hidden = NO;
            }else{
                //            NSArray *_dArr = [devicelist copy];
                NSData *_dData = [NSKeyedArchiver archivedDataWithRootObject:devicelist];
                [[NSUserDefaults standardUserDefaults] setObject:_dData forKey:@"devicelistByGroupArr"];
                [[NSUserDefaults standardUserDefaults] synchronize];
                
            }
            
            [mainTableView reloadData];
            
        } fail:^(NSError *error, NSInteger statusCode) {
            
            [mainTableView.header endRefreshing];
            [HelpMsg showMessage:@"刷新失败,请检查你的网络" inView:[[UIApplication sharedApplication].delegate window]];
            NSData *_dData = [[NSUserDefaults standardUserDefaults] objectForKey:@"devicelistByGroupArr"];
            
            NSMutableArray *_cArr = [NSKeyedUnarchiver unarchiveObjectWithData:_dData];
            if(_cArr.count>0){
                devicelistByGroupArr = [_cArr mutableCopy];
            }
            NSLog(@"失败");
            [mainTableView reloadData];
        }];

        
//    }
    
 

}

-(BOOL)isInternetConnect{
    
    BOOL whether = YES;
    NSURL *url1 = [NSURL URLWithString:@"http://www.baidu.com"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url1 cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:10];
    NSHTTPURLResponse *response;
    [NSURLConnection sendSynchronousRequest:request returningResponse: &response error: nil];
    if (response == nil) {
        NSLog(@"没有网络");
        whether = NO;
    }
    else{
        NSLog(@"网络是通的");
    }
    return whether;
}


-(void)buttonClick:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];


}

#pragma mark ===================UI===================
-(void)addNaviView{
    UIView *navView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, NAVIBARHEIGHT+STATUSBARHEIGHT)];
    navView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:navView];
    
    CALayer *lineLayer = [[CALayer alloc]init];
    lineLayer.frame = CGRectMake(0, NAVIBARHEIGHT+STATUSBARHEIGHT-SINGLE_LINE_WIDTH, ScreenWidth, SINGLE_LINE_WIDTH);
    lineLayer.backgroundColor = KCOLOR(@"c7c7c7").CGColor;
    [navView.layer addSublayer:lineLayer];
    
    UIButton *leftBtn =[UIButton setButtonWithNomalImage:[UIImage imageNamed:@"arrow_back_black"] AndSelectImage:[UIImage imageNamed:@"arrow_back_black"] AndFrame:CGRectMake(0, STATUSBARHEIGHT, 60, NAVIBARHEIGHT)];
    leftBtn.imageEdgeInsets =UIEdgeInsetsMake(0, 0, 0, 0);
    leftBtn.tag = backTag;
    [leftBtn addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
    [navView addSubview:leftBtn];
    
    UILabel *label =[UILabel setLabelWith:self.groupModel.groupName AndFont:[UIFont systemFontOfSize:18] AndIsNumberOfLines:NO AndtextColor:[UIColor blackColor] AndFrame:CGRectMake((ScreenWidth-100)/2, STATUSBARHEIGHT, 100, NAVIBARHEIGHT) AndAlignment:NSTextAlignmentCenter];
    [navView addSubview:label];


}

-(void)addTableView{
    mainTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, NAVIBARHEIGHT+STATUSBARHEIGHT, ScreenWidth, ScreenHeight - NAVIBARHEIGHT-STATUSBARHEIGHT)];
    mainTableView.delegate =self;
    mainTableView.dataSource =self;
    mainTableView.separatorStyle = NO;
    
    typeof(self) __weak weakSelf = self;
    MJRefreshStateHeader *header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
       
            [weakSelf getDeviceListByGroup];
        
    }];
    header.lastUpdatedTimeLabel.hidden = YES;
    mainTableView.header = header;

    
    UIView *footView =[[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, SINGLE_LINE_WIDTH)];
    footView.backgroundColor =[UIConfig colorFromHexRGB:@"ffffff"];
    mainTableView.tableFooterView = footView;
    [self.view addSubview:mainTableView];


}

-(UIView *)notingView{
    if (!_notingView) {
        _notingView = [[UIView alloc]initWithFrame:CGRectMake(0, NAVIBARHEIGHT+STATUSBARHEIGHT, ScreenWidth, ScreenHeight - NAVIBARHEIGHT-STATUSBARHEIGHT)];
        _notingView.backgroundColor = KCOLOR(@"eef0f1");
//        [self.view addSubview:_notingView];
        
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake((ScreenWidth -160 *NewBasicHeight)/2, 122 *NewBasicHeight , 160 *NewBasicHeight, 160 *NewBasicHeight)];
        imageView.image = [UIImage imageNamed:@"NoCooks"];
        imageView.contentMode = UIViewContentModeScaleAspectFit;
        [_notingView addSubview:imageView];
        
        UILabel * label = [UILabel setLabelWith:@"暂无设备记录" AndFont:KFONT(14) AndIsNumberOfLines:YES AndtextColor:KCOLOR(@"a9a9a9") AndFrame:CGRectMake(0, 24 *NewBasicHeight +CGRectGetMaxY(imageView.frame), ScreenWidth, 16) AndAlignment:NSTextAlignmentCenter];
        
        [_notingView addSubview:label];
        
        
        _notingView.hidden = YES;
    }
        
   
    
    return _notingView;

}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return devicelistByGroupArr.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 70;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    GroupCell *cell = [tableView dequeueReusableCellWithIdentifier:@"reuseIdentifier"];
    cell.accessoryType =UITableViewCellAccessoryDisclosureIndicator;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    NSLog(@"%d",indexPath.row);
    if(!cell){
        cell = [[GroupCell  alloc]initWithStyle:UITableViewCellStyleDefault  reuseIdentifier:@"reuseIdentifier"];
        cell.accessoryType =UITableViewCellAccessoryDisclosureIndicator;
//        cell.leftImageView.image =[UIImage imageNamed:@"deviceIcon_on"];
//        cell.midLabel.text = @"女厕除臭机";
//        cell.locationLabel.text = @"清华大学研究院";
//        cell.DeviceLabel.text = @"设备号:234234234";
    }
    if (devicelistByGroupArr.count!=0) {
        NSNumber *onlineNum = [devicelistByGroupArr[indexPath.row] objectForKey:@"onlineStatus"];
        if ( [onlineNum intValue]==0) {
            //离线
            cell.leftImageView.image =[UIImage imageNamed:@"deviceIcon_off"];
        }else{
            //在线
            cell.leftImageView.image =[UIImage imageNamed:@"deviceIcon_on"];
        }
        
        cell.midLabel.text = [devicelistByGroupArr[indexPath.row] objectForKey:@"deviceName"];
        cell.locationLabel.text = [devicelistByGroupArr[indexPath.row] objectForKey:@"deviceAddress"];
        //设备号
        NSString *identifyStr = [devicelistByGroupArr[indexPath.row] objectForKey:@"mac"];
        NSNumber *onlineStatus = [devicelistByGroupArr[indexPath.row] objectForKey:@"onlineStatus"];
        if([onlineStatus intValue]==1){
            //1 在线
            cell.onlineLabel.hidden = YES;
        }else{
            //0 离线
            cell.onlineLabel.hidden = NO;
        }
        
        cell.DeviceLabel.text =[NSString stringWithFormat:@"设备号:%@",identifyStr];
    }
    
    return cell;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    if (devicelistByGroupArr.count>0) {
            NSMutableDictionary *currentDic = [ devicelistByGroupArr[indexPath.row]  mutableCopy];
        if (currentDic != nil) {
            
            NSMutableDictionary *dic =[NSMutableDictionary dictionaryWithDictionary:[devicelistByGroupArr[indexPath.row] objectForKey:@"deviceBind"]] ;
            MainDevice *currentDevice = [[MainDevice  alloc]init];
            [currentDevice setValuesForKeysWithDictionary:dic];
            DeviceControlController *deviceControl = [[DeviceControlController alloc]init];
            deviceControl.device = currentDevice;
            deviceControl.groupModel = self.groupModel;
            
            [self.navigationController pushViewController:deviceControl animated:YES];
        }

    }


}

@end
