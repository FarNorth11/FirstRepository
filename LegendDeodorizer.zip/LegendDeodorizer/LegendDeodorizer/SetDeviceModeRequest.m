//
//  SetDeviceModeRequest.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/5.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "SetDeviceModeRequest.h"
#import "HETRequest+Private.h"

@implementation SetDeviceModeRequest{
    NSString  *_accessToken;
    NSInteger _appType;
    NSString *_mac;
    NSInteger _modeType;
    NSString *_week;
    NSString *_threshold;
    NSString *_setList;
}

-(instancetype)initWithAccessToken:(NSString *)accessToken appType:(NSInteger)appType mac:(NSString *)mac modeType:(NSInteger)modeType week:(NSString *)week threshold:(NSString *)threshold setList:(NSString *)setList{
    self = [super init];
    if (self) {
        _accessToken = accessToken;
        _appType  = appType;
        _mac = mac;
        _modeType = modeType;
        _week = week;
        _threshold = threshold;
        _setList = setList;
        
    }
    
    return self;



}
- (YTKRequestMethod)requestMethod{
    
    return YTKRequestMethodGet;
    
}

-(BOOL)isHttpsType{
    
    return YES;
}

-(NSString *)requestUrl{
    
    return [@"/v1/app/customization/legend" stringByAppendingString: @"/setDeviceMode"];
    
}

- (id)requestArgument{
    
    if (_setList) {
        return @{
                 @"accessToken":_accessToken,
                 @"appType" :@(_appType),
                 @"mac" : _mac,
                 @"modeType" : @(_modeType),
                 @"week" : _week,
                 @"threshold" : _threshold,
                 @"setList" :_setList
                 };
    }else{
        return @{
                 @"accessToken":_accessToken,
                 @"appType" :@(_appType),
                 @"mac" : _mac,
                 @"modeType" : @(_modeType),
                 @"week" : _week,
                 @"threshold" : _threshold,
                 
                 };
    }
    
    
}

- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock{
    [super startWithSuccessBlockDictionaryParameter:successBlock failure:failureBlock];
}


@end
