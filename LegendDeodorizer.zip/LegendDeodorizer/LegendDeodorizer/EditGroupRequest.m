//
//  EditGroupRequest.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/5.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "EditGroupRequest.h"
#import "HETRequest+Private.h"

@implementation EditGroupRequest{
    NSString  *_accessToken;
    NSInteger _opeType;
    NSInteger _gid;
    NSString *_groupName;
    NSNumber *_pageIndex;
    NSNumber *_pageRows;
}

-(instancetype)initWithAccessToken:(NSString *)accessToken opeType:(NSInteger)opeType gid:(NSInteger)gid groupName:(NSString *)groupName pageIndex:(NSNumber *)pageIndex pageRows:(NSNumber *)pageRows{
    self = [super init];
    if (self) {
        _accessToken = accessToken;
        _opeType = opeType;
        _gid = gid;
        _groupName = groupName;
        _pageIndex = pageIndex;
        _pageRows = pageRows;
    }
    
    return self;

}
- (YTKRequestMethod)requestMethod{
    
    return YTKRequestMethodGet;
    
}

-(BOOL)isHttpsType{
    
    return YES;
}

-(NSString *)requestUrl{
    
    return [@"/v1/app/customization/legend" stringByAppendingString: @"/opeGroup"];
    
}

- (id)requestArgument{
    
    return @{
             @"accessToken":_accessToken,
             @"opeType" : @(_opeType),
             @"gid" : @(_gid),
             @"groupName":_groupName,
             @"pageIndex":_pageIndex,
             @"pageRows":_pageRows
             };
    
}

- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock{
    [super startWithSuccessBlockDictionaryParameter:successBlock failure:failureBlock];
}

@end
