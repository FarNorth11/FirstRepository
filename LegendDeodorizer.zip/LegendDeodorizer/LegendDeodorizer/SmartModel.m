//
//  SmartModel.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/10.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "SmartModel.h"
#import "SetListModel.h"
@implementation SmartModel
- (void)setValue:(id)value forKey:(NSString *)key{
    if ([key isEqualToString:@"setList"]) {
        NSArray *list  = (NSArray *)value;
        NSMutableArray *mutableArray = [[NSMutableArray alloc]init];
        if (list.count >0) {
            for (NSDictionary *dic in list) {
                SetListModel *model = [[SetListModel alloc]init];
                [model setValuesForKeysWithDictionary:dic];
                [mutableArray addObject:model];
            }
            
        }
        [super setValue:mutableArray forKey:key];
    }else{
        [super setValue:value forKey:key];
    }
}
- (void)setValue:(id)value forUndefinedKey:(NSString *)key{

}
@end
