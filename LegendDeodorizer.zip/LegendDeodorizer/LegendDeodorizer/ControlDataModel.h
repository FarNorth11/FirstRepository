//
//  ControlDataModel.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/8.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ControlDataModel : NSObject

//更新状态位
typedef NS_ENUM(UInt16, UpdateFlagStat) {
    power                       = 0x0100, //  开关机
    Atomizerchannel             = 0x0200, //  A/B雾化器
    Airlevel                    = 0x0400,//风量设置
    concentration               = 0x0800,//浓度设置
    sound                       = 0x1000,//音量设置
    mode                        = 0x2000,//模式设置
    wash                        = 0x4000,//清洗设置
    QueryTiming                 = 0x8000,//查询定时标志位
    AddLiquid                   = 0x0001,//加液标志
};


/*
 AddLiquid = 0;        //加液标志
 Airlevel = 0;        //风量设置
 Atomizerchannel = 0;  //AB雾化器设置
 QueryTiming = 0;         //查询定时标志
 concentration = 0;       //浓度
 mode = 0;        //模式
 power = 0;     //开关机设置
 sound = 0;     //声音
 updateFlag = 0;
 wash = 0;    //清洗标志
 
 */

typedef NS_ENUM(NSInteger, powerType ) {
    off = 1,  //1关机  2开机
    on = 2,
};

typedef NS_ENUM(NSInteger, atomizerchannelType ) {
    Model_A = 1,
    Model_B = 2,
    Model_AB = 3,  //定期切换
};


typedef NS_ENUM(NSInteger, airlevelType ) {
    airlevel_1 = 1,
    airlevel_2 = 2,
    airlevel_3 = 3,
};

typedef NS_ENUM(NSInteger, concentrationType ) {
    concentration_1 = 1,
    concentration_2 = 2,
    concentration_3 = 3,
};

typedef NS_ENUM(NSInteger, soundType ) {
    sound_1 = 1,
    sound_2 = 2,
    sound_3 = 3,
};

typedef NS_ENUM(NSInteger, modeType ) {
    smartMode = 1,    //智能模式
    manualMode = 2,   //标准模式
    
};

typedef NS_ENUM(NSInteger, washType ) {
    Befree = 1,    //空闲
    working = 2,   //清洗中
    
};


typedef NS_ENUM(NSInteger, addLiquidType ) {
    addLiquid_off = 0,    //不加液
    addLiquid_on = 1,   //加液
    
};



@property (nonatomic,strong) NSString               *deviceId;          //设备ID
@property (nonatomic,strong) NSString               *userId;          //设备ID

@property (nonatomic,assign) powerType              power;                              //电源开关
@property (nonatomic,assign) atomizerchannelType    Atomizerchannel;                  //AB雾化器设置
@property (nonatomic,assign) airlevelType           Airlevel;                        //风量设置
@property (nonatomic,assign) concentrationType      concentration  ;                  //浓度
@property (nonatomic,assign) soundType              sound;                          //声音
@property (nonatomic,assign) modeType              mode;                          //模式
@property (nonatomic,assign) washType              wash;                          //清洗
@property (nonatomic,assign) NSInteger              QueryTiming;         //查询定时标志
@property (nonatomic,assign) addLiquidType              AddLiquid;          //加液标志


@property (nonatomic,strong) NSDictionary           *CFGJson;           //大循环设置Json
@property (nonatomic,strong) NSData                 *CFGData;           //小循环设置Data
@property (nonatomic,assign) UpdateFlagStat         UpdateFlag;      //设置标志位;

-(void)SetCfgData:(NSDictionary *)CfgdataDic;
-(void)SetRunData:(NSDictionary *)RundataDic;
-(instancetype)initWithData:(NSDictionary *)dic;
- (void)initCfgJson;

+ (NSData *)getLitterRoopConfigDataWithDic:(NSDictionary *)dataDic UpdateFlag:(UInt16)flag PacketNum:(UInt32)PacketNum;
+(NSDictionary *)getBigRoopConfigDataWithDic:(NSDictionary *)dataDic UpdateFlag:(UInt16)flag deviceId:(NSString *)deviceId;
+ (NSDictionary *)GetDeviceCFGInfoWithData:(NSData *)data;

-(NSInteger)changeModel:(NSInteger)currentModel  withMax:(NSInteger) max;


@end
