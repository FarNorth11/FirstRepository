//
//  DeviceGroupVC.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/10.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^ReturnBlock)(NSString * groupName,NSInteger gid);

@interface DeviceGroupVC : UIViewController<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong) NSString * groupName;
@property(nonatomic,assign) NSInteger gid;
@property (nonatomic, copy) ReturnBlock   block;

@end
