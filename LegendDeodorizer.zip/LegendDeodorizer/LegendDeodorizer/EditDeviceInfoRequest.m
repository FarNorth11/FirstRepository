//
//  EditDeviceInfoRequest.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/5.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "EditDeviceInfoRequest.h"
#import "HETRequest+Private.h"

@implementation EditDeviceInfoRequest{
    NSString  *_accessToken;
    NSString *_mac;
    NSString *_deviceName;
    NSString *_deviceAddress;
    NSString *_headName;
    NSString *_headPhone;
    NSInteger _gid;
    NSString *_intro;
}

-(instancetype)initWithAccessToken:(NSString *)accessToken mac:(NSString *)mac deviceName:(NSString *)deviceName deviceAddress:(NSString *)deviceAddress headName:(NSString *)headName headPhone:(NSString *)headPhone gid:(NSInteger)gid intro:(NSString *)intro{
    self = [super init];
    if (self) {
        _accessToken = accessToken;
        _mac = mac;
        _deviceName = deviceName;
        _deviceAddress = deviceAddress;
        _headName = headName;
        _headPhone = headPhone;
        _gid = gid;
        _intro = intro;
    }
    
    return self;
}
- (YTKRequestMethod)requestMethod{
    
    return YTKRequestMethodGet;
    
}

-(BOOL)isHttpsType{
    
    return YES;
}

-(NSString *)requestUrl{
    
    return [@"/v1/app/customization/legend" stringByAppendingString: @"/editDeviceInfo"];
    
}

- (id)requestArgument{
    
    
    NSMutableDictionary *mutableDic = [[NSMutableDictionary alloc]init];
    if (_accessToken) {
        [mutableDic setObject:_accessToken forKey:@"accessToken"];
    }
    if (_mac) {
        [mutableDic setObject:_mac forKey:@"mac"];
    }
    if (_deviceName) {
        [mutableDic setObject:_deviceName forKey:@"deviceName"];
    }
    if (_deviceAddress) {
        [mutableDic setObject:_deviceAddress forKey:@"deviceAddress"];
    }
    if (_headName) {
        [mutableDic setObject:_headName forKey:@"headName"];
    }
    if (_headPhone) {
        [mutableDic setObject:_headPhone forKey:@"headPhone"];
    }
    if (_gid) {
        [mutableDic setObject:@(_gid) forKey:@"gid"];
    }
    if (_intro) {
        [mutableDic setObject:_intro forKey:@"intro"];
    }
    return mutableDic;
//    return @{
//             @"accessToken":_accessToken,
//             @"mac" : _mac,
//             @"deviceName" :_deviceName,
//             @"deviceAddress" : _deviceAddress,
//             @"headName" : _headName,
//             @"headPhone" : _headPhone,
//             @"gid" : @(_gid),
//             @"intro" : _intro
//             
//             };
    
}

- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock{
    [super startWithSuccessBlockDictionaryParameter:successBlock failure:failureBlock];
}

@end
