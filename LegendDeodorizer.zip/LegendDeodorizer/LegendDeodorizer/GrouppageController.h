//
//  GrouppageController.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/28.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GroupListModel.h"

@interface GrouppageController : UIViewController<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,strong) GroupListModel *groupModel;

@property(nonatomic,strong) UIView *notingView;


@end
