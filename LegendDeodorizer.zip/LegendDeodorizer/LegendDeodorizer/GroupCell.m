//
//  GroupCell.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/28.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "GroupCell.h"

@implementation GroupCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


//在每行加分割线
- (void)drawRect:(CGRect)rect
{
    CGFloat gap = 80*NewBasicWidth;
//    CGContextRef context = UIGraphicsGetCurrentContext();
//    CGContextSetStrokeColorWithColor(context, [UIConfig colorFromHexRGB:@"c7c8cc"].CGColor);
//     CGContextSetLineWidth(context, SINGLE_LINE_WIDTH);//线条宽度
//     CGContextMoveToPoint(context, gap, self.frame.size.height-SINGLE_LINE_WIDTH);
//    CGContextAddLineToPoint(context, self.frame.size.width, self.frame.size.height-SINGLE_LINE_WIDTH);
//     CGContextStrokePath(context);
//    CGContextStrokeRect(context, CGRectMake(gap, rect.size.height , rect.size.width - gap * 2, 1));
    
    CGContextRef context = UIGraphicsGetCurrentContext(); //设置上下文
    //画一条线
    CGContextSetStrokeColorWithColor(context, [UIConfig colorFromHexRGB:@"c7c8cc"].CGColor);//线条颜色
    
    CGContextSetLineWidth(context, SINGLE_LINE_WIDTH);//线条宽度
    
    CGContextMoveToPoint(context, gap, self.frame.size.height-SINGLE_LINE_WIDTH); //开始画线, x，y 为开始点的坐标
    
    CGContextAddLineToPoint(context, self.frame.size.width, self.frame.size.height-SINGLE_LINE_WIDTH);//画直线, x，y 为线条结束点的坐标
    
//    CGContextMoveToPoint(context, gap, SINGLE_LINE_WIDTH); //开始画线, x，y 为开始点的坐标
//    
//    CGContextAddLineToPoint(context, self.frame.size.width, SINGLE_LINE_WIDTH);//画直线, x，y 为线条结束点的坐标
    
    CGContextStrokePath(context); //开始画线
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        _leftImageView = [[UIImageView alloc]init];
        [self.contentView addSubview:_leftImageView];
        
        
        _midLabel =[[UILabel alloc]init];
        _midLabel.font =[UIFont systemFontOfSize:16];
        _midLabel.textColor =[UIConfig colorFromHexRGB:@"323232"];
        [self.contentView addSubview:_midLabel];
        
        
        
        _locationLabel =[[UILabel alloc]init];
        _locationLabel.font =[UIFont systemFontOfSize:16];
        _locationLabel.textColor =[UIConfig colorFromHexRGB:@"323232"];
        [self.contentView addSubview:_locationLabel];
        
        _DeviceLabel =[[UILabel alloc]init];
        _DeviceLabel.font =[UIFont systemFontOfSize:16];
        _DeviceLabel.textColor =[UIConfig colorFromHexRGB:@"323232"];
        [self.contentView addSubview:_DeviceLabel];
        
        _onlineLabel =[[UILabel alloc]init];
        _onlineLabel.font =[UIFont systemFontOfSize:8];
        _onlineLabel.textColor =[UIConfig colorFromHexRGB:@"848484"];
        _onlineLabel.layer.borderColor = [[UIConfig colorFromHexRGB:@"848484"] CGColor];
        _onlineLabel.tintColor = [UIConfig colorFromHexRGB:@"848484" ];
        _onlineLabel.layer.borderWidth = SINGLE_LINE_WIDTH;
        _onlineLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_onlineLabel];

        [self createUI];
    }
    return self;
}
- (void)createUI{
    
    if (isiPhone6Plus) {
        _leftImageView.frame =CGRectMake(16 *NewBasicWidth, 10*NewBasicHeight, 49 *NewBasicWidth, 49*NewBasicWidth);
        _leftImageView.contentMode = UIViewContentModeScaleAspectFit;
        
    }else{
        _leftImageView.frame =CGRectMake(16 *NewBasicWidth, 10*NewBasicHeight, 65 *NewBasicWidth, 65*NewBasicWidth);
        _leftImageView.contentMode = UIViewContentModeScaleAspectFit;
    }


    _midLabel.frame =CGRectMake(CGRectGetMaxX(_leftImageView.frame)+16 *NewBasicWidth,8, 100*NewBasicWidth, 18);

    _locationLabel.frame =CGRectMake(CGRectGetMaxX(_leftImageView.frame)+16 *NewBasicWidth, CGRectGetMidY(_midLabel.frame)+10, 200*NewBasicWidth, 18);
    
    _DeviceLabel.frame =CGRectMake(CGRectGetMaxX(_leftImageView.frame)+16 *NewBasicWidth, CGRectGetMaxY(_locationLabel.frame), 200*NewBasicWidth, 18);
    
    _onlineLabel.frame = CGRectMake(CGRectGetMaxX(_midLabel.frame), 10, 40, 15);
    _onlineLabel.text = @"设备离线";
    

}
@end
