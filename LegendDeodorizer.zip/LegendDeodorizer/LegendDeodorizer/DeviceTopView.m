//
//  DeviceTopView.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/29.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "DeviceTopView.h"

@implementation DeviceTopView{
    UILabel *regularPPMLab;

}

@synthesize liquidImgView,currentModeLab,currentMPPMLab;
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self createUI];
    }
    return self;
}

-(void)createUI{
    //背景
    UIImageView *topView = [[UIImageView alloc]initWithFrame:self.bounds];
    topView.image =[UIImage imageNamed:@"deviceBg"];
    topView.userInteractionEnabled = YES;
    [self addSubview:topView];
    
//    UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 0, 0)];
//    imageView.image = [UIImage imageNamed:@"NH3"];
    UIImageView *imageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"NH3_white"]];
    imageView.frame = CGRectMake(50*NewBasicWidth, 70*NewBasicHeight, imageView.frame.size.width, imageView.frame.size.height);
    [topView addSubview:imageView];
    
//    //计算字体的高度
//    CGRect currentTextFrame = [currentWaterCountLabel.text boundingRectWithSize:CGSizeMake(200, 100) options:NSStringDrawingUsesLineFragmentOrigin attributes:[NSDictionary dictionaryWithObjectsAndKeys:currentLabelFont,NSFontAttributeName, nil] context:nil];
    
//    CGSize anaSizeX=[@"00.00" sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:30]}];
    CGSize anaSizeX = [@"00.00" boundingRectWithSize:CGSizeMake(200, 100) options:NSStringDrawingUsesLineFragmentOrigin attributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:30],NSFontAttributeName, nil] context:nil].size;
    CGFloat laberY = CGRectGetMaxY(imageView.frame)-(imageView.frame.size.height/2)- (anaSizeX.height/2);
//    ScreenWidth - anaSizeX.width -58*NewBasicWidth
//    currentMPPMLab =[[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(imageView.frame)+58*NewBasicWidth,laberY, anaSizeX.width, anaSizeX.height)];
    currentMPPMLab =[[UILabel alloc] initWithFrame:CGRectMake(ScreenWidth - anaSizeX.width -100*NewBasicWidth,laberY, anaSizeX.width, anaSizeX.height)];
    currentMPPMLab.font = [UIFont systemFontOfSize:30];
    currentMPPMLab.textColor = [UIColor whiteColor];
    currentMPPMLab.text =@"00.00";
    currentMPPMLab.textAlignment = NSTextAlignmentRight;
    [topView addSubview:currentMPPMLab];
    
//    CGSize anaSizelea=[@"ppm" sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:10]}];
    CGSize anaSizelea = [@"ppm" boundingRectWithSize:CGSizeMake(200, 100) options:NSStringDrawingUsesLineFragmentOrigin attributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:10],NSFontAttributeName, nil] context:nil].size;
    regularPPMLab =[[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(currentMPPMLab.frame), CGRectGetMinY(currentMPPMLab.frame), anaSizelea.width, anaSizelea.height)];
    regularPPMLab.font = [UIFont systemFontOfSize:10];
    regularPPMLab.textColor = [UIColor whiteColor];
    regularPPMLab.text =@"ppm";
    regularPPMLab.textAlignment = NSTextAlignmentRight;
    [topView addSubview:regularPPMLab];
    
    
    
    liquidImgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"zhiwuye"]];
    liquidImgView.frame = CGRectMake(CGRectGetMinX(imageView.frame)+8, CGRectGetMaxY(imageView.frame)+40*NewBasicHeight, liquidImgView.frame.size.width, liquidImgView.frame.size.height);
    [topView addSubview:liquidImgView];


    CGFloat ModeLabY = CGRectGetMinY(liquidImgView.frame)+5*NewBasicHeight;
//    UILabel *regularModeLab = [[UILabel alloc] initWithFrame:CGRectMake(CGRectGetMaxX(liquidImgView.frame)+60*NewBasicWidth, ModeLabY, 80, 15)];
    UILabel *regularModeLab = [[UILabel alloc] initWithFrame:CGRectMake(ScreenWidth - 80 - 100*NewBasicWidth, ModeLabY, 80, 15)];
    regularModeLab.font = [UIFont systemFontOfSize:15];
    regularModeLab.textColor = [UIColor whiteColor];
    regularModeLab.text =@"当前模式:";
    regularModeLab.textAlignment = NSTextAlignmentCenter;
    [topView addSubview:regularModeLab];
    
    CGSize anaSizeHGG = [@"智能模式" boundingRectWithSize:CGSizeMake(200, 200) options:NSStringDrawingUsesLineFragmentOrigin attributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:30],NSFontAttributeName, nil] context:nil].size;
    currentModeLab = [[UILabel alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(regularModeLab.frame)+20, anaSizeHGG.width, anaSizeHGG.height)];
    currentModeLab.font = [UIFont systemFontOfSize:30];
    currentModeLab.center = CGPointMake(regularModeLab.center.x, regularModeLab.center.y +regularModeLab.frame.size.height/2+20);
    currentModeLab.textColor = [UIColor whiteColor];
    currentModeLab.text =@"智能模式";
    currentModeLab.textAlignment = NSTextAlignmentCenter;
    [topView addSubview:currentModeLab];
    



}

-(void)setImageValue:(NSInteger )value{
    if (value ==0 ) {
        liquidImgView.image = [UIImage imageNamed:@"zhiwuye"];
    }else if(value ==5){
        liquidImgView.image = [UIImage imageNamed:@"zhiwuye_3"];
    }else if(value ==4 ||value ==3 ){
        liquidImgView.image = [UIImage imageNamed:@"zhiwuye_2"];
    }else{
        liquidImgView.image = [UIImage imageNamed:@"zhiwuye_1"];
    }
    CGSize anaSizelea = [@"ppm" boundingRectWithSize:CGSizeMake(200, 100) options:NSStringDrawingUsesLineFragmentOrigin attributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:10],NSFontAttributeName, nil] context:nil].size;
    regularPPMLab.frame = CGRectMake(CGRectGetMaxX(currentMPPMLab.frame)+10, CGRectGetMinY(currentMPPMLab.frame),anaSizelea.width, anaSizelea.height);
    
}
@end
