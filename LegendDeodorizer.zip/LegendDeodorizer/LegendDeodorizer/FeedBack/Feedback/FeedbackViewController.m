//
//  FeedbackViewController.m
//  CLove
//
//  Created by qygxwy on 15/5/21.
//  Copyright (c) 2015年 luojie. All rights reserved.
//

#import "FeedbackViewController.h"
#import "CCCommonHelp.h"
#import "FeedBackStyleView.h"
#import "FeedStyleChooseView.h"
#import "FeedDevicesController.h"
#import "HotRequest.h"
#import "FeedListViewController.h"

#import "NSString+Utils.h"
@interface FeedbackViewController ()<UITextViewDelegate,DeviceSelectDelegate>
{
    UITextView *adviceView;
    UILabel *placeholderLabel;
    UITextField *phoneField;
    UITapGestureRecognizer *HiddenKeyboardtap;
    
    FeedBackStyleView *questionView;//问题选项
    FeedBackStyleView *deviceView;//设备选项
    
    MainDevice *selectDevice;
    NSArray *files;
}
@end

@implementation FeedbackViewController

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    AppDelegate *app =(AppDelegate *)[UIApplication sharedApplication].delegate;
    app.root.tabBar.hidden = YES;
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardShow)
                                                 name:UIKeyboardDidShowNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardHide)
                                                 name:UIKeyboardDidHideNotification
                                               object:nil];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidHideNotification object:nil];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self createNaviView];
    [self createContentView];
}

- (void) createNaviView
{

    NSString *title = @"意见反馈";
    CGSize titleSize = [UIConfig sizeWithString:title Font:[UIFont systemFontOfSize:17] maxSize:CGSizeMake(MAXFLOAT, MAXFLOAT)];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(ScreenWidth_2-titleSize.width/2, 0, titleSize.width, NAVIBARHEIGHT)];
    titleLabel.text = title;
    titleLabel.textColor = [UIColor blackColor];
    titleLabel.font = [UIFont systemFontOfSize:17];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    self.navigationItem.titleView = titleLabel;

    UIFont *btnFont = [UIFont systemFontOfSize:17];
    CGSize btnSize = [UIConfig sizeWithString:@"提交" Font:btnFont maxSize:CGSizeMake(MAXFLOAT, MAXFLOAT)];
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [rightBtn setTitle:@"提交" forState:UIControlStateNormal];
    rightBtn.titleLabel.font = btnFont;
    [rightBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    rightBtn.frame = (CGRect){{0,0},btnSize};
    [rightBtn addTarget:self action:@selector(submitAction) forControlEvents:UIControlEventTouchUpInside];
    [self.navigationItem setRightBarButtonItem:[[UIBarButtonItem alloc] initWithCustomView:rightBtn]];
    
    self.view.backgroundColor = [UIConfig colorFromHexRGB:@"f0f0f0"];
    
    self.view.userInteractionEnabled = YES;
    
}


- (void) hideKeyboardAction
{
    [self.view endEditing:YES];
    if (adviceView.text.length == 0) {
        [placeholderLabel setHidden:NO];
    }
}

- (void) createContentView
{
    UIFont *textFont = [UIFont systemFontOfSize:15];
    CGSize maxSize = CGSizeMake(MAXFLOAT, MAXFLOAT);
    CGSize titleSize = [UIConfig sizeWithString:@"问题和意见" Font:textFont maxSize:maxSize];
    UIView *contentView = [[UIView alloc] initWithFrame:self.view.frame];
    [self.view addSubview:contentView];
    CGFloat paddingWidth = 28/2*BasicWidth;
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(paddingWidth, 40/2*BasicHeight, ScreenWidth, titleSize.height*BasicHeight)];
    titleLabel.text = @"问题和意见";
    titleLabel.font = textFont;
    titleLabel.textColor = [UIConfig colorFromHexRGB:@"555555"];
    [contentView addSubview:titleLabel];
    
    UIView *centerView = [[UIView alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(titleLabel.frame) + 8*BasicHeight, ScreenWidth, 230/2*BasicHeight)];
    centerView.backgroundColor = WHITECOLOR;
    centerView.layer.borderWidth = SINGLE_LINE_WIDTH;
    centerView.layer.borderColor = KCOLOR(@"e6e6e6").CGColor;
    [contentView addSubview:centerView];
    
    adviceView = [[UITextView alloc] initWithFrame:CGRectMake(paddingWidth, 3*BasicHeight, ScreenWidth-paddingWidth*2, (230-28)/2*BasicHeight)];
    adviceView.delegate = self;
    adviceView.font = textFont;
    [centerView addSubview:adviceView];
    
    placeholderLabel = [[UILabel alloc] initWithFrame:CGRectMake(paddingWidth + 6*BasicWidth, 10*BasicHeight, ScreenWidth-paddingWidth*2, titleSize.height*BasicHeight)];
    [placeholderLabel setHidden:NO];
    placeholderLabel.text = @"请输入您的宝贵意见";
    placeholderLabel.font = textFont;
    placeholderLabel.textColor = [UIConfig colorFromHexRGB:@"323232"];
    [centerView addSubview:placeholderLabel];
    
    UILabel *phoneLabel = [[UILabel alloc] initWithFrame:CGRectMake(paddingWidth, CGRectGetMaxY(centerView.frame) + 40/2*BasicHeight, ScreenWidth - paddingWidth*2, titleSize.height*BasicHeight)];
    phoneLabel.text = @"联系方式(选填)";
    phoneLabel.font = textFont;
    phoneLabel.textColor = titleLabel.textColor;
    [contentView addSubview:phoneLabel];
    
    phoneField = [[UITextField alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(phoneLabel.frame) + 8*BasicHeight, ScreenWidth, 78/2*BasicHeight)];
    phoneField.backgroundColor = WHITECOLOR;
    phoneField.placeholder = @"请输入您的手机号码/邮箱";
    phoneField.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, paddingWidth, 78/2*BasicHeight)];
    phoneField.leftViewMode = UITextFieldViewModeAlways;
    phoneField.font = textFont;
    phoneField.layer.borderWidth = SINGLE_LINE_WIDTH;
    phoneField.layer.borderColor = KCOLOR(@"e6e6e6").CGColor;
    phoneField.clearButtonMode = UITextFieldViewModeWhileEditing;
    [contentView addSubview:phoneField];
    
    files = @[@"APP使用",@"硬件设备",@"配网相关",@"意见建议",@"其它"];
    __block NSInteger selectindex = 0;
    questionView = [[FeedBackStyleView alloc]initWithFrame:CGRectMake(-1, CGRectGetMaxY(phoneField.frame) + 20 , ScreenWidth+2, 48 *NewBasicHeight) title:@"问题类型" selectTitle:files[0] AndTapAvtion:^{
     
        FeedStyleChooseView * bellView = [[FeedStyleChooseView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight) originY: CGRectGetMaxY(questionView.frame)+64 itemArray:files ButtonClick:^(UIButton *button,NSInteger selectIndex) {
            if (button.tag ==sureTag) {
                
                questionView.accessLabel.text = [files objectAtIndex:selectIndex];
                selectindex = selectIndex;
                
                if (selectIndex == 1) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        deviceView.hidden = NO;
                    });
                    
                }else{
                    dispatch_async(dispatch_get_main_queue(), ^{
                        deviceView.hidden = YES;
                    });
                }
            }
            
            
        }];
        bellView.selectIndex = selectindex;
        [bellView show];
    }];
    questionView.layer.borderColor = KCOLOR(@"e6e6e6").CGColor;
    questionView.layer.borderWidth = SINGLE_LINE_WIDTH;
//    [contentView addSubview:questionView];
    __weak typeof(self)Wself = self;
    deviceView = [[FeedBackStyleView alloc]initWithFrame:CGRectMake(-1, CGRectGetMaxY(questionView.frame), ScreenWidth+2, 44) title:@"所属设备" selectTitle:@"请选择" AndTapAvtion:^{
       dispatch_async(dispatch_get_main_queue(), ^{
           
           FeedDevicesController *devices = [[FeedDevicesController alloc]init];
           devices.deviceDelegate = self;
           if (![deviceView.accessLabel.text isEqualToString:@"未选择"]) {
                devices.deviceName = deviceView.accessLabel.text;
           }
          
           [Wself.navigationController pushViewController:devices animated:YES];
       });
        
    }];
    deviceView.layer.borderColor = KCOLOR(@"e6e6e6").CGColor;
    deviceView.layer.borderWidth = SINGLE_LINE_WIDTH;
    [contentView addSubview:deviceView];
    deviceView.hidden = YES;
}

- (void) submitAction
{
    if ([adviceView isFirstResponder]) {
        [adviceView resignFirstResponder];
    }
    if ([phoneField isFirstResponder]) {
        [phoneField resignFirstResponder];
    }
    if (!adviceView.text||adviceView.text.length==0) {
         [CCCommonHelp showAutoDissmissAlertView:nil msg:@"请填写您的宝贵意见"];
        return;
    }
    if (phoneField.text.length>0&&[self isChinese:phoneField.text]) {
        [HelpMsg showMessage:@"联系方式含有中文" inView:self.view];
        return;
    }
//    if (![NSString isValidEmail:phoneField.text]&&![NSString isMobileNumber:phoneField.text]) {
//        [HelpMsg showMessage:@"号码无效" inView:self.view];
//        return;
//    }
    if(adviceView.text.length>50)
    {
       adviceView.text=[adviceView.text substringToIndex:50];
    }
    
    NSNumber *type ;
    for (NSInteger i=0; i<files.count; i++) {
        if ([questionView.accessLabel.text isEqualToString:files[i]]) {
            type = @(i+1);
        }
    }
    if (type.integerValue ==2 &&selectDevice == nil) {
        
        [HelpMsg showMessage:@"未选择设备" inView:self.view];
        return;
    }
    [CCCommonHelp showAutoDissmissAlertView:nil msg:@"正在提交..."];
    NSNumber *productId;
    if (type.integerValue ==2 &&selectDevice&&selectDevice.productId != nil) {
        productId = selectDevice.productId;
    }
    __weak typeof(self)Wself = self;
    [[HotRequest shareInstance]addFeedBackWithAccessToken:[HETUserInfo userInfo].accessToken contact:phoneField.text content:adviceView.text productId:productId feedbackType:type AndSuccess:^(NSNumber *num) {
        if (adviceView.text.length>0) {
            adviceView.text =@"";
        }
        if (phoneField.text.length>0) {
            phoneField.text =@"";
        }
        [CCCommonHelp HidHud];
        [CCCommonHelp showAutoDissmissAlertView:nil msg:@"提交成功，谢谢您的意见"];
        
        for (UIViewController *view in self.navigationController.viewControllers) {
            if ([view isKindOfClass:[FeedListViewController class]]) {
                FeedListViewController *feed = (FeedListViewController *)view;
                [feed freshData];
                [Wself.navigationController  popToViewController:feed animated: YES];
                return ;
            }
        }
        
        FeedListViewController *feed = [[FeedListViewController alloc]init];
        NSMutableArray * viewsArray = [NSMutableArray arrayWithArray:Wself.navigationController.viewControllers];
        [viewsArray insertObject:feed atIndex:1];
        Wself.navigationController.viewControllers = viewsArray;
        [Wself.navigationController popToViewController:feed animated: YES];
        
    } AndFaliBlock:^(NSError *error) {
        [CCCommonHelp HidHud];
        [CCCommonHelp showAutoDissmissAlertView:nil msg:error.userInfo[@"NSLocalizedDescription"]];
    }];
    
    
}
#pragma mark-=====DeviceSelectDelegate
- (void)getSelectDevice:(MainDevice *)model{

    deviceView.accessLabel.text = model.productName;
    selectDevice = model;
}
#pragma mark - UITextViewDelegate

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    [placeholderLabel setHidden:YES];
}

- (void)textViewDidChange:(UITextView *)textView
{
    NSInteger length = textView.text.length;

    if (length>50) {
        textView.text = [textView.text substringToIndex:50];
        length = 50;
    }
    if (length>0) {
        [placeholderLabel setHidden:YES];
    }
    else
    {
        [placeholderLabel setHidden:NO];
    }
}
- (BOOL)isChinese:(NSString *)str{
    for (int i =0; i<str.length; i++) {
        int a =[str characterAtIndex:i];
        if (a>0x4e00&&a<0x9fff) {
            return YES;
        }
    }
    return NO;
}
-(void)keyboardShow{
    if (!HiddenKeyboardtap) {
        HiddenKeyboardtap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideKeyboardAction)];
        [self.view addGestureRecognizer:HiddenKeyboardtap];
    }
}

-(void)keyboardHide{
    if (HiddenKeyboardtap) {
        [self.view removeGestureRecognizer:HiddenKeyboardtap];
        HiddenKeyboardtap = nil;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidHideNotification object:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
