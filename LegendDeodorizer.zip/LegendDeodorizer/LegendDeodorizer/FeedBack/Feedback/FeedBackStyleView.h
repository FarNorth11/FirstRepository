//
//  FeedBackStyleView.h
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/19.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^tapBlock)();
@interface FeedBackStyleView : UIView

@property (strong,nonatomic) UILabel *titleLabel;

@property (strong,nonatomic) UILabel *accessLabel;

@property (copy,nonatomic) tapBlock tapblock;

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title  selectTitle:(NSString *)select AndTapAvtion:(tapBlock)block;

@end
