//
//  FeedBackStyleView.m
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/19.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "FeedBackStyleView.h"

@implementation FeedBackStyleView

- (instancetype)initWithFrame:(CGRect)frame title:(NSString *)title  selectTitle:(NSString *)select AndTapAvtion:(tapBlock)block
{
    self = [super initWithFrame:frame];
    if (self) {
        self.tapblock = block;
        self.backgroundColor = WHITECOLOR;
        self.titleLabel = [UILabel setLabelWith:title AndFont:KFONT(16) AndIsNumberOfLines:YES AndtextColor:KCOLOR(@"323232") AndFrame:CGRectMake(16 *NewBasicWidth, (48 *NewBasicHeight-18)/2, 100 *NewBasicWidth, 18) AndAlignment:NSTextAlignmentLeft];
        [self addSubview:self.titleLabel];
        
        self.accessLabel = [UILabel setLabelWith:select AndFont:KFONT(14) AndIsNumberOfLines:YES AndtextColor:KCOLOR(@"848484") AndFrame:CGRectMake(70 *NewBasicWidth, (48 *NewBasicHeight-16)/2, ScreenWidth -116 *NewBasicWidth, 16) AndAlignment:NSTextAlignmentRight];
        [self addSubview:self.accessLabel];
        
        CALayer *accessLayer = [[CALayer alloc]init];
        accessLayer.contents = (id)[UIImage imageNamed:@"rightBtn"].CGImage;
        accessLayer.frame = CGRectMake(ScreenWidth - 30 *NewBasicWidth, (48 *NewBasicHeight-14)/2, 14, 14);
        [self.layer addSublayer:accessLayer];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapAction:)];
        
        self.userInteractionEnabled = YES;
        
        [self addGestureRecognizer:tap];

    }
    return self;
}

- (void)tapAction:(UITapGestureRecognizer *)sender{
    
    if (self.tapblock) {
        self.tapblock();
    }
}
@end
