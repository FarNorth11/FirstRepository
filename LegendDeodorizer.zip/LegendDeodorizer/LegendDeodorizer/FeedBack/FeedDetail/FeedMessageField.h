//
//  FeedMessageField.h
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/30.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^sendMsg)(id);
@interface FeedMessageField : UIView<UITextViewDelegate>

@property (copy,nonatomic) sendMsg block;

@property (strong,nonatomic) UITextView *FeedField;

- (instancetype)initWithFrame:(CGRect)frame sendMsg:(sendMsg)send;


@end
