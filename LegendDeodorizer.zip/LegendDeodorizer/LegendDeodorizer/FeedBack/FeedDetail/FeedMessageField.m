//
//  FeedMessageField.m
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/30.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "FeedMessageField.h"
#import <Masonry.h>

@implementation FeedMessageField

- (instancetype)initWithFrame:(CGRect)frame sendMsg:(sendMsg)send
{
    self = [super initWithFrame:frame];
    if (self) {
        self.block = send;
        self.backgroundColor = KCOLOR(@"f4f4f6");
        //WithFrame:CGRectMake(20 *NewBasicWidth , 7, 288 *NewBasicWidth, 36)
        _FeedField = [[UITextView alloc]init];
        [self addSubview:_FeedField];
        
        [_FeedField mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self).with.offset(20 * NewBasicWidth);
            make.top.equalTo(self.mas_top).with.offset(7);
            make.width.mas_equalTo(288 * NewBasicWidth);
            make.bottom.equalTo(self.mas_bottom).with.offset(-7);
        }];
        
        _FeedField.layer.borderWidth = SINGLE_LINE_WIDTH;
        _FeedField.layer.borderColor = KCOLOR(@"d7d8da").CGColor;
        _FeedField.layer.cornerRadius = 5;
        _FeedField.layer.masksToBounds = YES;
        _FeedField.font = KFONT(16);
        _FeedField.delegate = self;
        _FeedField.scrollEnabled = NO;
        _FeedField.scrollsToTop = NO;
        _FeedField.showsHorizontalScrollIndicator = NO;
        _FeedField.enablesReturnKeyAutomatically = YES;
        _FeedField.returnKeyType = UIReturnKeyGo;
        
        UIButton *sendBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [sendBtn setTitle:@"发送" forState:UIControlStateNormal];
        [sendBtn setTitleColor:KCOLOR(@"323232")  forState:UIControlStateNormal];
        sendBtn.titleLabel.font = KFONT(16);
//        UIButton * sendBtn = [UIButton setButtonWith:@"发送" AndNomalColor:KCOLOR(@"323232") AndSelectColor:KCOLOR(@"323232") AndFont:KFONT(16) AndFrame:CGRectMake(CGRectGetMaxX(_FeedField.frame), 0, ScreenWidth -CGRectGetMaxX(_FeedField.frame), self.frame.size.height)];
        [self addSubview:sendBtn];
        [sendBtn addTarget:self action:@selector(buttonActions) forControlEvents:UIControlEventTouchUpInside];
        
        [sendBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(_FeedField.mas_right).with.offset(0);
            make.top.equalTo(self).with.offset(0);
            make.right.equalTo(self).offset(0);
            make.height.mas_equalTo(50);
        }];
    }
    return self;
}
#pragma mark-===============事件==============
- (void)buttonActions{
    if (self.block) {
        self.block(self.FeedField.text);
    }
}
#pragma mark-===============UITextViewDelegate=====
- (void)textViewDidBeginEditing:(UITextView *)textView{
    
    [textView becomeFirstResponder];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{

   
    if (textView.text.length >50) {
        
        return NO;
    }else{
        if ([text isEqualToString:@"\n"]) {
            if (self.block) {
                self.block(self.FeedField.text);
            }
            
            return NO;
        }else{
             return YES;
        }
       
    }
}
@end
