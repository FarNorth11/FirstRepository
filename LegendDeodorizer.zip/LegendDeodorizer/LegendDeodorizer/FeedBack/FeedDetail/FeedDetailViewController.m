//
//  FeedDetailViewController.m
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/30.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "FeedDetailViewController.h"
#import "FeedListViewController.h"
#import "FeedMessageField.h"
#import "FeedBackCell.h"
#import "HotRequest.h"
#import "UIImage+Gif.h"
#import "MJRefreshGifHeader.h"
#import "UIImageView+WebCache.h"
#import "NSDate+SSToolkitAdditions.h"
#import "CCCommonHelp.h"
@interface FeedDetailViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (strong,nonatomic) UITableView * feedTableView;

@property (strong,nonatomic) NSMutableArray *feedListArray;
@end

@implementation FeedDetailViewController
{
    FeedMessageField *feedTextFied;
    CGFloat keyboardY;
    CGFloat textHeight;
    
    NSInteger currentPage;//当前页(默认从第一页开始)
    NSInteger pageCount;//总页数
    
    NSInteger hypotheticalId;//虚拟id
}
- (void)viewDidLoad {
    [super viewDidLoad];
    textHeight = 20;
    hypotheticalId = -1;
    self.title = @"意见反馈";
    [self.view addSubview:self.feedTableView];
    [self createBottomView];
    
    self.view.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(keyboardOut)];
    [self.view addGestureRecognizer:tap];
    //监听键盘弹出
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(textFieldUp:) name:UIKeyboardWillShowNotification object:nil];
    //监听textfield输入
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(textFieldFrame:) name:UITextViewTextDidChangeNotification object:nil];
    // Do any additional setup after loading the view.
    
    [self getRequest];
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    AppDelegate *app =(AppDelegate *)[UIApplication sharedApplication].delegate;
    app.root.tabBar.hidden = YES;
}
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    if ([feedTextFied.FeedField isFirstResponder]) {
        [feedTextFied.FeedField resignFirstResponder];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)dealloc{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}
#pragma mark-==============UI================
- (void)createBottomView{
    __weak typeof(self)Wself = self;
   feedTextFied = [[FeedMessageField alloc]initWithFrame:CGRectMake(0, ScreenHeight -NAVIBARHEIGHT -STATUSBARHEIGHT- 50, ScreenWidth, 50) sendMsg:^(NSString *text) {
       
       [Wself submitAction];
    }];
    feedTextFied.layer.borderWidth = SINGLE_LINE_WIDTH;
    feedTextFied.layer.borderColor =  KCOLOR(@"d7d8da").CGColor;
    [self.view addSubview:feedTextFied];
}
- (UITableView *)feedTableView{
    
    if (!_feedTableView) {
        _feedTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight-22-  50) style:UITableViewStylePlain];
        _feedTableView.dataSource = self;
        _feedTableView.delegate = self;
        _feedTableView.backgroundColor = KCOLOR(@"f4f4f6");
        _feedTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [_feedTableView registerClass:[FeedBackCell class] forCellReuseIdentifier:@"cell"];
        
        _feedTableView.tableFooterView = [UIView new];
        @weakify(self);
     
        UIImage *xiaoC_refresh = [UIImage sd_animatedGIFNamed:@"XiaoC_loading"];
        MJRefreshGifHeader *header = [MJRefreshGifHeader headerWithRefreshingBlock:^{
            @strongify(self);
            
            [self getMoreRequest];
        }];
        
        [header setImages:xiaoC_refresh.images forState:MJRefreshStateIdle];
        [header setImages:xiaoC_refresh.images forState:MJRefreshStatePulling];
        [header setImages:xiaoC_refresh.images forState:MJRefreshStateRefreshing];
        [header setTitle:@"正在获取最新数据!" forState:MJRefreshStateRefreshing];
        [header setTitle:@"没有更多数据了!" forState:MJRefreshStateNoMoreData];
        header.lastUpdatedTimeLabel.hidden = YES;
        self.feedTableView.header = header;
    }
    return _feedTableView;
}

#pragma mark-===================http================
- (void)getRequest{
    
    if (!self.feedListArray) {
        self.feedListArray = [[NSMutableArray alloc]init];
    }else{
        [self.feedListArray removeAllObjects];
    }
    currentPage = 1;
    
    [self startRequest];
    
}
- (void)getMoreRequest{
    if (pageCount>0&&currentPage<pageCount) {
        
        currentPage++;
        [self startRequest];
        
    }else{
        [self.feedTableView.header endRefreshing];
    }

}
- (void)startRequest{
    
    __weak typeof(self)Wself = self;
    
    [[HotRequest shareInstance]getFeedBackReplyListWithAccessToken:[HETUserInfo userInfo].accessToken feedbackId:self.feedModel.feedbackId pageIndex:currentPage pageRows:20 AndSuccess:^(NSDictionary *dictValue) {
        if ([dictValue.allKeys containsObject:@"pager"]) {
            pageCount =  [dictValue[@"pager"][@"totalPages"]integerValue];
        }
        if ([dictValue.allKeys containsObject:@"list"]) {
            NSArray *list = dictValue[@"list"];
            //，首页请求20个，如果首页内容少于20个，添加content内容在第一个
            if (currentPage ==1 &&list.count <20) {
                FeedBackReplyModel *user = [[FeedBackReplyModel alloc]init];
                user.replyContent = Wself.feedModel.content;
                user.replyTime = Wself.feedModel.feedbackTime;
                user.replyUserModel = Wself.feedModel.userModel;
                user.feedbackId = Wself.feedModel.feedbackId;
                user.isShowTime = YES;
                CGRect rect = [ user.replyContent boundingRectWithSize:CGSizeMake(232 *NewBasicWidth, 999) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:KFONT(16)} context:nil];
                user.replySize = CGSizeMake(rect.size.width, rect.size.height +5);
               
                [Wself.feedListArray addObject:user];
            }
            
            if (list.count >0) {
                
                for (NSInteger i= list.count-1; i>=0; i--) {
                    NSDictionary *replyDic = list[i];
                    FeedBackReplyModel *model = [[FeedBackReplyModel alloc]init];
                    [model setValuesForKeysWithDictionary:replyDic];
                    model.isShowTime = YES;
                    [Wself.feedListArray addObject:model];
                }
               
            }
            [Wself resetArray];
        }
        [Wself.feedTableView.header endRefreshing];
        
        [Wself.feedTableView reloadData];
        if (Wself.feedListArray.count>0) {
            NSIndexPath *index = [NSIndexPath indexPathForRow:Wself.feedListArray.count-1 inSection:0];
            [Wself.feedTableView scrollToRowAtIndexPath:index atScrollPosition:UITableViewScrollPositionBottom animated:NO];
        }
       
    } AndFaliBlock:^(NSError *error) {
        [Wself.feedTableView.header endRefreshing];
        
        NSLog(@"%@",error);
    }];
    
}
- (void)resetArray{

    if (self.feedListArray.count>1) {
        
        for (NSInteger i=1; i<self.feedListArray.count; i++) {
            FeedBackReplyModel *last = self.feedListArray[i-1];
            FeedBackReplyModel *this = self.feedListArray[i];
            
            NSInteger lastTimeInval = last.replyTime.integerValue/1000;
            NSInteger thisTimeInval = this.replyTime.integerValue/1000;
            if (thisTimeInval -lastTimeInval >60 *60) {
                this.isShowTime = YES;
            }else{
                this.isShowTime = NO;
            }
            [self.feedListArray replaceObjectAtIndex:i withObject:this];
        }
    }
}
#pragma mark-=======<UITableViewDelegate,UITableViewDataSource>================
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.feedListArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    FeedBackCell *Cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    Cell.backgroundColor = [UIColor clearColor];
    Cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if (self.feedListArray.count > indexPath.row) {

        FeedBackReplyModel *replyModel = self.feedListArray[indexPath.row];
        [Cell fillCellWith:replyModel isShow:replyModel.isShowTime];
        
    }

    return Cell;

}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.feedListArray.count > indexPath.row) {

        FeedBackReplyModel *replyModel = self.feedListArray[indexPath.row];
        
        if (replyModel.isShowTime) {
            return replyModel.replySize.height +72 *NewBasicHeight;
            
        }else{
            return replyModel.replySize.height +38 *NewBasicHeight;
        }
       
    }else{
        return 0;
    }
    
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    
    return 72 *NewBasicHeight;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *contentView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 72 *NewBasicHeight)];
    
    contentView.backgroundColor = WHITECOLOR;
    contentView.layer.borderColor = KCOLOR(@"e6e6e6").CGColor;
    contentView.layer.borderWidth = SINGLE_LINE_WIDTH;
    
    UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(16 * NewBasicWidth, 8 *NewBasicHeight, 56 *NewBasicHeight, 56 *NewBasicHeight)];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    [contentView addSubview:imageView];
    
    NSString *itemStr;
    NSArray *files = @[@"APP使用",@"硬件设备",@"配网相关",@"意见建议",@"其它"];
    if (self.feedModel.feedbackType.integerValue ==2) {
        [imageView sd_setImageWithURL:[NSURL URLWithString:self.feedModel.productModel.productIcon] placeholderImage:[UIImage imageNamed:@"imageLoading"]];
        itemStr = self.feedModel.productModel.productName;
    }else{
        imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"FeedType_%@",self.feedModel.feedbackType]];
        if (self.feedModel.feedbackType.integerValue< files.count) {
            itemStr = files[self.feedModel.feedbackType.integerValue -1];
        }else{
            itemStr = files.firstObject;
        }
        
    }
    
    UILabel *itemLabel = [UILabel setLabelWith:itemStr AndFont:KFONT(16) AndIsNumberOfLines:YES AndtextColor:KCOLOR(@"323232") AndFrame:CGRectMake(CGRectGetMaxX(imageView.frame) + 12 *NewBasicWidth, (72 *NewBasicHeight - 18)/2, ScreenWidth -CGRectGetMaxX(imageView.frame) - 12 *NewBasicWidth, 18) AndAlignment:NSTextAlignmentLeft];
    
    [contentView addSubview:itemLabel];
    
    
    return contentView;

}
#pragma mark-==========通知=========
- (void)textFieldUp:(NSNotification *)notification{

    //1. 获取键盘的 Y 值
    CGRect keyboardFrame = [[notification.userInfo objectForKey:@"UIKeyboardFrameEndUserInfoKey"] CGRectValue];
    
    //注意从字典取出来的是对象，而 CGRect CGFloat 都是基本数据类型，一次需要转换
    
    keyboardY = keyboardFrame.origin.y;
    
    CGRect frame = feedTextFied.frame;
    frame.origin.y = keyboardY - 30 -NAVIBARHEIGHT -STATUSBARHEIGHT -textHeight;
    frame.size.height = 30 + textHeight;
    
    feedTextFied.frame = frame;
    
    frame = self.feedTableView.frame;
    
    //如果tableview 的content size高度加上导航栏高度 大于键盘弹出的y 需要做上移操作
    
    CGFloat theY = self.feedTableView.contentSize.height + STATUSBARHEIGHT + NAVIBARHEIGHT -keyboardY - 30  -textHeight;
    if (theY > 0 ) {
        frame.origin.y = -(ScreenHeight - keyboardY - 30 - textHeight + NAVIBARHEIGHT);
        self.feedTableView.frame = frame;
        if (self.feedListArray.count >1) {
            [self.feedTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.feedListArray.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
        }
        
    }
    
}
- (void)textFieldFrame:(NSNotification *)notification{
    
    CGRect rect = [feedTextFied.FeedField.text boundingRectWithSize:CGSizeMake(280 *NewBasicWidth, 999) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:KFONT(16)} context:nil];
    
    if (rect.size.height >20) {
        textHeight = rect.size.height +10;
        CGRect frame = feedTextFied.FeedField.frame;
        frame.size.height = rect.size.height + 10;
        feedTextFied.FeedField.frame = frame;
        
        frame = feedTextFied.frame;
        frame.origin.y =keyboardY - 30 -NAVIBARHEIGHT -STATUSBARHEIGHT -rect.size.height -10;
        frame.size.height = 30  + rect.size.height+10;
        feedTextFied.frame = frame;
        
        frame = self.feedTableView.frame;
        
        //如果tableview 的content size高度加上导航栏高度 大于键盘弹出的y 需要做上移操作
        
        CGFloat theY = self.feedTableView.contentSize.height + STATUSBARHEIGHT + NAVIBARHEIGHT -keyboardY - 30  -textHeight;
        if (theY > 0 ) {
            frame.origin.y = -(ScreenHeight - keyboardY - 30 - textHeight+ NAVIBARHEIGHT);
            self.feedTableView.frame = frame;
            if (self.feedListArray.count >1) {
                [self.feedTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.feedListArray.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
            }
            
        }

    }else{
        textHeight = 20;
    }
}
#pragma mark-========事件======
- (void)keyboardOut{
    
    [feedTextFied.FeedField resignFirstResponder];
    CGRect frame = feedTextFied.frame;
    frame.origin.y =  ScreenHeight -NAVIBARHEIGHT -STATUSBARHEIGHT- 30 - textHeight;
    frame.size.height = 30 + textHeight;
    feedTextFied.frame = frame;
    
    frame = self.feedTableView.frame;

    //如果tableview 的content size高度加上导航栏高度 大于键盘弹出的y 需要做上移操作
    
    CGFloat theY = self.feedTableView.contentSize.height +STATUSBARHEIGHT +NAVIBARHEIGHT -keyboardY - 30  -textHeight;
    if (theY > 0 ) {
        frame.origin.y = 0;
        self.feedTableView.frame = frame;
        if (self.feedListArray.count >1) {
            [self.feedTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.feedListArray.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
        }
        
    }


}
- (void) submitAction
{
    if ([feedTextFied.FeedField isFirstResponder]) {
        [self keyboardOut];
    }
    if (!feedTextFied.FeedField.text||feedTextFied.FeedField.text.length==0) {
        [CCCommonHelp showAutoDissmissAlertView:nil msg:@"请填写您的宝贵意见"];
        return;
    }
   
    if(feedTextFied.FeedField.text.length>50)
    {
        feedTextFied.FeedField.text=[feedTextFied.FeedField.text substringToIndex:50];
    }
   
    FeedBackReplyModel *user = [[FeedBackReplyModel alloc]init];
    user.replyContent = feedTextFied.FeedField.text;
    
    NSInteger thisTime = [[NSDate date]GMTSecond] -8*60*60;
    user.replyTime = @(thisTime *1000);
    user.replyUserModel = self.feedModel.userModel;
    user.feedbackId = self.feedModel.feedbackId;
    user.replyId = @(hypotheticalId);
    user.isShowTime = YES;
    CGRect rect = [ user.replyContent boundingRectWithSize:CGSizeMake(232 *NewBasicWidth, 999) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:KFONT(16)} context:nil];
    user.replySize = CGSizeMake(rect.size.width, rect.size.height +5);
    
    __weak typeof(self)Wself = self;
   [[HotRequest shareInstance]replyFeedBackWithAccessToken:[HETUserInfo userInfo].accessToken feedbackId:self.feedModel.feedbackId replyContent:feedTextFied.FeedField.text AndSuccess:^(NSNumber *num) {
        [Wself.feedListArray addObject:user];
       [Wself resetArray];
       if (feedTextFied.FeedField.text.length>0) {
           feedTextFied.FeedField.text =@"";
       }
       textHeight = 20;
      dispatch_async(dispatch_get_main_queue(), ^{
          CGRect frame = feedTextFied.frame;
          frame.origin.y = ScreenHeight -NAVIBARHEIGHT -STATUSBARHEIGHT- 50;
          frame.size.height = 50;
          feedTextFied.frame = frame;
      });
       
       [Wself.feedTableView reloadData];

       [Wself.feedTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:Wself.feedListArray.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
       
       hypotheticalId --;
       
   } AndFaliBlock:^(NSError *error) {
       [CCCommonHelp HidHud];
       [CCCommonHelp showAutoDissmissAlertView:nil msg:error.userInfo[@"NSLocalizedDescription"]];
   }];
    
}
- (void)buttonClick:(UIButton *)sender{
    for (UIViewController *view in self.navigationController.viewControllers) {
        if ([view isKindOfClass:[FeedListViewController class]]) {
            FeedListViewController *feed = (FeedListViewController *)view;
            [feed freshData];
        }
    }
    [self.navigationController popViewControllerAnimated:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
