//
//  FeedBackProductModel.h
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/29.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FeedBackProductModel : NSObject
@property (copy,nonatomic) NSNumber *productId;// 1746,
@property (copy,nonatomic) NSNumber *devSubKeyId;// 60,
@property (copy,nonatomic) NSNumber *deviceSubtypeId;// 11001,
@property (copy,nonatomic) NSNumber *deviceTypeId;// 11,
@property (copy,nonatomic) NSNumber *developerId;// 50081,
@property (copy,nonatomic) NSNumber *productVersion;// 11,
@property (copy,nonatomic) NSString *productIcon;// http;////200.200.200.58;//8981/group1
@property (copy,nonatomic) NSNumber *bindType;// 1,
@property (copy,nonatomic) NSString *productName;// hcc-v7,
@property (copy,nonatomic) NSString *productCode;// hcc-v7vgg,
@property (copy,nonatomic) NSString *deviceKey;// 498d1e078e1f4b86bbc6767ef8e72a9c,
@property (copy,nonatomic) NSNumber *mode;// 0,
@property (copy,nonatomic) NSNumber *status;// 0,
@property (copy,nonatomic) NSString *remark;// hhhhhhhhdfgzdfhbzdfh,
@property (copy,nonatomic) NSNumber *createTime;// 1467756727000,
@property (copy,nonatomic) NSNumber *modifyTime;// 1467756727000,
@property (copy,nonatomic) NSNumber *moduleId;// null
@end
