//
//  FeedBackReplyBase.m
//  CSuperAppliances
//
//  Created by Starlueng on 2017/1/5.
//  Copyright © 2017年 starlueng. All rights reserved.
//

#import "FeedBackReplyBase.h"

@implementation FeedBackReplyBase

+(instancetype)shareInstance{
    static id base = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        //    if (!base) {
        base = [[[self class] alloc]init];
        //  }
        
    });
    return base;
}
- (instancetype)init
{
    self = [super init];
    if (self) {
        [self createBaseData];
    }
    return self;
}

- (void)createBaseData{
    NSString *dataPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    
    NSString *tablePath = [dataPath stringByAppendingPathComponent:@"replybaseSql.db"];
    
    _dataBase = [FMDatabase databaseWithPath:tablePath];
    
    [_dataBase open];
    
    NSString *sql = @"create table if not exists ReplyList (id integer primary key autoincrement not null,replyId text, feedbackId text,replyUserId text,upperReplyId text,replyContent text,replyTime text,avatar text,userId text,isShowTime text,replySizeWidth text,replySizeheight text);";
    
    [_dataBase executeUpdate:sql];
}

- (BOOL) isExistBaseDataWithCitiesModel:(FeedBackReplyModel *)model{
    NSString *sql =[NSString stringWithFormat:@"select count(*)from ReplyList where replyId='%@';",model.replyId];
    
    FMResultSet *set =[_dataBase executeQuery:sql];
    if ([set next]) {
        int c = [set intForColumnIndex:0];
        [set close];
        return c>0;
    }
    return NO;
}
- (void) addBaseDataWithCitiesModel:(FeedBackReplyModel *)model{
    BOOL isExist = [self isExistBaseDataWithCitiesModel:model];
    if (isExist) {
        return;
    }
    NSString * sql =@"insert into ReplyList (replyId,feedbackId,replyUserId,upperReplyId,replyContent,replyTime,avatar,userId,isShowTime,replySizeWidth,replySizeheight) values (?,?,?,?,?,?,?,?,?,?,?);";
    
    [_dataBase executeUpdate:sql,[NSString stringWithFormat:@"%@",model.replyId],[NSString stringWithFormat:@"%@",model.feedbackId],[NSString stringWithFormat:@"%@",model.replyUserId],[NSString stringWithFormat:@"%@",model.upperReplyId],model.replyContent,[NSString stringWithFormat:@"%@",model.replyTime],model.replyUserModel.avatar,model.replyUserModel.userId,model.isShowTime?@"1":@"0",[NSString stringWithFormat:@"%.2f",model.replySize.width],[NSString stringWithFormat:@"%.2f",model.replySize.height]];
}


- (void) deleteBaseDataWithCitiesModelWith:(NSNumber *)modelFeedId{
    
    FeedBackReplyModel *model = [[FeedBackReplyModel alloc]init];
    model.feedbackId = modelFeedId;
    BOOL isExist = [self isExistBaseDataWithCitiesModel:model];
    if (isExist) {
        NSString * sql = [NSString stringWithFormat:@"delete from ReplyList where feedbackId ='%@'",modelFeedId];
        [_dataBase executeUpdate:sql];
    }

}
- (void)deleteBaseDataWith:(NSNumber *)modelReplyId{

    NSString * sql = [NSString stringWithFormat:@"delete from ReplyList where replyId ='%@'",modelReplyId];
    [_dataBase executeUpdate:sql];
}
- (NSArray *) getAllBaseDataWith:(NSNumber *)modelFeedId{
    NSString * sql =@"select * from ReplyList";
    FMResultSet * set =[_dataBase executeQuery:sql];
    NSMutableArray * restArray = [[NSMutableArray alloc]init];
    while ([set next]) {
        NSInteger feedBackId = [set stringForColumn:@"feedbackId"].integerValue;
        
        if (feedBackId == modelFeedId.integerValue) {
            FeedBackReplyModel *model = [[FeedBackReplyModel alloc]init];
            model.feedbackId = @([set stringForColumn:@"feedbackId"].integerValue);
            model.replyId = @([set stringForColumn:@"replyId"].integerValue);
            model.replyUserId = @([set stringForColumn:@"replyUserId"].integerValue);
            model.upperReplyId = @([set stringForColumn:@"upperReplyId"].integerValue);
            model.replyTime = @([set stringForColumn:@"replyTime"].integerValue);
            model.replyContent = [set stringForColumn:@"replyContent"];
            model.replyUserModel = [[FeedBackUserModel alloc]init];
            model.replyUserModel.avatar = [set stringForColumn:@"avatar"];
            model.replyUserModel.userId = [set stringForColumn:@"userId"];
            
            NSString *isShow = [set stringForColumn:@"isShowTime"];
            model.isShowTime = isShow.integerValue;
            CGFloat width = [set stringForColumn:@"replySizeWidth"].floatValue;
            CGFloat height = [set stringForColumn:@"replySizeheight"].floatValue;
            model.replySize = CGSizeMake(width, height);
            
            [restArray addObject:model];
            
        }
    }
    return [restArray copy];
}

@end
