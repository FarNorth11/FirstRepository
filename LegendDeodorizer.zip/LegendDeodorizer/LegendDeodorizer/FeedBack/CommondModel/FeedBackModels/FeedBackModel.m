//
//  FeedBackModel.m
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/29.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "FeedBackModel.h"
#import "FeedBackReplyModel.h"
@implementation FeedBackModel

- (void)setValue:(id)value forKey:(NSString *)key{
    
    if ([key isEqualToString:@"user"]) {
        
        FeedBackUserModel *user = [[FeedBackUserModel alloc]init];
        [user setValuesForKeysWithDictionary:value];
        [super setValue:user forKey:@"userModel"];
    }else if ([key isEqualToString:@"product"]){
        
        FeedBackProductModel *user = [[FeedBackProductModel alloc]init];
        [user setValuesForKeysWithDictionary:value];
        [super setValue:user forKey:@"productModel"];
        
    }else if ([key isEqualToString:@"feedbackReplies"]){
        
        NSArray *list = (NSArray *)value;
        NSMutableArray *mutableArray = [[NSMutableArray alloc]init];
        if (list.count >0) {
            
            for (NSDictionary *dic in list) {
                FeedBackReplyModel *user = [[FeedBackReplyModel alloc]init];
                [user setValuesForKeysWithDictionary:dic];
                [mutableArray addObject:user];
            }
            [super setValue:mutableArray forKey:key];
        }else{
            
            [super setValue:value forKey:key];
        }
    
    }else{
        [super setValue:value forKey:key];
    }
    
}
- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}
@end
