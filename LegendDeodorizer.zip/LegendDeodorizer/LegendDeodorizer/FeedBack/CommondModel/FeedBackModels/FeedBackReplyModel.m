//
//  FeedBackReplyModel.m
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/30.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "FeedBackReplyModel.h"

@implementation FeedBackReplyModel
- (void)setValue:(id)value forKey:(NSString *)key{
    
    if ([key isEqualToString:@"replyUser"]&&[value isKindOfClass:[NSDictionary class]]) {
        
        NSDictionary *valueDic = (NSDictionary *)value;
        self.replyUserModel = [[FeedBackUserModel alloc]init];
        [self.replyUserModel setValuesForKeysWithDictionary:valueDic];
        
    }else if ([key isEqualToString:@"replyContent"]){
        
        NSString * valueStr = (NSString *)value;
        CGRect rect = [valueStr boundingRectWithSize:CGSizeMake(232 *NewBasicWidth, 999) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:KFONT(16)} context:nil];
        self.replySize = CGSizeMake(rect.size.width, rect.size.height +5);
        
        [super setValue:value forKey:key];
    }else{
        [super setValue:value forKey:key];
    }
    
}
- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}
@end
