//
//  FeedBackProductModel.m
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/29.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "FeedBackProductModel.h"

@implementation FeedBackProductModel
- (void)setValue:(id)value forKey:(NSString *)key{
    
    [super setValue:value forKey:key];
}
- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}
@end
