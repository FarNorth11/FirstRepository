//
//  FeedBackReplyBase.h
//  CSuperAppliances
//
//  Created by Starlueng on 2017/1/5.
//  Copyright © 2017年 starlueng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"
#import "FeedBackReplyModel.h"
@interface FeedBackReplyBase : NSObject
{
    FMDatabase *_dataBase;
}
/**
 *  获取单列
 *
 *  @return 单例
 */
+(instancetype)shareInstance;

/**
 *  是否存在数据库纪录
 *
 *  @param class 根据model
 *  @param sql   数据库语言
 *
 *  @return 是否
 */

- (BOOL) isExistBaseDataWithCitiesModel:(FeedBackReplyModel *)model;

- (void) addBaseDataWithCitiesModel:(FeedBackReplyModel *)model;

- (void) deleteBaseDataWithCitiesModelWith:(NSNumber *)modelFeedId;//删除对话框

- (void)deleteBaseDataWith:(NSNumber *)modelReplyId;//删除单一对话

- (NSArray *) getAllBaseDataWith:(NSNumber *)modelFeedId;


@end
