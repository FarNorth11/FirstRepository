//
//  FeedBackUserModel.h
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/29.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FeedBackUserModel    : NSObject

@property (copy,nonatomic) NSString *  userId      ;// 10579,
@property (copy,nonatomic) NSString *  userName      ;//    果果   ,
@property (copy,nonatomic) NSNumber *  sex      ;// 2,
@property (copy,nonatomic) NSNumber *  birthday      ;// 1451577600000,
@property (copy,nonatomic) NSNumber *  weight      ;// 48000,
@property (copy,nonatomic) NSNumber *  height      ;// 163,
@property (copy,nonatomic) NSString *  avatar      ;//    http   ;////200.200.200.58   ;/
@property (copy,nonatomic) NSString *  city      ;//       ,
@property (copy,nonatomic) NSString *  address      ;//       ,
@property (copy,nonatomic) NSNumber *  status      ;// 1,
@property (copy,nonatomic) NSString *  keyword      ;// null,
@property (copy,nonatomic) NSString *  headimgurl      ;// null,
@property (copy,nonatomic) NSString *  phone      ;//    15617420290   ,
@property (copy,nonatomic) NSString *  email      ;// null,
@property (copy,nonatomic) NSNumber *  createTime      ;// 1473202333000


@end
