//
//  FeedBackReplyModel.h
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/30.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FeedBackUserModel.h"
@interface FeedBackReplyModel : NSObject

@property (copy,nonatomic) NSNumber *replyId;// 意见反馈回复标识
@property (copy,nonatomic) NSNumber *feedbackId;// 意见反馈标识
@property (copy,nonatomic) NSNumber *replyUserId;// 1,回复人
@property (copy,nonatomic) NSNumber *upperReplyId;// 0,回复谁的（回复的哪条记录）
@property (copy,nonatomic) NSString *replyContent;// 回复反馈628,
@property (copy,nonatomic) NSNumber *replyTime;// 1482893467000,回复时间
@property (strong,nonatomic) FeedBackUserModel *replyUserModel;

@property (assign,nonatomic) CGSize replySize;//回复尺寸
@property (assign,nonatomic) BOOL isShowTime;
@end
