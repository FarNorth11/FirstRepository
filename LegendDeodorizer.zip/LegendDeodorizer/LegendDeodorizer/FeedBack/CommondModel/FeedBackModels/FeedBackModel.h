//
//  FeedBackModel.h
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/29.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FeedBackUserModel.h"
#import "FeedBackProductModel.h"

@interface FeedBackModel : NSObject

@property (copy,nonatomic) NSNumber *feedbackId;//意见反馈标识

@property (strong,nonatomic) FeedBackUserModel *userModel;

@property (copy,nonatomic) NSNumber *feedbackTime;//反馈时间

@property (copy,nonatomic) NSNumber *status;//状态：0-删除 1-未处理 2-已回复 3-已忽略

@property (copy,nonatomic) NSNumber *source;//来源(1-web；2-app；3-微信)

@property (copy,nonatomic) NSNumber *sourceId;//app应用标识

@property (strong,nonatomic)FeedBackProductModel *productModel;

@property (copy,nonatomic) NSNumber *feedbackType;//问题类型（1-APP问题，2-硬件设备，3-配网相关，4-意见建议 ，5 -其它）

@property (copy,nonatomic)NSArray *feedbackReplies;

@property (copy,nonatomic) NSString *contact;//联系方式

@property (copy,nonatomic) NSString *content;//反馈内容

@property (assign,nonatomic) BOOL showTailView;//是否展示底部发送时间
@end
