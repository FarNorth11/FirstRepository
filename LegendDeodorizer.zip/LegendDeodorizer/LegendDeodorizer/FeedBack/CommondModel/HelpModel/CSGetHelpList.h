//
//  CSGetHelpList.h
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/22.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "HETRequest.h"

@interface CSGetHelpList : HETRequest
- (instancetype)initWithpageIndex:(NSInteger )pageIndex pageRows:(NSInteger )pageRows;

- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock;
@end
