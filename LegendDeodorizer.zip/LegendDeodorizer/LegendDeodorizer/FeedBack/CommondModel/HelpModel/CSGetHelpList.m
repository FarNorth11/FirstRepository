//
//  CSGetHelpList.m
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/22.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "CSGetHelpList.h"
#import "HETRequest+Private.h"
#import "HETDeviceGetBindRequest.h"
@implementation CSGetHelpList
{
    
    NSInteger _pageIndex;
    NSInteger _pageRows;
}
- (instancetype)initWithpageIndex:(NSInteger )pageIndex pageRows:(NSInteger )pageRows{
    
    self = [super init];
    if (self) {
        
        _pageRows =pageRows;
        _pageIndex = pageIndex;
    }
    
    return self;
    
}
- (YTKRequestMethod)requestMethod{
    
    return YTKRequestMethodGet;
}

-(BOOL)isHttpsType{
    
    return YES;
}

-(NSString *)requestUrl{
    
    return [@"/v1/app/cms" stringByAppendingString: @"/help/getHelpList"];
}

- (id)requestArgument{
    
    
    return @{
             @"pageIndex":@(_pageIndex),
             @"pageRows":@(_pageRows)
             
             };
}

- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock {
    
    [super startWithSuccessBlockDictionaryParameter:successBlock
                                            failure:failureBlock];
}

@end
