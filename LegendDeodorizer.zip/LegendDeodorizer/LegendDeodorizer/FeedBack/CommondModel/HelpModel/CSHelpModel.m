//
//  CSHelpModel.m
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/22.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "CSHelpModel.h"

@implementation CSHelpModel
- (void)setValue:(id)value forKey:(NSString *)key{
   
    [super setValue:value forKey:key];
    
}
- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}
@end
