//
//  CSGetDetailHelp.m
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/22.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "CSGetDetailHelp.h"
#import "HETRequest+Private.h"
#import "HETDeviceGetBindRequest.h"
@implementation CSGetDetailHelp
{
    
    NSNumber  *_faqId;

}
- (instancetype)initWithfaqId:(NSNumber *)faqId{
    
    self = [super init];
    if (self) {
        
        _faqId =faqId;
 
    }
    
    return self;
    
}
- (YTKRequestMethod)requestMethod{
    
    return YTKRequestMethodGet;
}

-(BOOL)isHttpsType{
    
    return YES;
}

-(NSString *)requestUrl{
    
    return [@"/v1/app/cms" stringByAppendingString: @"/help/getHelp"];
}

- (id)requestArgument{
    
    
    return @{
             @"faqId":_faqId
         
             };
}

- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock {
    
    [super startWithSuccessBlockDictionaryParameter:successBlock
                                            failure:failureBlock];
}


@end
