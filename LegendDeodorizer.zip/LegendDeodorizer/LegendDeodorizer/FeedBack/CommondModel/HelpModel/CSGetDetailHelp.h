//
//  CSGetDetailHelp.h
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/22.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "HETRequest.h"

@interface CSGetDetailHelp : HETRequest
- (instancetype)initWithfaqId:(NSNumber *)faqId;
- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock;
@end
