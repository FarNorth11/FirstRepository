//
//  CSHelpModel.h
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/22.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CSHelpModel : NSObject

@property (copy ,nonatomic) NSNumber *faqId;//3,
@property (copy ,nonatomic) NSString *title;//喜临门打不开,
@property (copy ,nonatomic) NSString *content;//,
@property (copy ,nonatomic) NSNumber *top;//0,
@property (copy ,nonatomic) NSString *createTime;//2015-12-06 09;//18;//13
@end
