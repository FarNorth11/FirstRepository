//
//  FeedBackCell.m
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/30.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "FeedBackCell.h"
#import "UIImageView+WebCache.h"
#import "NSDate+SSToolkitAdditions.h"
@implementation FeedBackCell
{
    UIImageView *backGdView;//底部气泡
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        [self createUI];
    }
    return self;
}
- (void)createUI{
    
    _iconImageView = [[UIImageView alloc]init];
    _iconImageView.layer.cornerRadius = 20 *NewBasicHeight;
    _iconImageView.layer.masksToBounds = YES;
    _iconImageView.contentMode = UIViewContentModeScaleAspectFit;
    [self.contentView addSubview:_iconImageView];
    
    backGdView = [[UIImageView alloc]init];
    [self.contentView addSubview:backGdView];
    
    _contentLabel = [UILabel setLabelWith:@"" AndFont:KFONT(16) AndIsNumberOfLines:YES AndtextColor:KCOLOR(@"323232") AndFrame:CGRectZero AndAlignment:NSTextAlignmentLeft];
    [backGdView addSubview:_contentLabel];
    
    _showTimeLabel = [UILabel setLabelWith:@"" AndFont:KFONT(12) AndIsNumberOfLines:NO AndtextColor:WHITECOLOR AndFrame:CGRectZero AndAlignment:NSTextAlignmentCenter];
    _showTimeLabel.layer.cornerRadius = 5;
    _showTimeLabel.layer.masksToBounds = YES;
    _showTimeLabel.backgroundColor = KCOLOR(@"cecece");
    [self.contentView addSubview:_showTimeLabel];

}
- (void)fillCellWith:(FeedBackReplyModel *)feedModel isShow:(BOOL)show{
     NSString *feedUserId = [NSString stringWithFormat:@"%@",feedModel.replyUserModel.userId];
    if ([feedUserId isEqualToString:[HETUserInfo userInfo].userId]) {
        _iconImageView.layer.cornerRadius = 20 *NewBasicHeight;
        _iconImageView.layer.masksToBounds = YES;
    }else{
        _iconImageView.layer.cornerRadius = 0;
        _iconImageView.layer.masksToBounds = NO;
    }
    
    if (show) {
        _showTimeLabel.hidden = NO;
        NSString *feedTime = [NSString stringWithFormat:@"%@",feedModel.replyTime];
        NSString *needTime = [feedTime substringToIndex:feedTime.length -3];
        NSString *currentTime = [NSDate getNeedTimeFrom:needTime.integerValue isShowSecond:YES];
        NSString *todayStr = [[NSDate date]LocalDayISO8601String];
        NSString *currentDayStr = [currentTime componentsSeparatedByString:@" "].firstObject;
        NSString *currentSecStr = [currentTime componentsSeparatedByString:@" "].lastObject;
        //如果时间早于今天 全部显示时间
        if ([currentDayStr compare:todayStr] == NSOrderedAscending) {
            
            CGSize size = [currentTime sizeWithAttributes:@{NSFontAttributeName:KFONT(12)}];
            _showTimeLabel.frame = CGRectMake((ScreenWidth -size.width-12)/2, 14 *NewBasicHeight, size.width +12, 20*NewBasicHeight);
            _showTimeLabel.text = currentTime;
            if ([feedUserId isEqualToString:[HETUserInfo userInfo].userId]) {

                _iconImageView.frame = CGRectMake(ScreenWidth -10 *NewBasicWidth - 40 *NewBasicHeight,CGRectGetMaxY(_showTimeLabel.frame)+ 14 *NewBasicHeight, 40 *NewBasicHeight, 40 *NewBasicHeight);
                backGdView.frame = CGRectMake(ScreenWidth - 40 *NewBasicWidth - CGRectGetWidth(_iconImageView.frame) -feedModel.replySize.width ,CGRectGetMaxY(_showTimeLabel.frame)+ 14 *NewBasicHeight, feedModel.replySize.width +26 *NewBasicWidth, feedModel.replySize.height +24 *NewBasicHeight);
                backGdView.image = [[UIImage imageNamed:@"UserFeed"]resizableImageWithCapInsets:UIEdgeInsetsMake(28, 10, CGRectGetHeight(backGdView.frame)-28, CGRectGetWidth(backGdView.frame)-10)];
                _contentLabel.frame = CGRectMake(10 *NewBasicWidth, 12 *NewBasicHeight, feedModel.replySize.width, feedModel.replySize.height);
            }else{
          
                _iconImageView.frame = CGRectMake(10 *NewBasicWidth ,CGRectGetMaxY(_showTimeLabel.frame)+ 14 *NewBasicHeight, 40 *NewBasicHeight, 40 *NewBasicHeight);
                backGdView.frame = CGRectMake( 6 *NewBasicWidth + CGRectGetMaxX(_iconImageView.frame)  ,CGRectGetMaxY(_showTimeLabel.frame)+ 14 *NewBasicHeight, feedModel.replySize.width +26 *NewBasicWidth, feedModel.replySize.height +24 *NewBasicHeight);
                
                backGdView.image = [[UIImage imageNamed:@"FeedBack"]resizableImageWithCapInsets:UIEdgeInsetsMake(28, 10,CGRectGetHeight(backGdView.frame)-28, CGRectGetWidth(backGdView.frame)-10)];
                _contentLabel.frame = CGRectMake(16 *NewBasicWidth, 12 *NewBasicHeight, feedModel.replySize.width, feedModel.replySize.height);
            }

        }else{
            
            if (feedModel.isShowTime) {
                CGSize size = [currentSecStr sizeWithAttributes:@{NSFontAttributeName:KFONT(12)}];
                _showTimeLabel.frame = CGRectMake((ScreenWidth -size.width-12)/2, 14 *NewBasicHeight, size.width +12, 20*NewBasicHeight);
                 _showTimeLabel.text = currentSecStr;
            }else{
                _showTimeLabel.frame = CGRectZero;
            }
            
            if ([feedUserId isEqualToString:[HETUserInfo userInfo].userId]) {
                
                _iconImageView.frame = CGRectMake(ScreenWidth -10 *NewBasicWidth - 40 *NewBasicHeight,CGRectGetMaxY(_showTimeLabel.frame)+ 14 *NewBasicHeight, 40 *NewBasicHeight, 40 *NewBasicHeight);
                backGdView.frame = CGRectMake(ScreenWidth - 40 *NewBasicWidth - CGRectGetWidth(_iconImageView.frame) -feedModel.replySize.width ,CGRectGetMaxY(_showTimeLabel.frame)+ 14 *NewBasicHeight, feedModel.replySize.width +26 *NewBasicWidth, feedModel.replySize.height +24 *NewBasicHeight);
                backGdView.image = [[UIImage imageNamed:@"UserFeed"]resizableImageWithCapInsets:UIEdgeInsetsMake(28, 10, CGRectGetHeight(backGdView.frame)-28, CGRectGetWidth(backGdView.frame)-10)];
                _contentLabel.frame = CGRectMake(10 *NewBasicWidth, 12 *NewBasicHeight, feedModel.replySize.width, feedModel.replySize.height);
            }else{
                
                
                _iconImageView.frame = CGRectMake(10 *NewBasicWidth ,CGRectGetMaxY(_showTimeLabel.frame)+  14 *NewBasicHeight, 40 *NewBasicHeight, 40 *NewBasicHeight);
                backGdView.frame = CGRectMake( 6 *NewBasicWidth + CGRectGetMaxX(_iconImageView.frame)  ,CGRectGetMaxY(_showTimeLabel.frame)+ 14 *NewBasicHeight, feedModel.replySize.width +26 *NewBasicWidth, feedModel.replySize.height +24 *NewBasicHeight);
                
                backGdView.image = [[UIImage imageNamed:@"FeedBack"]resizableImageWithCapInsets:UIEdgeInsetsMake(28, 10,CGRectGetHeight(backGdView.frame)-28, CGRectGetWidth(backGdView.frame)-10)];
                _contentLabel.frame = CGRectMake(16 *NewBasicWidth, 12 *NewBasicHeight, feedModel.replySize.width, feedModel.replySize.height);
            }
        }

    }else{
        _showTimeLabel.hidden = YES;
        if ([feedUserId isEqualToString:[HETUserInfo userInfo].userId]) {
            
            _iconImageView.frame = CGRectMake(ScreenWidth -10 *NewBasicWidth - 40 *NewBasicHeight, 14 *NewBasicHeight, 40 *NewBasicHeight, 40 *NewBasicHeight);
            backGdView.frame = CGRectMake(ScreenWidth - 40 *NewBasicWidth - CGRectGetWidth(_iconImageView.frame) -feedModel.replySize.width , 12 *NewBasicHeight, feedModel.replySize.width +26 *NewBasicWidth, feedModel.replySize.height +24 *NewBasicHeight);
            backGdView.image = [[UIImage imageNamed:@"UserFeed"]resizableImageWithCapInsets:UIEdgeInsetsMake(28, 10, CGRectGetHeight(backGdView.frame)-28, CGRectGetWidth(backGdView.frame)-10)];
            _contentLabel.frame = CGRectMake(10 *NewBasicWidth, 12 *NewBasicHeight, feedModel.replySize.width, feedModel.replySize.height);
        }else{
            
            _iconImageView.frame = CGRectMake(10 *NewBasicWidth , 14 *NewBasicHeight, 40 *NewBasicHeight, 40 *NewBasicHeight);
            backGdView.frame = CGRectMake( 6 *NewBasicWidth + CGRectGetMaxX(_iconImageView.frame)  , 12 *NewBasicHeight, feedModel.replySize.width +26 *NewBasicWidth, feedModel.replySize.height +24 *NewBasicHeight);
            
            backGdView.image = [[UIImage imageNamed:@"FeedBack"]resizableImageWithCapInsets:UIEdgeInsetsMake(28, 10,CGRectGetHeight(backGdView.frame)-28, CGRectGetWidth(backGdView.frame)-10)];
            _contentLabel.frame = CGRectMake(16 *NewBasicWidth, 12 *NewBasicHeight, feedModel.replySize.width, feedModel.replySize.height);
        }

    }
    if ([feedUserId isEqualToString:[HETUserInfo userInfo].userId]) {
        [_iconImageView sd_setImageWithURL:[NSURL URLWithString:feedModel.replyUserModel.avatar] placeholderImage:[UIImage imageNamed:@"imageLoading"]];
    }else{
        _iconImageView.image = [UIImage imageNamed:@"serverIcon"];
    }
    
    _contentLabel.text = feedModel.replyContent;
    
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
