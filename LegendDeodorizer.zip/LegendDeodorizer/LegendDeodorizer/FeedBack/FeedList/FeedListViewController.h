//
//  FeedListViewController.h
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/30.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "RootViewController.h"

@interface FeedListViewController : RootViewController

- (void)freshData;
@end
