//
//  FeedListViewController.m
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/30.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "FeedListViewController.h"
#import "FeedBackCell.h"
#import "FeedBackUserModel.h"
#import "FeedBackModel.h"
#import "UIImageView+WebCache.h"
#import "NSDate+SSToolkitAdditions.h"
#import "HotRequest.h"
#import "BaseAlert.h"
#import "FeedbackViewController.h"
#import "FeedDetailViewController.h"

#import "UIImage+Gif.h"
#import "MJRefreshBackGifFooter.h"
#import "MJRefreshGifHeader.h"

@interface FeedListViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (strong,nonatomic) UITableView * feedTableView;

@property (strong,nonatomic) NSMutableArray *feedListArray;

@end

@implementation FeedListViewController
{
    NSInteger currentPage;//当前页(默认从第一页开始)
    NSInteger pageCount;//总页数
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self createNaviView];
    [self.view addSubview:self.feedTableView];
    
    [self getHotRequest];
    // Do any additional setup after loading the view.
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    AppDelegate *app =(AppDelegate *)[UIApplication sharedApplication].delegate;
    app.root.tabBar.hidden = YES;
}
#pragma mark-===============UI===============
- (void)createNaviView{

    NSString *title = @"意见反馈";
    CGSize titleSize = [UIConfig sizeWithString:title Font:[UIFont systemFontOfSize:18] maxSize:CGSizeMake(MAXFLOAT, MAXFLOAT)];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(ScreenWidth_2-titleSize.width/2, 0, titleSize.width, NAVIBARHEIGHT)];
    titleLabel.text = title;
    titleLabel.textColor = [UIColor blackColor];
    titleLabel.font = [UIFont systemFontOfSize:17];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    self.navigationItem.titleView = titleLabel;
    
    UIFont *btnFont = [UIFont systemFontOfSize:17];
    CGSize btnSize = [UIConfig sizeWithString:@"添加" Font:btnFont maxSize:CGSizeMake(MAXFLOAT, MAXFLOAT)];
    UIButton *rightBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [rightBtn setTitle:@"添加" forState:UIControlStateNormal];
    rightBtn.titleLabel.font = btnFont;
    [rightBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    rightBtn.frame = (CGRect){{0,0},btnSize};
    [rightBtn addTarget:self action:@selector(addAction) forControlEvents:UIControlEventTouchUpInside];
    [self.navigationItem setRightBarButtonItem:[[UIBarButtonItem alloc] initWithCustomView:rightBtn]];
    
    
}
- (UITableView *)feedTableView{
    
    if (!_feedTableView) {
        _feedTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight-STATUSBARHEIGHT) style:UITableViewStylePlain];
        _feedTableView.dataSource = self;
        _feedTableView.delegate = self;
        _feedTableView.backgroundColor = KCOLOR(@"f4f4f8");
        _feedTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [_feedTableView registerClass:[FeedBackCell class] forCellReuseIdentifier:@"cell"];
        
        @weakify(self);
        MJRefreshBackGifFooter *footer = [MJRefreshBackGifFooter footerWithRefreshingBlock:^{
            @strongify(self);
            
            [self getMoreRequest];
        }];
        footer.automaticallyHidden = YES;
        UIImage *xiaoC_refresh = [UIImage sd_animatedGIFNamed:@"XiaoC_loading"];
        [footer setImages:xiaoC_refresh.images forState:MJRefreshStateIdle];
        [footer setImages:xiaoC_refresh.images forState:MJRefreshStatePulling];
        [footer setImages:xiaoC_refresh.images forState:MJRefreshStateRefreshing];
        [footer setTitle:@"正在获取最新数据!" forState:MJRefreshStateRefreshing];
        [footer setTitle:@"没有更多数据了!" forState:MJRefreshStateNoMoreData];
        self.feedTableView.footer = footer;
        
        MJRefreshGifHeader *header = [MJRefreshGifHeader headerWithRefreshingBlock:^{
            @strongify(self);
            
            [self getHotRequest];
        }];
        
        [header setImages:xiaoC_refresh.images forState:MJRefreshStateIdle];
        [header setImages:xiaoC_refresh.images forState:MJRefreshStatePulling];
        [header setImages:xiaoC_refresh.images forState:MJRefreshStateRefreshing];
        [header setTitle:@"正在获取最新数据!" forState:MJRefreshStateRefreshing];
        [header setTitle:@"没有更多数据了!" forState:MJRefreshStateNoMoreData];
        header.lastUpdatedTimeLabel.hidden = YES;
        self.feedTableView.header = header;
    }
    return _feedTableView;
}
#pragma mark-=============getHotRequest=====
- (void)getHotRequest{
    if (!self.feedListArray) {
        self.feedListArray = [[NSMutableArray alloc]init];
    }else{
        [self.feedListArray removeAllObjects];
    }
    currentPage = 1;
   
    [self startRequest];
}
- (void)getMoreRequest{
    if (pageCount>0&&currentPage<pageCount) {
        
        currentPage++;
        [self startRequest];
        
    }else{
    [self.feedTableView.footer endRefreshing];
    }

}
- (void)startRequest{
    
    __weak typeof(self)Wself = self;
    [[HotRequest shareInstance]getFeedBackListWithAccessToken:[HETUserInfo userInfo].accessToken pageIndex:currentPage pageRows:20 AndSuccess:^(NSDictionary *dictValue) {
        
        if ([dictValue.allKeys containsObject:@"pager"]) {
            pageCount =  [dictValue[@"pager"][@"totalPages"]integerValue];
        }
        if ([dictValue.allKeys containsObject:@"list"]) {
            NSArray *list = dictValue[@"list"];
            if (list.count >0) {
                
                for (NSInteger i = 0; i<list.count; i++) {
                    NSDictionary *replyDic = list[i];
                    FeedBackModel *model = [[FeedBackModel alloc]init];
                    [model setValuesForKeysWithDictionary:replyDic];
                    //如果回复内容为空，将第一条加进去
                    if (model.feedbackReplies.count ==0) {
                        FeedBackReplyModel *user = [[FeedBackReplyModel alloc]init];
                        user.replyContent = model.content;
                        user.replyTime = model.feedbackTime;
                        user.replyUserModel = model.userModel;
                        
                        CGRect rect = [ model.content boundingRectWithSize:CGSizeMake(232 *NewBasicWidth, 999) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:KFONT(16)} context:nil];
                        user.replySize = CGSizeMake(rect.size.width, rect.size.height +5);
                        model.feedbackReplies = @[user];
                        model.showTailView = NO;
                    }else if (model.feedbackReplies.count ==1){
                        FeedBackReplyModel *userone = model.feedbackReplies.firstObject;
                        
                        FeedBackReplyModel *user = [[FeedBackReplyModel alloc]init];
                        user.replyContent = model.content;
                        user.replyTime = model.feedbackTime;
                        user.replyUserModel = model.userModel;
                        
                        CGRect rect = [ model.content boundingRectWithSize:CGSizeMake(232 *NewBasicWidth, 999) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:KFONT(16)} context:nil];
                        user.replySize = CGSizeMake(rect.size.width, rect.size.height +5);
                        //如果有客服回复，显示2条信息，用户客服，否则单一显示用户
                        if (![userone.replyUserModel.userId isEqualToString: [HETUserInfo userInfo].userId]) {
                           
                            
                            model.feedbackReplies = @[user,userone];
                           
                            model.showTailView = YES;
                        }else{
                            model.feedbackReplies = @[userone];
                            
                            model.showTailView = NO;
                        }

                    }
                    else{
                        //存在返回2条数据：为1条客服，1条用户，按照时间排序
                        NSMutableArray *mutableArray = [NSMutableArray arrayWithArray:model.feedbackReplies];
                        
                        model.showTailView = NO;
                        for (FeedBackReplyModel *user in mutableArray) {
                           
                            if (![user.replyUserModel.userId isEqualToString: [HETUserInfo userInfo].userId]) {
                                
                                model.showTailView = YES;
                            }
                          
                        }
                        if (model.showTailView) {
                            FeedBackReplyModel *userF = mutableArray.firstObject;
                            FeedBackReplyModel *userT = mutableArray[1];
                            if (userF.replyTime.integerValue<userT.replyTime.integerValue) {
                                model.feedbackReplies = @[userF,userT];
                            }else{
                                model.feedbackReplies = @[userT,userF];
                            }
                            //数组倒序
                          
                        }else{
                            FeedBackReplyModel *user = mutableArray.firstObject;
                            model.feedbackReplies = @[user];
                        }
                        
                    }
                    [Wself.feedListArray addObject:model];
                }
            }
        }
        [Wself.feedTableView.header endRefreshing];
        [Wself.feedTableView.footer endRefreshing];
        [Wself.feedTableView reloadData];
    } AndFaliBlock:^(NSError *error) {
        [Wself.feedTableView.header endRefreshing];
        [Wself.feedTableView.footer endRefreshing];
        NSLog(@"%@",error);
    }];

}
#pragma mark-=============action=======
- (void)addAction{

    FeedbackViewController *feed = [[FeedbackViewController alloc]init];
    [self.navigationController pushViewController:feed animated:YES];
}
- (void)delete:(UILongPressGestureRecognizer *)sender{
    NSInteger section;
    if ([sender.view isKindOfClass:[FeedBackCell class]]) {
        FeedBackCell *cell = (FeedBackCell *)sender.view;
        section = [_feedTableView indexPathForCell:cell].section;
    }else{
        section = sender.view.tag -viewTag;
    }

    __weak typeof(self)Wself = self;
    [[BaseAlert shareInstance]alertWithAlertStyle:AlertStyleAlert title:@"是否要删除反馈信息？" message:nil cancelBtnTitle:@"取消" buttonList:@[@"确定"] AndSelectButtonAction:^(NSNumber *num) {
        if (num.integerValue == 1) {
            if (Wself.feedListArray.count > section) {
                FeedBackModel *model = Wself.feedListArray[section];
                [[HotRequest shareInstance]delFeedBackWithAccessToken:[HETUserInfo userInfo].accessToken feedbackId:model.feedbackId AndSuccess:^(NSNumber *num) {
                    
                    [Wself.feedListArray removeObjectAtIndex:section];
                    [Wself.feedTableView reloadData];
                    
                } AndFaliBlock:^(NSError *error) {
                    NSLog(@"%@",error);
                }];
                
               
            }

        }
    }];
    
    
}
- (void)TapAction:(UITapGestureRecognizer *)sender{
    if (self.feedListArray.count > sender.view.tag -viewTag) {
        FeedBackModel *replyModel = self.feedListArray[ sender.view.tag -viewTag];
        
        FeedDetailViewController * detail = [[FeedDetailViewController alloc]init];
        detail.feedModel = replyModel;
        [self.navigationController pushViewController:detail animated:YES];
    }

}
- (void)freshData{
    
    [self.feedTableView.header beginRefreshing];
}
#pragma mark-=============UITableViewDelegate,UITableViewDataSource=====
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.feedListArray.count;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (self.feedListArray.count > section) {
        
        FeedBackModel *replyModel = self.feedListArray[section];
        NSArray *replyArray = replyModel.feedbackReplies;
        return replyArray.count;
    }else{
        return 0;
    }

}
- (CGFloat) tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    
    return 88 *NewBasicHeight;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.feedListArray.count > indexPath.section) {
        
        FeedBackModel *replyModel = self.feedListArray[indexPath.section];
        NSArray *replyArray = replyModel.feedbackReplies;
       
        if (replyArray.count > indexPath.row) {
            
            FeedBackReplyModel *replyModel = replyArray[indexPath.row];
            
            return replyModel.replySize.height +38 *NewBasicHeight;

        }else{
            return 0;
        }
        
    }else{
        return 0;
    }
    
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
     FeedBackModel *replyModel = self.feedListArray[section];
    if (replyModel.showTailView) {
        
        return 26 *NewBasicHeight;
    }else{
        return 0;
    }

}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    FeedBackCell *Cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    Cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if (self.feedListArray.count > indexPath.section) {
        
        FeedBackModel *replyModel = self.feedListArray[indexPath.section];
        NSArray *replyArray = replyModel.feedbackReplies;
        if (replyArray.count > indexPath.row) {
             FeedBackReplyModel *replyModel = replyArray[indexPath.row];
            [Cell fillCellWith:replyModel isShow:NO];
        }
    }
    
    UILongPressGestureRecognizer *longTap = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(delete:)];
    [Cell addGestureRecognizer:longTap];
    return Cell;
}
static NSInteger const viewTag = 50;//设置每个view的tag
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if (self.feedListArray.count > section) {
        FeedBackModel *replyModel = self.feedListArray[section];
        
       
        UIView *headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 88 *NewBasicHeight)];
        headView.tag = viewTag + section;
        UIView *contentView = [[UIView alloc]initWithFrame:CGRectMake(0, 16 *NewBasicHeight, ScreenWidth, 72 *NewBasicHeight)];
        [headView addSubview:contentView];
        contentView.backgroundColor = WHITECOLOR;
        contentView.layer.borderColor = KCOLOR(@"e6e6e6").CGColor;
        contentView.layer.borderWidth = SINGLE_LINE_WIDTH;
        
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(16 * NewBasicWidth, 8 *NewBasicHeight, 56 *NewBasicHeight, 56 *NewBasicHeight)];
        imageView.contentMode = UIViewContentModeScaleAspectFit;
   
        [contentView addSubview:imageView];
        
        NSString *itemStr;
        NSArray *files = @[@"APP使用",@"硬件设备",@"配网相关",@"意见建议",@"其它"];
        if (replyModel.feedbackType.integerValue ==2) {
            [imageView sd_setImageWithURL:[NSURL URLWithString:replyModel.productModel.productIcon] placeholderImage:[UIImage imageNamed:@"imageLoading"]];
            itemStr = replyModel.productModel.productName;
        }else{
            imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"FeedType_%@",replyModel.feedbackType]];
            if (replyModel.feedbackType.integerValue< files.count) {
                itemStr = files[replyModel.feedbackType.integerValue -1];
            }else{
                itemStr = files.firstObject;
            }
            
        }
        
        UILabel *itemLabel = [UILabel setLabelWith:itemStr AndFont:KFONT(16) AndIsNumberOfLines:YES AndtextColor:KCOLOR(@"323232") AndFrame:CGRectMake(CGRectGetMaxX(imageView.frame) + 12 *NewBasicWidth, (72 *NewBasicHeight - 18)/2, ScreenWidth -CGRectGetMaxX(imageView.frame) - 12 *NewBasicWidth, 18) AndAlignment:NSTextAlignmentLeft];
        
        [contentView addSubview:itemLabel];
        
        headView.userInteractionEnabled = YES;
        UILongPressGestureRecognizer *longTap = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(delete:)];
        [headView addGestureRecognizer:longTap];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(TapAction:)];
        [headView addGestureRecognizer:tap];
        return headView;
        
    }else{
        return nil;
    }
    
    
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
  
    if (self.feedListArray.count > section) {
        FeedBackModel *replyModel = self.feedListArray[section];
        NSString *currentTime;
        if (replyModel.feedbackReplies.count >0) {
            FeedBackReplyModel *reModel = replyModel.feedbackReplies.lastObject;
            NSString *feedTime = [NSString stringWithFormat:@"%@",reModel.replyTime];
            NSString *needTime = [feedTime substringToIndex:feedTime.length -3];
            currentTime = [NSDate getNeedTimeFrom:needTime.integerValue isShowSecond:YES];
        }else{
            NSString *feedTime = [NSString stringWithFormat:@"%@",replyModel.feedbackTime];
            NSString *needTime = [feedTime substringToIndex:feedTime.length -3];
            currentTime = [NSDate getNeedTimeFrom:needTime.integerValue isShowSecond:YES];
        }
        
        UIView *footView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 26 *NewBasicHeight)];
        footView.backgroundColor = WHITECOLOR;
        
        UILabel *label = [UILabel setLabelWith:currentTime AndFont:KFONT(12) AndIsNumberOfLines:YES AndtextColor:KCOLOR(@"848484") AndFrame:CGRectMake(16 *NewBasicWidth, 0, ScreenWidth - 16 *NewBasicWidth, 14) AndAlignment:NSTextAlignmentLeft];
        [footView addSubview:label];
        
        CALayer *lineLayer = [[CALayer alloc]init];
        lineLayer.frame = CGRectMake(0, 26 *NewBasicHeight-SINGLE_LINE_WIDTH, ScreenWidth, SINGLE_LINE_WIDTH);
        lineLayer.backgroundColor = KCOLOR(@"c6c6c6").CGColor;
        [footView.layer addSublayer:lineLayer];
        
        return footView;
    }else{
        return nil;
    }
  
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.feedListArray.count > indexPath.section) {
        FeedBackModel *replyModel = self.feedListArray[indexPath.section];
        
        FeedDetailViewController * detail = [[FeedDetailViewController alloc]init];
        detail.feedModel = replyModel;
        [self.navigationController pushViewController:detail animated:YES];
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
