//
//  FeedBackCell.h
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/30.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FeedBackReplyModel.h"
@interface FeedBackCell : UITableViewCell

@property (strong,nonatomic) UIImageView * iconImageView;//显示图片

@property (strong,nonatomic) UILabel *contentLabel;//显示回复内容

@property (strong,nonatomic) UILabel *showTimeLabel;//显示时间

- (void)fillCellWith:(FeedBackReplyModel *)feedModel isShow:(BOOL)show;
@end
