//
//  FeedDevicesController.m
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/20.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "FeedDevicesController.h"
#import "FeedDevicesCell.h"

#import "HotRequest.h"
@interface FeedDevicesController ()<UITableViewDelegate,UITableViewDataSource>

@property (strong,nonatomic) UITableView *devicesTableView;//列表

@property (strong,nonatomic) NSMutableArray *devicesArray ;//数据
@end

@implementation FeedDevicesController
{
    NSInteger selectIndex;//选中的cell
    UIView *notithingView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    selectIndex = -1;
    self.title = @"所属设备";
    [self.view addSubview:self.devicesTableView];
    [self createNotingView];
//    [self requestDevices];
    // Do any additional setup after loading the view.
}
//- (void)requestDevices{
//    if (!_devicesArray) {
//        _devicesArray =[[NSMutableArray alloc]init];
//    }else{
//        [_devicesArray removeAllObjects];
//    }
//    if ([HETUserInfo userInfo].isLogin) {
//        
//        __weak typeof(self)Wself = self;
//
//        [[HotRequest shareInstance]getDevicesListWith:[HETUserInfo userInfo].accessToken AndSuccess:^(NSArray *deviceArray) {
//            [CSAppUserSettings shareInstance].userAcountChange = NO;
//            if (deviceArray.count>0) {
//               
//                /**对网络获取的设备信息进行赋值处理，这些设备都是非体验设备 isExperience ＝false
//                 *  风扇支持小循环，其余的不支持小循环
//                 */
//                for (NSInteger i=0;i<deviceArray.count; i++) {
//                    
//                    NSDictionary * deviceDic = deviceArray[i];
//                    MainDevice * device =[[MainDevice alloc]init];
//                    device.DeviceInfo = deviceDic;
//                    [device setValuesForKeysWithDictionary:deviceDic];
//                    
//                    [Wself.devicesArray addObject:device];
//                    
//                    if ([device.productName isEqualToString:Wself.deviceName]) {
//                        selectIndex = i;
//                    }
//                }
//            
//            }else{
//                 notithingView.hidden = NO;
//            }
//            [self.devicesTableView reloadData];
//        } AndFaliBlock:^(NSError *error) {
//            NSString * errorDes = [error.userInfo objectForKey:NSLocalizedDescriptionKey];
//            [HelpMsg showMessage:errorDes inView:self.view];
//           
//        }];
//    }
//
//}
- (UITableView *)devicesTableView{
    
    if (!_devicesTableView) {
        _devicesTableView = [[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _devicesTableView.dataSource = self;
        _devicesTableView.delegate = self;
        _devicesTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        [_devicesTableView registerClass:[FeedDevicesCell class] forCellReuseIdentifier:@"cell"];
        
        _devicesTableView.tableFooterView = [UIView new];
        
    }
    return _devicesTableView;
}
- (void)createNotingView{
    
    notithingView = [[UIView alloc]initWithFrame:self.view.bounds ];
    notithingView.backgroundColor = KCOLOR(@"eef0f1");
    [self.view addSubview:notithingView];
    
    UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake((ScreenWidth -160 *NewBasicHeight)/2, 122 *NewBasicHeight + NAVIBARHEIGHT, 160 *NewBasicHeight, 160 *NewBasicHeight)];
    imageView.image = [UIImage imageNamed:@"NoCooks"];
    [notithingView addSubview:imageView];
    
    UILabel * label = [UILabel setLabelWith:@"无绑定设备" AndFont:KFONT(14) AndIsNumberOfLines:YES AndtextColor:KCOLOR(@"a9a9a9") AndFrame:CGRectMake(0, 24 *NewBasicHeight +CGRectGetMaxY(imageView.frame), ScreenWidth, 16) AndAlignment:NSTextAlignmentCenter];
    
    [notithingView addSubview:label];
    
    [self.view addSubview:notithingView];
    notithingView.hidden = YES;
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.devicesArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    FeedDevicesCell *Cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    Cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if (self.devicesArray.count>indexPath.row) {
        [Cell fillCellWithModel:self.devicesArray[indexPath.row]];
    }
    if (selectIndex == indexPath.row) {
        Cell.isMark = YES;
    }else{
        Cell.isMark = NO;
    }
    return Cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (selectIndex >= 0) {
        FeedDevicesCell *Cell = (FeedDevicesCell *)[tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:selectIndex inSection:0]];
        Cell.isMark = NO;
    }
    FeedDevicesCell *Cell = (FeedDevicesCell *)[tableView cellForRowAtIndexPath:indexPath];
    Cell.isMark = YES;
    
    selectIndex = indexPath.row;
    MainDevice *model = self.devicesArray[indexPath.row];
    
    if (self.deviceDelegate &&[self.deviceDelegate respondsToSelector:@selector(getSelectDevice:)]) {
        [self.deviceDelegate getSelectDevice:model];
    }
    [self.navigationController popViewControllerAnimated:YES];
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 72 *NewBasicHeight;
}
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}
//cell的边线置顶
-(void)viewDidLayoutSubviews
{
    
    if ([self.devicesTableView respondsToSelector:@selector(setSeparatorInset:)]) {
        [self.devicesTableView setSeparatorInset:UIEdgeInsetsMake(0,0,0,0)];
    }
    
    if ([self.devicesTableView respondsToSelector:@selector(setLayoutMargins:)]) {
        [self.devicesTableView setLayoutMargins:UIEdgeInsetsMake(0,0,0,0)];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
