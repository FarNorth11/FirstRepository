//
//  FeedDevicesCell.h
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/20.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainDevice.h"
@interface FeedDevicesCell : UITableViewCell

@property (strong,nonatomic) UIImageView *ImageView;//设备图片

@property (strong,nonatomic) UILabel *itemLabel;//设备名称

@property (assign,nonatomic) BOOL isMark;//是否被标记

- (void)fillCellWithModel:(MainDevice *)model;
@end
