//
//  FeedStyleChooseView.h
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/20.
//  Copyright © 2016年 starlueng. All rights reserved.
//
static NSInteger const cancelTag  = 40;//取消按钮tag
static NSInteger const sureTag    = 41;//确定按钮tag
#import <UIKit/UIKit.h>
typedef void (^CellClick)(UIButton *button ,NSInteger selectNum);

@interface FeedStyleChooseView : UIView<UITableViewDelegate,UITableViewDataSource>
@property (strong,nonatomic) UITableView *theTableView;

@property (copy,nonatomic)CellClick clickBlock;

@property (assign,nonatomic) CGFloat originY;

@property (assign,nonatomic) NSInteger selectIndex;

- (instancetype)initWithFrame:(CGRect)frame originY:(CGFloat)y itemArray:(NSArray *)array  ButtonClick:(CellClick)block;

- (void)show;

- (void)hiden;
@end
