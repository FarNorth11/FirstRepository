
//
//  FeedDevicesCell.m
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/20.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "FeedDevicesCell.h"
#import "UIImageView+WebCache.h"
@implementation FeedDevicesCell
{
    UIImageView *accessImageView;//勾选
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createUI];
    }
    return self;
}
#pragma mark-===================UI=========================
- (void) createUI{
    
    self.ImageView = [[UIImageView alloc]initWithFrame:CGRectMake(16 *NewBasicWidth, 8*NewBasicHeight, 56 *NewBasicHeight, 56 *NewBasicHeight)];
    self.ImageView.contentMode = UIViewContentModeScaleAspectFit;
    self.ImageView.clipsToBounds = YES;
    [self.contentView addSubview:self.ImageView];
    
    
    self.itemLabel = [UILabel setLabelWith:@"" AndFont:KFONT(16) AndIsNumberOfLines:YES AndtextColor:KCOLOR(@"323232") AndFrame:CGRectMake(CGRectGetMaxX(self.ImageView.frame)+12 *NewBasicWidth, (72 *NewBasicHeight - 18)/2, ScreenWidth -CGRectGetMaxX(self.ImageView.frame) -56 *NewBasicWidth, 18) AndAlignment:NSTextAlignmentLeft];
    [self.contentView addSubview:self.itemLabel];
    
    accessImageView = [[UIImageView alloc]initWithFrame:CGRectMake(ScreenWidth -32 *NewBasicWidth, 28*NewBasicHeight, 16*NewBasicHeight, 16*NewBasicHeight)];
    accessImageView.image = [UIImage imageNamed:@"bellSelect"];
    [self.contentView addSubview:accessImageView];
    accessImageView.hidden = YES;
}
- (void)setIsMark:(BOOL)isMark{
    
    if (isMark) {
        
        accessImageView.hidden = NO;
    }else{
        accessImageView.hidden = YES;
    }
}
- (void)fillCellWithModel:(MainDevice *)model{
    
    [self.ImageView sd_setImageWithURL:[NSURL URLWithString:model.productIcon] placeholderImage:[UIImage imageNamed:@"imageLoading"]];
    self.itemLabel.text = model.productName;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
