//
//  FeedStyleCell.h
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/20.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^sendB)(id);
@interface FeedStyleCell : UITableViewCell
@property (strong,nonatomic) UIImageView *selectImageView;//被选中的图片

@property (strong,nonatomic) UILabel *itemLabel;//文件名称

@property (assign,nonatomic) BOOL isMark;//是否被标记

@property (copy,nonatomic) sendB block;
@end
