//
//  FeedStyleCell.m
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/20.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "FeedStyleCell.h"

@implementation FeedStyleCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createUI];
    }
    return self;
}
#pragma mark-===================UI=========================
- (void) createUI{
   
    _itemLabel = [UILabel setLabelWith:@"" AndFont:[UIFont systemFontOfSize:14] AndIsNumberOfLines:YES AndtextColor:[UIConfig colorFromHexRGB:@"323232"] AndFrame:CGRectMake(18 *NewBasicWidth, 14*NewBasicHeight, 200 *NewBasicWidth, 16) AndAlignment:NSTextAlignmentLeft];
    [self.contentView addSubview:_itemLabel];
    
    _selectImageView = [[UIImageView alloc]initWithFrame:CGRectMake(ScreenWidth -32 *NewBasicWidth, 14*NewBasicHeight, 16*NewBasicHeight, 16*NewBasicHeight)];
    _selectImageView.image = [UIImage imageNamed:@"bellSelect"];
    [self.contentView addSubview:_selectImageView];
    _selectImageView.hidden = YES;
  
}
- (void)play:(UIButton *)sender{
   
    if (self.block) {
        self.block(sender);
    }
}
- (void)setIsMark:(BOOL)isMark{
    if (isMark) {
        _selectImageView.hidden = NO;
    
    }else{
        _selectImageView.hidden = YES;
    
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated{
    
    [super setSelected:selected animated:animated];
}


@end
