//
//  FeedDevicesController.h
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/20.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "RootViewController.h"
#import "MainDevice.h"
@protocol DeviceSelectDelegate <NSObject>

- (void)getSelectDevice:(MainDevice *)model;

@end
@interface FeedDevicesController : RootViewController
@property (nonatomic, weak) id<DeviceSelectDelegate> deviceDelegate;

@property (copy,nonatomic) NSString *deviceName;
@end
