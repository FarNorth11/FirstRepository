//
//  FeedStyleChooseView.m
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/20.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "FeedStyleChooseView.h"
#import "FeedStyleCell.h"
@implementation FeedStyleChooseView

{
    NSArray *dataSource;//数据
    UIView *showView;//展示view
    UIView *backGdView;//背景图片
   
}
@synthesize   selectIndex;

- (instancetype)initWithFrame:(CGRect)frame originY:(CGFloat)y itemArray:(NSArray *)array  ButtonClick:(CellClick)block{
    self = [super initWithFrame:frame];
    if (self) {
        self.originY = y;
        dataSource = array;
        [self createUI];
        self.clickBlock = block;
        
    }
    return self;
}
#pragma mark-============================UI=======================================
- (void)createUI{
    selectIndex = 0;
    self.backgroundColor = [UIColor clearColor];
    backGdView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
    [self addSubview:backGdView];
    backGdView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.4];
    backGdView.hidden = YES;
    backGdView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(hiden)];
    [backGdView addGestureRecognizer:tap];
    
    showView = [[UIView alloc]initWithFrame:CGRectMake(0, ScreenHeight, ScreenWidth,ScreenHeight - self.originY)];
    [self addSubview:showView];
    
    showView.backgroundColor = WHITECOLOR;
    
    UILabel *title = [UILabel setLabelWith:@"问题类型" AndFont:[UIFont systemFontOfSize:14] AndIsNumberOfLines:YES AndtextColor:[UIConfig colorFromHexRGB:@"323232"] AndFrame:CGRectMake((ScreenWidth -100*NewBasicWidth)/2, 0, 100 *NewBasicWidth, 48 *NewBasicHeight) AndAlignment:NSTextAlignmentCenter];
    [showView addSubview:title];
    
    [showView addSubview:self.theTableView];
    
    CALayer *lineLayer = [[CALayer alloc]init];
    lineLayer.frame = CGRectMake(0, 48 *NewBasicHeight-SINGLE_LINE_WIDTH, ScreenWidth, SINGLE_LINE_WIDTH);
    lineLayer.backgroundColor = [UIConfig colorFromHexRGB:@"c7c8cc"].CGColor;
    [showView.layer addSublayer:lineLayer];
    
    UIButton *cancelBtn = [UIButton setButtonWith:@"取消" AndNomalColor:[UIConfig colorFromHexRGB:@"323232"] AndSelectColor:[UIConfig colorFromHexRGB:@"323232"] AndFont:[UIFont systemFontOfSize:14] AndFrame:CGRectMake(16 *NewBasicWidth, 0, 50 *NewBasicWidth, 48 *NewBasicHeight)];
    [showView addSubview:cancelBtn];
    cancelBtn.tag = cancelTag;
    [cancelBtn addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *sureBtn = [UIButton setButtonWith:@"确定" AndNomalColor:[UIConfig colorFromHexRGB:@"323232"] AndSelectColor:[UIConfig colorFromHexRGB:@"323232"] AndFont:[UIFont systemFontOfSize:14] AndFrame:CGRectMake(ScreenWidth -66 *NewBasicWidth, 0, 50 *NewBasicWidth, 48 *NewBasicHeight)];
    [showView addSubview:sureBtn];
    sureBtn.tag = sureTag;
    [sureBtn addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    

    
    if (showView&&backGdView) {
        [self show];
    }
}
- (UITableView *)theTableView{
    
    if (!_theTableView) {
        _theTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 48 *NewBasicHeight, ScreenWidth, ScreenHeight - self.originY-48 *NewBasicHeight)];
        _theTableView.delegate = self;
        _theTableView.dataSource = self;
        [_theTableView registerClass:[FeedStyleCell class] forCellReuseIdentifier:@"cell"];
        _theTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        _theTableView.tableFooterView = [UIView new];
    }
    return _theTableView;
}
#pragma mark-=============UITableViewDelegate,UITableViewDataSource=================================
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return dataSource.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    FeedStyleCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if (dataSource.count>indexPath.row) {
        NSString *itemName = dataSource[indexPath.row];
        cell.itemLabel.text = [[itemName componentsSeparatedByString:@"."]firstObject];
        if (selectIndex == indexPath.row) {
            cell.isMark = YES;
        }else{
            cell.isMark = NO;
        }
    }
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 45 *NewBasicHeight;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    FeedStyleCell *lastcell = (FeedStyleCell *)[tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:selectIndex inSection:0]];
    lastcell.isMark = NO;
   
    FeedStyleCell *cell = (FeedStyleCell *)[tableView cellForRowAtIndexPath:indexPath];
    
    cell.isMark = YES;
    
    selectIndex = indexPath.row;
}

#pragma mark-========================事件=======================
- (void) buttonAction:(UIButton *)sender{
    
    [self hiden];
    if (self.clickBlock) {
        self.clickBlock (sender,selectIndex);
    }
}
- (void)show{
    [[[[UIApplication sharedApplication]delegate]window]addSubview:self];
    if (backGdView) {
        backGdView.hidden = NO;
    }
    if (showView) {
        [UIView animateWithDuration:0.3 animations:^{
            CGRect frame = showView.frame;
            frame.origin.y = self.originY;
            showView.frame = frame;
        }];
    }
}
- (void)hiden{
    
//    [[PublicOperation shareInstance]playerStop];
    if (backGdView) {
        backGdView.hidden = YES;
    }
    if (showView) {
        [UIView animateWithDuration:0.3 animations:^{
            CGRect frame = showView.frame;
            frame.origin.y = ScreenHeight;
            showView.frame = frame;
            
        } completion:^(BOOL finished) {
            if (finished) {
                
                [self removeFromSuperview];
                
            }
        }];
    }
    
}

@end
