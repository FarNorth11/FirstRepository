//
//  HomepageController.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/27.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "HomepageController.h"
#import "HomepageCell.h"
#import "GrouppageController.h"
#import "UINavigationController+FDFullscreenPopGesture.h"
#import "GetGroupListRequest.h"
#import "PublicOperation.h"
#import "GroupListModel.h"
#import "EditGroupRequest.h"
#import "MJRefresh.h"
#import "DeviceManage.h"

@interface HomepageController (){
    UITableView *mainTableView;
    NSMutableArray *_groupListArr;
    UIControl *control;
    NSString *GroupNameText;
}

@end

@implementation HomepageController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.fd_prefersNavigationBarHidden = YES;
    [self addNaviView];
    [self addTableView];
    [self getGroupList];
    
    //修改了分组列表
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(getGroupList)
                                                 name:@"RefreshGroupList" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(getGroupList)
                                                 name:@"kNotificationHasLogin" object:nil];
    
    
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    AppDelegate *app =(AppDelegate *)[UIApplication sharedApplication].delegate;
    app.root.tabBar.hidden = NO;
    app.root.button.hidden = NO;
    [mainTableView reloadData];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark  =========================== action ===========================
-(void) actionCancel:(id)sender{
    [control removeFromSuperview];
}

-(void)changeGroupName:(NSInteger )gid{
    EditGroupRequest *editGroup = [[EditGroupRequest alloc]initWithAccessToken:[HETUserInfo userInfo].accessToken opeType:2 gid:gid groupName:GroupNameText pageIndex:@(1) pageRows:@(20)];
    [editGroup startWithSuccess:^(NSDictionary *dictValue) {
        [self getGroupList];

        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"修改成功" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
        [alert show];
    } failure:^(NSError *error, NSInteger statusCode) {
//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"修改失败" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
//        [alert show];
        [HelpMsg showMessage:@"设置失败" inView:[[[UIApplication sharedApplication]delegate]window]];
        if (error.code == 0) {
            [HelpMsg showMessage:@"当前网络不可用" inView:[[UIApplication sharedApplication].delegate window]];
        }
    }];
    


}

#pragma mark  =========================== UI ===========================
-(void)addTableView{
    mainTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, NAVIBARHEIGHT+STATUSBARHEIGHT, ScreenWidth, ScreenHeight)];
    mainTableView.backgroundColor = [UIColor whiteColor];
    mainTableView.delegate=self;
    mainTableView.dataSource = self;
//    mainTableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
//        // 进入刷新状态后会自动调用这个block
//    }];
//    mainTableView.header.lastUpdatedTime
//    [self.tableView.header beginRefreshing];
    
    typeof(self) __weak weakSelf = self;
    MJRefreshStateHeader *header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
       
        PublicOperation  *publicOp = [PublicOperation shareInstance];
        if ([HETUserInfo userInfo].isLogin) {
            [weakSelf getGroupList];
        }else{
//            [HelpMsg showMessage:@"请登录" inView:[[UIApplication sharedApplication].delegate window]];
            [mainTableView.header endRefreshing];
            [publicOp publicSet];
            [publicOp loginAndPopWith:^{
                [[NSNotificationCenter defaultCenter] postNotificationName: @"addLoginNotification" object: nil userInfo:nil];
            }];
            
            
        }
        
    }];
    header.lastUpdatedTimeLabel.hidden = YES;
    mainTableView.header = header;

    /**
     清除多余线
     */
    UIView *footView =[[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, SINGLE_LINE_WIDTH)];
    footView.backgroundColor =[UIColor whiteColor];
    mainTableView.tableFooterView =footView;
    mainTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:mainTableView];
    
}

-(void)addNaviView{

    UILabel *label =[UILabel setLabelWith:@"我的设备" AndFont:[UIFont systemFontOfSize:18] AndIsNumberOfLines:NO AndtextColor:WHITECOLOR AndFrame:CGRectMake((ScreenWidth-100)/2, STATUSBARHEIGHT, 100, NAVIBARHEIGHT) AndAlignment:NSTextAlignmentCenter];
    label.textColor = [UIConfig colorFromHexRGB:@"131212"];
    [self.view addSubview:label];
}

#pragma mark  =========================== Request ===========================
-(void)getGroupList{
    if(![self isInternetConnect]){
        [mainTableView.header endRefreshing];
        [HelpMsg showMessage:@"刷新失败,请检查你的网络" inView:[[UIApplication sharedApplication].delegate window]];
        _groupListArr = nil;
        [mainTableView reloadData];
    }else{
    
        GetGroupListRequest *getGroupList = [[GetGroupListRequest alloc]initWithAccessToken:[HETUserInfo userInfo].accessToken pageIndex:@(1) pageRows:@(20)];
        _groupListArr = nil;
        [getGroupList startWithSuccessBlockDictionaryParameter:^(NSDictionary *dictValue) {
            [mainTableView.header endRefreshing];
            if (dictValue!=nil ) {
                _groupListArr = [[NSMutableArray alloc]init];
                NSArray *groupArr = [dictValue objectForKey:@"list"];
                for (int i=0; i<groupArr.count; i++) {
                    [_groupListArr addObject:[[GroupListModel alloc]initWithData:groupArr[i]]];
                }
            }
            [mainTableView reloadData];
            //        [mainTableView.header endRefreshing];
            NSLog(@"成功");
        } failure:^(NSError *error, NSInteger statusCode) {
            [mainTableView.header endRefreshing];
            NSLog(@"失败");
            [HelpMsg showMessage:@"刷新失败,请检查你的网络" inView:[[UIApplication sharedApplication].delegate window]];
            _groupListArr = nil;
            [mainTableView reloadData];
            
            //        [mainTableView.header endRefreshing];
        }];

    }
    

}




-(BOOL)isInternetConnect{
    
    BOOL whether = YES;
    NSURL *url1 = [NSURL URLWithString:@"http://www.baidu.com"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url1 cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:10];
    NSHTTPURLResponse *response;
    [NSURLConnection sendSynchronousRequest:request returningResponse: &response error: nil];
    if (response == nil) {
        NSLog(@"没有网络");
        whether = NO;
    }
    else{
        NSLog(@"网络是通的");
    }
    return whether;
}

-(void)handleTextFieldTextDidChangeNotification:(NSNotification *)notification{
    UITextField *textField = notification.object;
    NSString * toBeString = textField.text; //得到输入框的内容
    
    if ([toBeString length] > 10) { //如果输入框内容大于10则弹出警告
        textField.text = [toBeString substringToIndex:10];
//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"超过最大字数不能输入了" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
//        [alert show];
    }
    GroupNameText = textField.text;
}

//- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
//    
//    NSString *new = [textView.text stringByReplacingCharactersInRange:range withString:text];
//    
//    if(new.length > 20){
//        
//        if (![text isEqualToString:@""]) {
//            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"超过最大字数不能输入了" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
//            [alert show];
//            
//            return NO;
//            
//        }
//        
//    }
//    
//    return YES;
//    
//}
#pragma mark UITableViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 70;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if ([HETUserInfo userInfo].isLogin) {
        if (_groupListArr.count ==0) {
            return 6;
        }else{
            return _groupListArr.count;
        }
        
    }else{
        
      return 6;
    }
    
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    
//    [tableView registerClass:[HomepageCell class] forCellReuseIdentifier:@"HomepageCell"];
//    HomepageCell *cell = [tableView dequeueReusableCellWithIdentifier:@"HomepageCell" forIndexPath:indexPath];
    
    
    
    HomepageCell * cell = [tableView dequeueReusableCellWithIdentifier:@"HomepageCell"];
    if (cell == nil)  {
        cell = [[HomepageCell alloc] initWithStyle:UITableViewCellStyleSubtitle  reuseIdentifier:@"HomepageCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    NSArray *groupTextArr = @[@"分组一",@"分组二",@"分组三",@"分组四",@"分组五",@"分组六"];
    if ([HETUserInfo userInfo].isLogin) {
        if(_groupListArr.count>0){
            GroupListModel *currentMode =  _groupListArr[indexPath.section];
            cell.titleLabel.text = currentMode.groupName;
            
            [cell.countBtn setTitle:[NSString stringWithFormat:@"%@",currentMode.deviceNum] forState:UIControlStateNormal ];
        }else{
            cell.titleLabel.text = groupTextArr[indexPath.section];
            [cell.countBtn setTitle:@"0" forState:UIControlStateNormal ];
        }
    }else{

        cell.titleLabel.text = groupTextArr[indexPath.section];
        [cell.countBtn setTitle:@"0" forState:UIControlStateNormal ];
        
    }

    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    PublicOperation  *publicOp = [PublicOperation shareInstance];

    if ([HETUserInfo userInfo].isLogin) {
        GrouppageController *groupView = [[GrouppageController alloc]init];
        if(_groupListArr.count>0){
            GroupListModel *currentMode = _groupListArr[indexPath.section];
            groupView.groupModel = currentMode;
            groupView.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:groupView animated:YES];
        }
        
    }else{
        [publicOp publicSet];
        [publicOp loginAndPopWith:^{
            [[NSNotificationCenter defaultCenter] postNotificationName: @"addLoginNotification" object: nil userInfo:nil];
        }];
        
        
    }
}


- (NSArray*)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewRowAction *renameAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleDestructive title:@"重命名" handler:^(UITableViewRowAction *action, NSIndexPath *indexPath){
        
        //                    EditGroupRequest *editGroup = [[EditGroupRequest alloc]initWithAccessToken:[HETUserInfo userInfo].accessToken opeType:2 gid:_groupListArr[indexPath.section] groupName:@"" pageIndex:@(1) pageRows:@(20)]
        
        //        control=[[UIControl  alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
        //        control.backgroundColor=[UIColor colorWithRed:0 green:0 blue:0 alpha:0.4];
        //         AppDelegate *app =(AppDelegate *)[UIApplication sharedApplication].delegate;
        //        [app.window  addSubview:control];
        //        [control  addTarget:self action:@selector(actionCancel:)   forControlEvents:UIControlEventTouchUpInside];
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"" message:@"" preferredStyle:UIAlertControllerStyleAlert];
        
        WEAKSELF;
        [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
            //监听text文本 是否有中文
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleTextFieldTextDidChangeNotification:) name:UITextFieldTextDidChangeNotification object:textField];
            textField.placeholder = @"最多10个中英文字符";
            textField.clearButtonMode = UITextFieldViewModeWhileEditing;
            textField.delegate = weakSelf;
//            [textField resignFirstResponder];
            
        }];
        
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            NSLog(@"The \"Secure Text Entry\" alert's cancel action occured.");
             [[NSNotificationCenter defaultCenter] removeObserver:self name:UITextFieldTextDidChangeNotification object:alertController.textFields.firstObject];
            if([GroupNameText length] ==0){
                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"不能为空" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
                [alert show];
            }else{
                GroupListModel *model =  _groupListArr[indexPath.section];
                
                [self changeGroupName:model.gid];
            }
            
        }];
        
        UIAlertAction *otherAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
            NSLog(@"The \"Secure Text Entry\" alert's other action occured.");
            
             [[NSNotificationCenter defaultCenter] removeObserver:self name:UITextFieldTextDidChangeNotification object:alertController.textFields.firstObject];
        }];
        
//        otherAction.enabled = NO;
//        self.secureTextAlertAction = otherAction;
        
        // Add the actions.
        [alertController addAction:cancelAction];
        [alertController addAction:otherAction];
        
        [self presentViewController:alertController animated:YES completion:nil];
        
        
        
    }];
    
    renameAction.backgroundColor    = [UIConfig colorFromHexRGB:@"63d3d3"];
    return @[renameAction];
}

//IOS 9之前版本需要加上的.否则不能正确显示
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;// 删除cell
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        

    }
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
