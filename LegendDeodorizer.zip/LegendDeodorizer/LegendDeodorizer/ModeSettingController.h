//
//  ModeSettingController.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/30.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainDevice.h"

typedef void (^backBlock)(NSNumber *);
@interface ModeSettingController : UIViewController
@property(nonatomic,strong)MainDevice *device;
@property (copy,nonatomic)backBlock clickBack;

@end
