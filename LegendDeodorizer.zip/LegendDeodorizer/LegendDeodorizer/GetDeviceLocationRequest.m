//
//  GetDeviceLocationRequest.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/5.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "GetDeviceLocationRequest.h"
#import "HETRequest+Private.h"

@implementation GetDeviceLocationRequest{
    NSString  *_accessToken;
    NSString *_mac;
}
-(instancetype)initWithAccessToken:(NSString *)accessToken mac:(NSString *)mac{
    
    self = [super init];
    if (self) {
        _accessToken = accessToken;
        _mac = mac;
        
    }
    
    return self;
    
    
}
- (YTKRequestMethod)requestMethod{
    
    return YTKRequestMethodGet;
    
}

-(BOOL)isHttpsType{
    
    return YES;
}

-(NSString *)requestUrl{
    
    return [@"/v1/app/customization/legend" stringByAppendingString: @"/getDeviceLocation"];
    
}

- (id)requestArgument{
    
    return @{
             @"accessToken":_accessToken,
             @"mac" : _mac
             };
    
}

- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock{
    [super startWithSuccessBlockDictionaryParameter:successBlock failure:failureBlock];
}


@end
