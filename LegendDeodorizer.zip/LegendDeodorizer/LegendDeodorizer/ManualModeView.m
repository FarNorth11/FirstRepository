//
//  ManualModeView.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/31.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "ManualModeView.h"
#import "DayChooseCell.h"
#import "ManualCell.h"
@implementation ManualModeView{
    UITableView *manualTableView;
    NSMutableArray *manualCellArr;
    NSMutableArray *daySelectArray;//存储设置的星期组合
}


-(void)setFrame:(CGRect)frame
{
    [super setFrame:frame];
    manualTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, self.frame.size.height-60)];
    manualTableView.backgroundColor = [UIConfig colorFromHexRGB:@"fbfbfb"];
    manualTableView.delegate =self;
    manualTableView.dataSource = self;
    
    UIView *footView =[[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, SINGLE_LINE_WIDTH)];
    footView.backgroundColor =[UIConfig colorFromHexRGB:@"ffffff"];
    manualTableView.tableFooterView = footView;
    
    [self addSubview:[self createFootView]];
    
    [manualTableView registerClass:[DayChooseCell class] forCellReuseIdentifier:@"cell"];
    
    [manualTableView registerClass:[ManualCell class] forCellReuseIdentifier:@"ManualCell"];
    [self addSubview:manualTableView];
    
}
/*
 {
 modeType = 2;
 setList =     (
 {
 endTime = "07:30";
 isUsed = 0;
 openTime = 5;
 startTime = "07:00";
 stopTime = 5;
 },
 {
 endTime = "08:30";
 isUsed = 0;
 openTime = 5;
 startTime = "08:00";
 stopTime = 5;
 });
 threshold = "<null>";
 week = "1,2,3,4,5";
 }

 
 
 */

-(void)getDataModel{
    if (_manualModeDic) {
        //        threshold = "1.35,1.05";
        //        week = "1,2,3,4,5";
        NSString *weekStr = _manualModeDic.week;
//        NSString *threshold = _manualModeDic.threshold;
        manualCellArr =  [NSMutableArray arrayWithArray:_manualModeDic.setList];
        
//        NSMutableCharacterSet *set = [NSMutableCharacterSet characterSetWithCharactersInString:@","];
//        NSArray *dataArray = [weekStr componentsSeparatedByCharactersInSet:set];
//        if (dataArray.count>0) {
//            daySelectArray = [[NSMutableArray alloc]init];
//            for (NSInteger i=1; i<=7; i++) {
//                [daySelectArray addObject:@NO];
//                
//            }
//            for (NSString *s in dataArray) {
//                NSInteger selectNum = s.integerValue;
//                if (selectNum>0&&selectNum <8) {
//                    [daySelectArray replaceObjectAtIndex:selectNum-1 withObject:@YES];
//                }
//            }
//            DayChooseCell  *cell = (DayChooseCell *)[manualTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
//            [cell setRetState:daySelectArray];
//        }
        
        DayChooseCell  *cell = (DayChooseCell *)[manualTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
        [cell setRetState:[self transfomModeStr:weekStr]];
        
        if (manualCellArr.count>0) {
            
            [manualTableView reloadData];
        }
        
        
        
    }
}

/**
 dayCell  后台数据格式 week = "1,2,3,4,5"; 转成 (1,1,1,1,1,0,0) 提供给dayCell展示
 
 **/
-(NSMutableArray *)transfomModeStr:(NSString *)weekStr{
    daySelectArray = [[NSMutableArray alloc]init];
    NSMutableCharacterSet *set = [NSMutableCharacterSet characterSetWithCharactersInString:@","];
    NSArray *dataArray = [weekStr componentsSeparatedByCharactersInSet:set];
    if (dataArray.count>0) {
        for (NSInteger i=1; i<=7; i++) {
            [daySelectArray addObject:@NO];
            
        }
        for (NSString *s in dataArray) {
            NSInteger selectNum = s.integerValue;
            if (selectNum>0&&selectNum <8) {
                [daySelectArray replaceObjectAtIndex:selectNum-1 withObject:@YES];
            }
        }
    }
    return  daySelectArray;
}
/**
 数据处理
 先把manualCellArr中的数据mode转换成字典,再用arr包起来
setList =     (
               {
                   endTime = "07:30";
                   isUsed = 0;
                   openTime = 5;
                   startTime = "07:00";
                   stopTime = 5;
               },
               
**/
-(NSMutableArray *)transfomModeToArr:(NSMutableArray *)modeArr{
    
    NSMutableArray * afterArr= [[NSMutableArray alloc]init];
    if (modeArr.count>0) {
 
        for (SetListModel *mode in modeArr) {
            NSMutableDictionary *modeDic = [[NSMutableDictionary alloc]init];
            [modeDic setObject:mode.endTime forKey: @"endTime"];
            [modeDic setObject:mode.openTime forKey:@"openTime"];
            [modeDic setObject:mode.startTime forKey:@"startTime"];
            [modeDic setObject:mode.stopTime forKey:@"stopTime"];
            [modeDic setObject:mode.isUsed forKey:@"isUsed"];
            [afterArr addObject:modeDic];

            
        }
    }

    return  afterArr;
}

-(UIView *)createFootView{
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, self.frame.size.height-60, ScreenWidth, 60)];
    view.backgroundColor = [UIColor clearColor];
   
    UIButton *button = [UIButton setButtonWith:@"启动" AndNomalColor:WHITECOLOR AndSelectColor:WHITECOLOR AndFont:KFONT(16) AndFrame:CGRectMake(30, 8, ScreenWidth -60, 44)];
    [button setBackgroundImage:[UIImage imageNamed:@"homeCellBg"] forState:UIControlStateNormal];
    [view addSubview:button];
    [button addTarget:self action:@selector(buttonAvtion:) forControlEvents:UIControlEventTouchUpInside];
    return view;
    
}
#pragma mark --------------- 更改模式 -------------
- (void)buttonAvtion:(UIButton *)button{
    /**
     {
     modeType = 2;
     setList =     (
     {
     endTime = "07:30";
     isUsed = 0;
     openTime = 5;
     startTime = "07:00";
     stopTime = 5;
     },
     {
     endTime = "08:30";
     isUsed = 0;
     openTime = 5;
     startTime = "08:00";
     stopTime = 5;
     }
     );
     threshold = "<null>";
     week = "1,2,3,4,5";
     }
     **/
    manualCellArr;
    daySelectArray;//(1,1,1,1,1,0,0)
    
    if (manualCellArr.count>0) {
        NSMutableArray *curArr = [self transfomModeToArr:manualCellArr];
        [self.delegate returnModeSetting:2 week:_manualModeDic.week threshold:@"" setList:curArr];
    }

    
}
#pragma mark ----------------- UITableViewDelegate ------------------
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section ==0) {
        return 1;
    }else{
        if (manualCellArr.count!= 0) {
            return manualCellArr.count;
        }else{
            return 5;
        }
        
    }
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        return 48;
    }else{
        return 72;
    }
   
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
 
    DayChooseCell  *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    ManualCell  *secondcell = [tableView dequeueReusableCellWithIdentifier:@"ManualCell"];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    secondcell.selectionStyle = UITableViewCellSelectionStyleNone;
    if (indexPath.section == 0) {
        [cell setRetState:daySelectArray];
         __weak typeof(self)Wself = self;
        cell.click =^(NSString *string){
            NSLog(@"------------------------%@",string);
            Wself.manualModeDic.week = string;
            [self transfomModeStr:string];
//            daySelectArray =
        };
        return cell;
    }else{
        if (manualCellArr.count>0) {
            SetListModel *setmodel = manualCellArr[indexPath.row];
            [secondcell setManualCellData:setmodel];
            
            secondcell.switchblock = ^(UISwitch *theSwitch){
                
/**
设备要求,后动模式设置的时间段不能重合,所以需要在这里判断是否有重合,如果有重合就不让switch开关打开
 
 **/
                if (theSwitch.on) {
                    setmodel.isUsed = @(1);
                }else{
                    setmodel.isUsed = @(0);
                }
//                setmodel.isUsed =@(theSwitch.on);
                if (theSwitch.isOn == YES) {
                    
                    for (SetListModel *model in manualCellArr) {
                        
                        if(model.isUsed.integerValue ==1){
                            
                            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                            [dateFormatter setDateFormat:@"HH:mm"];
                            
                            NSDate *current_startTime= [dateFormatter dateFromString:setmodel.startTime ];
                            
                            NSDate *current_endTime = [dateFormatter dateFromString:setmodel.endTime ];
                            
                            NSDate *arr_startTime = [dateFormatter dateFromString:model.startTime ];
                            
                            NSDate *arr_endTime = [dateFormatter dateFromString:model.endTime ];
                            
                            //                        [current_endTime compare:arr_startTime]
                            
                            NSLog(@"%@,%@,%@,%@",model.startTime ,model.endTime,setmodel.startTime,setmodel.endTime  );
                            
                            NSLog(@"%d",([current_endTime compare:arr_startTime] ==NSOrderedSame||[current_endTime compare:arr_startTime] ==NSOrderedAscending));
                            
                            NSLog(@"%d",([current_startTime compare:arr_endTime] ==NSOrderedSame||[current_startTime compare:arr_endTime] ==NSOrderedDescending));
                            
//                            if (!([current_startTime compare:arr_startTime] ==NSOrderedSame && [current_endTime compare:arr_endTime] ==NSOrderedSame)) {
//                                if(([current_endTime compare:arr_startTime] ==NSOrderedSame||[current_endTime compare:arr_startTime] ==NSOrderedAscending)||([current_startTime compare:arr_endTime] ==NSOrderedSame||[current_startTime compare:arr_endTime] ==NSOrderedDescending)){
//                                    //没有重合
//                                    setmodel.isUsed = @(1);
//                                    
//                                }else{
//                                    //有重合
//                                    [HelpMsg showMessage:@"时间设置重合,请调整" inView:[[[UIApplication sharedApplication]delegate]window]];
//                                    
//                                    //不让有重合的设置项 switch开关打开
//                                    setmodel.isUsed = @(0);
//                                    [manualTableView reloadData];
//                                }
//
//                            }
                            //是否是相同的时间段
                            BOOL  isSame = [current_startTime compare:arr_startTime] ==NSOrderedSame && [current_endTime compare:arr_endTime] ==NSOrderedSame;
                            //是否有重合
                            BOOL  isComplist = ([current_endTime compare:arr_startTime] ==NSOrderedSame||[current_endTime compare:arr_startTime] ==NSOrderedAscending)||([current_startTime compare:arr_endTime] ==NSOrderedSame||[current_startTime compare:arr_endTime] ==NSOrderedDescending);
                            if(!isSame && !isComplist){
                                //有重合
                                [HelpMsg showMessage:@"时间设置重合,请调整" inView:[[[UIApplication sharedApplication]delegate]window]];
                                
                                //不让有重合的设置项 switch开关打开
                                setmodel.isUsed = @(0);
                                [manualTableView reloadData];
                            }
                        
                        }
                        
                        
                    }
                }else{
                        setmodel.isUsed = @(0);
                
                }
                
                [manualCellArr replaceObjectAtIndex:indexPath.row withObject:setmodel];
            };
            secondcell.timeBlock = ^(NSString *times){
                
                NSArray *timeArray = [times componentsSeparatedByString:@"-"];
                if (timeArray.count ==2) {
                    setmodel.startTime = timeArray.firstObject;
                    setmodel.endTime = timeArray.lastObject;
                    setmodel.isUsed = @(0);
                    [manualCellArr replaceObjectAtIndex:indexPath.row withObject:setmodel];
                    [manualTableView reloadData];
                }
            };
            secondcell.settimeBlock = ^(SetListModel *model){
                [manualCellArr replaceObjectAtIndex:indexPath.row withObject:model];
            };
        }
        return secondcell;
    }
    
    
}


-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if (section==0) {
        return @"工作日期";
    }else{
        return @"配置清单";
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    
    if (section==0) {
        UIView* myView = [[UIView alloc] init];
        myView.backgroundColor = [UIConfig colorFromHexRGB:@"fbfbfb"];
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 90, 22)];
        titleLabel.textColor=[UIConfig colorFromHexRGB:@"848484"];
        titleLabel.backgroundColor = [UIColor clearColor];
        titleLabel.font = [UIFont systemFontOfSize:12];
        [titleLabel setText:@"工作日期"];
        [myView addSubview:titleLabel];
        return myView;
    }else{
        UIView* myView = [[UIView alloc] init];
        myView.backgroundColor = [UIConfig colorFromHexRGB:@"fbfbfb"];
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 90, 22)];
        titleLabel.textColor=[UIConfig colorFromHexRGB:@"848484"];
        titleLabel.backgroundColor = [UIColor clearColor];
        titleLabel.font = [UIFont systemFontOfSize:12];
        [titleLabel setText:@"配置清单"];
        [myView addSubview:titleLabel];
        return myView;
    }
}


@end
