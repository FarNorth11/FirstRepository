//
//  InsertDeviceDataRequest.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/25.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "HETRequest.h"

@interface InsertDeviceDataRequest : HETRequest

- (instancetype)initWithAccessToken: (NSString *)accessToken mac:(NSString *)mac dataType:(NSInteger)dataType data:(NSString *)data;


- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock;

@end
