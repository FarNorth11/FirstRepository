//
//  CodeScanViewController.h
//  CSuperAppliances
//
//  Created by starlueng on 16/5/18.
//  Copyright © 2016年 starlueng. All rights reserved.
//
#import <CoreLocation/CoreLocation.h>
#import "RootViewController.h"

//typedef void (^ReturnDeviceLoaction)(NSString * identify,NSString  *currentLoactionStr,NSNumber *deviceLongitude,NSNumber *deviceLatitude);

@interface CodeScanViewController : RootViewController<CLLocationManagerDelegate>

@property(nonatomic,strong) NSString *identify;//设备ID;
@property(nonatomic,strong) NSNumber *deviceLongitude; //当前设备定位的位置 经度
@property(nonatomic,strong) NSNumber *deviceLatitude; //当前设备定位的位置 纬度
@property(nonatomic,strong) NSString  *currentLoactionStr; //设备的位置信息
//@property (nonatomic, copy) ReturnDeviceLoaction   block;

@end
