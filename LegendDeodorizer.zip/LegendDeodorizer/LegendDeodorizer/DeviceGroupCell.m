
//
//  DeviceGroupCell.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/10.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "DeviceGroupCell.h"

@implementation DeviceGroupCell

@synthesize titleLabel,rightButton;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        [self fillCell];
    }
    return self;
}

- (void) fillCell
{
    
    titleLabel    = [[UILabel alloc]init];
    
    
    
    UIImage *myimage = [UIImage imageNamed:@"homeCellBg"];
    UIImageView *bgImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 65)];
    bgImageView.image = myimage;
    [self addSubview:bgImageView];
    
    [titleLabel setFrame:CGRectMake(0, 0, 50, 16)];
    titleLabel.textColor = [UIConfig colorFromHexRGB:@"222222"];
    titleLabel.textAlignment = NSTextAlignmentLeft;
    titleLabel.textColor = [UIConfig colorFromHexRGB:@"ffffff"];
    titleLabel.font = [UIFont systemFontOfSize:16.0f];
    titleLabel.center = CGPointMake(38, bgImageView.center.y);
    
    
//    rightImageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"arrow_right"]];
//    
//    rightImageView.center = CGPointMake( ScreenWidth-30, bgImageView.center.y);
//
//    
//    
//    [bgImageView addSubview:rightImageView];
    
    
    rightButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 30,30)];
    rightButton.center = CGPointMake( ScreenWidth-30, bgImageView.center.y);
    [rightButton setImage:[UIImage imageNamed:@"gouxuan_xz"] forState:UIControlStateSelected];
    [rightButton setImage:[UIImage imageNamed:@"gouxun"] forState:UIControlStateNormal];
    [bgImageView addSubview:rightButton];
    
    [bgImageView addSubview:titleLabel];
    
}

@end
