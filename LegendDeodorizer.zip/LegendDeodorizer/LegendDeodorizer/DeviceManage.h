//
//  DeviceManage.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/6.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^HETDeviceConfigSet)();
typedef void(^HETDeviceListGet)();
typedef void(^HETDeviceListByGroup)(NSMutableArray *devicelist);
typedef void(^HETDeviceError)(NSError *error, NSInteger statusCode);

@interface DeviceManage : NSObject
@property (nonatomic,strong) NSMutableArray *myDeviceList;//所有的设备
@property (nonatomic,strong) NSMutableArray *myDeviceGroupList;//所有的设备
@property (nonatomic,strong) NSArray *SupportDeviceType;//DeviceTypeModel对象数组
+(DeviceManage *)sharedInstance;

-(void)getDeviceGroupListRequsetSuccess:(void(^)()) groupList fail:(void(^)(NSError *error, NSInteger statusCode)) error;

- (void)getDeviceBindRequestSuccess:(void(^)()) deviceList  fail:(void(^)(NSError *error, NSInteger statusCode))   error;

- (void)getDevicelistByGroupGid:(NSInteger )gid Success:(void(^)(NSMutableArray *devicelist))deviceList  fail:(void(^)(NSError *error, NSInteger statusCode))   error;

@end
