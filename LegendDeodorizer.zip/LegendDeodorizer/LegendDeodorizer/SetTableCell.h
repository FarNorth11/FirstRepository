//
//  SetTableCell.h
//  Common_Refrigerator
//
//  Created by starlueng on 16/1/11.
//  Copyright © 2016年 starlueng. All rights reserved.
//
#import <UIKit/UIKit.h>

@interface SetTableCell : UITableViewCell

//@property (nonatomic,strong) UIImageView *leftImageView;//左视图

@property (nonatomic,strong) UILabel *midLabel;//左视图说明

//@property (nonatomic,strong) UIImageView *rightImageView;//右视图
//
//@property (nonatomic,strong) UIImageView *noticeView ;//提醒消息

- (void)setcellFrameWith:(BOOL)isLoginView AndRadius:(BOOL)radius AndShowNotice:(BOOL)show;
@end
