//
//  SetDeviceLocationRequest.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/5.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "HETRequest.h"

@interface SetDeviceLocationRequest : HETRequest

- (instancetype)initWithAccessToken: (NSString *)accessToken identify:(NSString *)identify mac:(NSString *)mac deviceLongitude:(NSNumber *)deviceLongitude deviceLatitude:(NSNumber *)deviceLatitude  deviceAddress:(NSString *)deviceAddress;

- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock;

@end
