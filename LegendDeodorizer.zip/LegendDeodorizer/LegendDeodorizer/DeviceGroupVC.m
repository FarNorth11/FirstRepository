//
//  DeviceGroupVC.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/10.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "DeviceGroupVC.h"
#import "UINavigationController+FDFullscreenPopGesture.h"
#import "GetGroupListRequest.h"
#import "DeviceGroupCell.h"
#import "GroupListModel.h"

static const NSInteger backTag           =5;//右侧按钮tag
static const NSInteger saveTag           =2;//右侧按钮tag

@interface DeviceGroupVC (){

    UITableView *mainTableView;
    NSMutableArray *_groupListArr;
}

@end

@implementation DeviceGroupVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.fd_prefersNavigationBarHidden = YES;
    [self addNaviView];
    [self addTableView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark ===================action===================

-(void)buttonClick:(id)sender{
    
    if ([sender isKindOfClass:[UIButton class]]) {
        UIButton *button = (UIButton *)sender;
        switch (button.tag) {
            case backTag:
            {
                //                AppDelegate *app =(AppDelegate *)[UIApplication sharedApplication].delegate;
                //                app.root.tabBar.hidden = NO;
                //                app.root.button.hidden = NO;
                //                app.root.selectedIndex =0;
                
                if(self.block){
                    self.block(self.groupName,self.gid);
                    [self dismissViewControllerAnimated:YES completion:nil];
                }
            }
                break;
            default:{
                
            }
                break;
        }
        
    }
    
    
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
          [self getDeviceListByGroup];
    });
  
}

#pragma mark ===================Request===================
-(void)getDeviceListByGroup{
    GetGroupListRequest *getGroupList = [[GetGroupListRequest alloc]initWithAccessToken:[HETUserInfo userInfo].accessToken pageIndex:@(1) pageRows:@(20)];
    _groupListArr = [[NSMutableArray alloc]initWithCapacity:8];
    MBProgressHUD *huddL =[HelpMsg showCustomHudtitle:@"加载中" targetView:self.view];
    [getGroupList startWithSuccessBlockDictionaryParameter:^(NSDictionary *dictValue) {
        [huddL hide:YES];
        if (dictValue!=nil ) {
            NSArray *groupArr = [dictValue objectForKey:@"list"];
            for (int i=0; i<groupArr.count; i++) {
                [_groupListArr addObject:[[GroupListModel alloc]initWithData:groupArr[i]]];
            }
        }
        [mainTableView reloadData];
        NSLog(@"成功");
    } failure:^(NSError *error, NSInteger statusCode) {
        [huddL hide:YES];
        NSLog(@"失败");
        if (error.code == 0) {
            [HelpMsg showMessage:@"当前网络不可用" inView:[[UIApplication sharedApplication].delegate window]];
        }
    }];
}


-(void) saveDeviceGroupInfo{
    
    
}
#pragma mark ===================UI===================
-(void)addNaviView{
    UIView *navView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, NAVIBARHEIGHT+STATUSBARHEIGHT)];
    navView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:navView];
    
    CALayer *lineLayer = [[CALayer alloc]init];
    lineLayer.frame = CGRectMake(0, NAVIBARHEIGHT+STATUSBARHEIGHT-1, ScreenWidth, SINGLE_LINE_WIDTH);
    lineLayer.backgroundColor = KCOLOR(@"c7c7c7").CGColor;
    [navView.layer addSublayer:lineLayer];
    
    UIButton *leftBtn =[UIButton setButtonWithNomalImage:[UIImage imageNamed:@"arrow_back_black"] AndSelectImage:[UIImage imageNamed:@"arrow_back_black"] AndFrame:CGRectMake(0, STATUSBARHEIGHT, 60, NAVIBARHEIGHT)];
    leftBtn.imageEdgeInsets =UIEdgeInsetsMake(0, 0, 0, 0);
    leftBtn.tag = backTag;
    [leftBtn addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
    [navView addSubview:leftBtn];
    
    UILabel *label =[UILabel setLabelWith:@"我的分组" AndFont:[UIFont systemFontOfSize:18] AndIsNumberOfLines:NO AndtextColor:[UIColor blackColor] AndFrame:CGRectMake((ScreenWidth-100)/2, STATUSBARHEIGHT, 100, NAVIBARHEIGHT) AndAlignment:NSTextAlignmentCenter];
    [navView addSubview:label];
    
    
}

-(void)addTableView{
    mainTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, NAVIBARHEIGHT+STATUSBARHEIGHT, ScreenWidth, ScreenHeight - NAVIBARHEIGHT-STATUSBARHEIGHT)];
    mainTableView.delegate =self;
    mainTableView.dataSource =self;
    
    UIView *footView =[[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, SINGLE_LINE_WIDTH)];
    footView.backgroundColor =[UIConfig colorFromHexRGB:@"c7c8cc"];
    mainTableView.tableFooterView = footView;
    [self.view addSubview:mainTableView];
    
    
}
#pragma mark - Table view data source

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 70;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return _groupListArr.count;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    DeviceGroupCell * cell = [tableView dequeueReusableCellWithIdentifier:@"HomepageCell"];
    if (cell == nil)  {
        cell = [[DeviceGroupCell alloc] initWithStyle:UITableViewCellStyleSubtitle  reuseIdentifier:@"HomepageCell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    if(_groupListArr.count !=0){
        GroupListModel *mode = _groupListArr[indexPath.section];
        cell.titleLabel.text = mode.groupName;
        
        if([self.groupName isEqualToString:mode.groupName]){
            cell.rightButton.selected =YES;
        }else{
            cell.rightButton.selected =NO;
        }
    }
    

    
    
    return cell;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    GroupListModel *mode = _groupListArr[indexPath.section];
    self.groupName = mode.groupName;
    self.gid = mode.gid;
//    [mainTableView reloadData];
    if(self.block){
        self.block(self.groupName,self.gid);   
    }
    [self dismissViewControllerAnimated:YES completion:nil];

    
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
