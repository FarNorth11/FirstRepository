//
//  RootTabBarViewController.h
//  Common_Refrigerator
//
//  Created by starlueng on 16/1/9.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LSYTabbarItem.h"
@interface RootTabBarViewController : UITabBarController<UITabBarControllerDelegate>

//@property (nonatomic,strong) LSYTabbarItem *lsyTabbarView;

@property(nonatomic,strong) UIButton *button;
@end
