//
//  GroupListModel.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/6.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GroupListModel : NSObject

@property (nonatomic,assign) NSInteger gid;
@property (nonatomic,strong) NSString *deviceNum;
@property (nonatomic,strong) NSString *groupName;



-(instancetype)initWithData:(NSDictionary *)dic;
@end
