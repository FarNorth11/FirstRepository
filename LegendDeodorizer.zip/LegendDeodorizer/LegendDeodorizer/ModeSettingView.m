//
//  ModeSettingView.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/31.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "ModeSettingView.h"
#import "SmartModeView.h"
#import "ManualModeView.h"

@implementation ModeSettingView{
    UIButton *smartModeBtn;
    UIButton *manualModeBtn;
    UIView *topBarView ;
    UIScrollView *MyScrollView;
    NSInteger PageCount;
    
    UITableView *smartTableView;
    UITableView *manualTableView;

}


- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self createBarView];
        [self createScrollView];
        
    }
    return self;
}

-(void)createBarView{
    topBarView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 64)];
    topBarView.backgroundColor = WHITECOLOR;
    [self addSubview:topBarView];
    
    
    smartModeBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth/2, topBarView.frame.size.height)];
    smartModeBtn.tag = 1;
    [smartModeBtn setBackgroundImage:[UIImage imageNamed:@"cellBg"] forState:UIControlStateSelected];
    smartModeBtn.selected = YES;
    [smartModeBtn setTitle:@"智能模式" forState:UIControlStateNormal];
    [smartModeBtn setTitleColor:[UIConfig colorFromHexRGB:@"c7c7c7"] forState:UIControlStateNormal];
    [smartModeBtn setTitleColor:WHITECOLOR forState:UIControlStateSelected];
    [smartModeBtn addTarget:self action:@selector(BatClick:) forControlEvents:UIControlEventTouchUpInside];
    [topBarView addSubview:smartModeBtn];
    
    manualModeBtn = [[UIButton alloc]initWithFrame:CGRectMake(ScreenWidth/2, 0, ScreenWidth/2, topBarView.frame.size.height)];
    manualModeBtn.tag = 2;
    [manualModeBtn setBackgroundImage:[UIImage imageNamed:@"cellBg"] forState:UIControlStateSelected];
    manualModeBtn.selected = 0;
    [manualModeBtn setTitle:@"手动模式" forState:UIControlStateNormal];
    [manualModeBtn setTitleColor:[UIConfig colorFromHexRGB:@"c7c7c7"] forState:UIControlStateNormal];
    [manualModeBtn setTitleColor:WHITECOLOR forState:UIControlStateSelected];
    [manualModeBtn addTarget:self action:@selector(BatClick:) forControlEvents:UIControlEventTouchUpInside];
    [topBarView addSubview:manualModeBtn];
    

}

-(void)createScrollView{
    MyScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(topBarView.frame), ScreenWidth, self.frame.size.height - topBarView.frame.size.height)];
    MyScrollView.delegate = self;
    MyScrollView.backgroundColor = [UIConfig colorFromHexRGB:@"fbfbfb"];
    // 隐藏水平滚动条
    MyScrollView.showsHorizontalScrollIndicator = NO;
    MyScrollView.showsVerticalScrollIndicator = NO;
    MyScrollView.pagingEnabled = YES;
    MyScrollView.bounces = NO;
    [self addSubview:MyScrollView];
    
    SmartModeView *smartModeView = [[SmartModeView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, MyScrollView.frame.size.height)];
    smartModeView.backgroundColor = [UIColor yellowColor];
    [MyScrollView addSubview:smartModeView];

    
    
    ManualModeView *manualModeView = [[ManualModeView alloc]initWithFrame:CGRectMake(ScreenWidth, 0, ScreenWidth, MyScrollView.frame.size.height)];
    manualModeView.backgroundColor = [UIColor yellowColor];
    [MyScrollView addSubview:manualModeView];
    // 设置UIScrollView的滚动范围（内容大小）
    MyScrollView.contentSize = CGSizeMake(ScreenWidth*2, 0);
    
}

//-(UIView *)createsmartModeView{
//
//    UIView *smartModeView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, MyScrollView.frame.size.height)];
//    smartModeView.backgroundColor = [UIColor yellowColor];
//    
//    smartTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, smartModeView.frame.size.height)];
//    
//    
//    [smartModeView addSubview:smartTableView];
//    
//    return smartModeView;
//}


-(void)BatClick:(id)sender{
    UIButton *btn = (UIButton *)sender ;
//    UIButton *btn2 = (UIButton *)[sender viewWithTag:2];
    btn.selected = YES;
    if (btn.tag==1) {
        manualModeBtn.selected = NO;
        MyScrollView.contentOffset= CGPointMake(0, 0) ;
    }else if(btn.tag ==2){
        smartModeBtn.selected = NO;
        MyScrollView.contentOffset = CGPointMake(ScreenWidth, 0) ;
    }

}

#pragma mark  ----UIScrollView------
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{

    NSLog(@"%@",scrollView);
    if(scrollView.contentOffset.x==0){
        //智能模式
        manualModeBtn.selected = NO;
        smartModeBtn.selected = YES;
    
    }else if(scrollView.contentOffset.x==ScreenWidth){
        //手动模式
        manualModeBtn.selected = YES;
        smartModeBtn.selected = NO;
    
    }
}
@end
