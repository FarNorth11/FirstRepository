//
//  DeviceControlController.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/28.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainDevice.h"
#import "GroupListModel.h"

@interface DeviceControlController : UIViewController<UICollectionViewDelegate,UICollectionViewDataSource>
@property(nonatomic,strong)MainDevice *device ;
@property(nonatomic,strong) GroupListModel *groupModel;
@property(nonatomic,strong) UILabel *titleLab;
@end
