//
//  main.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/27.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
