//
//  DeviceBtnView.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/29.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeviceBtnView : UIView

- (instancetype)initWithFrame:(CGRect)frame withTitle:(NSString *)title imageStr:(NSString *)imageStr;


@property(nonatomic,strong) UILabel *label;
@property(nonatomic,strong) UIButton *btn;
@end
