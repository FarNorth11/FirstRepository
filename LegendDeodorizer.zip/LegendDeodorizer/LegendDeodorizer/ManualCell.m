//
//  ManualCell.m
//  LegendDeodorizer
//
//  Created by Starlueng on 2017/3/31.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "ManualCell.h"
#import "ShowDetailView.h"
#import "TimePickerView.h"
#import "MinutePickerView.h"
@implementation ManualCell
{
    ShowDetailView *firstDetailView;
    ShowDetailView *secondview;
    ShowDetailView *thridview;
    UISwitch *setSwitch;
    SetListModel *_setmodel;
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        CGSize size = [@"99:99-99:99"sizeWithAttributes:@{NSFontAttributeName:[UIFont boldSystemFontOfSize:15]}];
        __weak typeof(self)Wself = self;
        firstDetailView = [[ShowDetailView alloc]initWithFrame:CGRectMake(16 *NewBasicWidth, 0, size.width, 72) Item:@"时段" detail:_setmodel TapAction:^(NSString *item) {
            NSLog(@"%@",item);
            
            TimePickerView *timePicker = [[TimePickerView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)andTimeReset:item AndSelectTime:^(NSString *string) {
                NSLog(@"%@",string);
                if (Wself.timeBlock) {
                    Wself.timeBlock(string);
                }
                firstDetailView.detailLabel.text = string;
            }];
            [self.window  addSubview:timePicker];
            
            
        }];
        [self.contentView addSubview:firstDetailView];
        
        size = [@"60分钟" sizeWithAttributes:@{NSFontAttributeName:[UIFont boldSystemFontOfSize:15]}];
        
        secondview = [[ShowDetailView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(firstDetailView.frame)+30 *NewBasicWidth, 0, size.width, 72) Item:@"开" detail:_setmodel TapAction:^(NSString *item) {
            NSLog(@"%@",item);
            MinutePickerView *minPicker = [[MinutePickerView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)andTimeReset:_setmodel AndSelectTime:^(SetListModel *select) {
                if (Wself.settimeBlock) {
                    Wself.settimeBlock(select);
                }
                secondview.detailLabel.text = [NSString stringWithFormat:@"%@分钟",_setmodel.openTime?:@0];
                thridview.detailLabel.text = [NSString stringWithFormat:@"%@分钟",_setmodel.stopTime?:@0];
            }];
            [self.window  addSubview:minPicker];

        }];
        secondview.detailLabel.text = [NSString stringWithFormat:@"%@分钟",_setmodel.openTime?:@0];
        [self.contentView addSubview:secondview];
        
        thridview = [[ShowDetailView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(secondview.frame)+15 *NewBasicWidth, 0, size.width, 72) Item:@"停" detail:_setmodel TapAction:^(NSString *item) {
            NSLog(@"%@",item);
            MinutePickerView *minPicker = [[MinutePickerView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight) andTimeReset:_setmodel AndSelectTime:^(SetListModel *select) {
                if (Wself.settimeBlock) {
                    Wself.settimeBlock(select);
                }
                secondview.detailLabel.text = [NSString stringWithFormat:@"%@分钟",_setmodel.openTime?:@0];
                thridview.detailLabel.text = [NSString stringWithFormat:@"%@分钟",_setmodel.stopTime?:@0];
            }];
            [self.window  addSubview:minPicker];
        }];
        thridview.detailLabel.text = [NSString stringWithFormat:@"%@分钟",_setmodel.stopTime?:@0];
        [self.contentView addSubview:thridview];
        
        setSwitch = [[UISwitch alloc]initWithFrame:CGRectMake(ScreenWidth -60 , 14, 44 , 44)];
        [self.contentView addSubview:setSwitch];
        setSwitch.onTintColor = [UIConfig colorFromHexRGB:@"0abf9c"];
        [setSwitch addTarget:self action:@selector(changeState:) forControlEvents:UIControlEventValueChanged];
    }
    return self;
}
- (void)changeState:(UISwitch *)sender{
    if (sender.isOn) {
        firstDetailView.isHightSelect = YES;
        secondview.isHightSelect = YES;
        thridview.isHightSelect = YES;
    }else{
        firstDetailView.isHightSelect = NO;
        secondview.isHightSelect = NO;
        thridview.isHightSelect = NO;
    }
    if (self.switchblock) {
        self.switchblock(sender);
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setManualCellData:(SetListModel *)setListModel{
    _setmodel = setListModel;
    NSString *start_endTime = [NSString stringWithFormat:@"%@-%@",setListModel.startTime,setListModel.endTime];
    [firstDetailView.detailLabel setText:start_endTime];
    
    [secondview.detailLabel setText:[NSString stringWithFormat:@"%@分钟",setListModel.openTime]];
    
    [thridview.detailLabel setText:[NSString stringWithFormat:@"%@分钟",setListModel.stopTime]];
    
    setSwitch.on = setListModel.isUsed.boolValue;
    if (setSwitch.isOn) {
        firstDetailView.isHightSelect = YES;
        secondview.isHightSelect = YES;
        thridview.isHightSelect = YES;
    }else{
        firstDetailView.isHightSelect = NO;
        secondview.isHightSelect = NO;
        thridview.isHightSelect = NO;
    }
}

@end
