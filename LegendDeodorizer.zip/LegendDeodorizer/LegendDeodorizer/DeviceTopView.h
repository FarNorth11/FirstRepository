//
//  DeviceTopView.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/29.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeviceTopView : UIView

@property(nonatomic,strong) UIImageView *liquidImgView;
@property(nonatomic,strong) UILabel *currentModeLab;
@property(nonatomic,strong) UILabel *currentMPPMLab;

-(void)setImageValue:(NSInteger )value;
@end
