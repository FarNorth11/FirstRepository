//
//  ModeSetting_ScrollView.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/11.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SmartModeView.h"
#import "ManualModeView.h"


typedef void (^ returnModeSetting)(NSInteger modeType,NSString *week,NSString *threshold,NSArray * setList);

@interface ModeSetting_ScrollView : UIView<returnModeSettingDelegate>
@property(nonatomic,strong)NSMutableArray *modeDataArr;
@property(nonatomic,strong)SmartModeView *smartModeView;
@property(nonatomic,strong)ManualModeView *manualModeView;
@property (nonatomic, copy) returnModeSetting   block;
-(void)getDataMode;

@end
