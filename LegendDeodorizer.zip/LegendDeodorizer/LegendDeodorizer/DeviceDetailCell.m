//
//  DeviceDetailCell.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/7.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "DeviceDetailCell.h"

@implementation DeviceDetailCell
@synthesize leftLabel;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        [self fillCell];
    }
    return self;
}

- (void) fillCell
{
    
    leftLabel    = [[UILabel alloc]init];
    [leftLabel setFrame:CGRectMake(10*NewBasicWidth, 5*NewBasicHeight, self.frame.size.width, self.frame.size.height)];
    leftLabel.textAlignment = NSTextAlignmentLeft;
    leftLabel.textColor = [UIColor blackColor];
    leftLabel.numberOfLines = 0;
    leftLabel.font = [UIFont systemFontOfSize:16.0f];
//    leftLabel.center = CGPointMake(50, self.center.y);
    [self addSubview:leftLabel];
    
}


//-(void) fillCellSpecific{
//
//
//    leftLabel    = [[UILabel alloc]init];
//    [leftLabel setFrame:CGRectMake(10*NewBasicWidth, 5*NewBasicHeight, self.frame.size.width*0.7, self.frame.size.height)];
//    leftLabel.textAlignment = NSTextAlignmentLeft;
//    leftLabel.textColor = [UIColor blackColor];
//    leftLabel.numberOfLines = 0;
//    leftLabel.font = [UIFont systemFontOfSize:16.0f];
//    //    leftLabel.center = CGPointMake(50, self.center.y);
//    [self addSubview:leftLabel];
//
//    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(CGRectGetMaxX(leftLabel.frame), 0, self.frame.size.width*0.3, self.frame.size.height)];
//    [btn setImage:[UIImage imageNamed:@"dingwei"] forState:UIControlStateNormal];
//    [btn setTitle:@"定位" forState:UIControlStateNormal];
//    [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
//    [btn setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 0)];
//    [btn setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 30, 0)];
//    [btn addTarget:self action:@selector(ScanQuickMark:) forControlEvents:UIControlEventTouchUpInside];
//    [self addSubview:btn];
//
//}



@end
