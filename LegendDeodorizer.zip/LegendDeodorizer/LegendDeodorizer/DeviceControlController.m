//
//  DeviceControlController.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/28.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "DeviceControlController.h"
#import "DeviceBtnView.h"
#import "DeviceBtnCell.h"
#import "DeviceTopView.h"
#import "DeviceDetailController.h"
#import "CSBusinessCenter.h"
//#import "HETDeviceControlBusiness.h"
#import "ControlDataModel.h"
#import "DeviceRunDataModel.h"
#import "ModeSettingController.h"
#import "UINavigationController+FDFullscreenPopGesture.h"
#import "BaseAlert.h"
#import "Reachability.h"
#import "InsertDeviceDataRequest.h"
#import "GetDeviceDataRequest.h"
#import <arpa/inet.h>


static const NSInteger moreTag           =2;//右侧按钮tag
static const NSInteger backTag           =5;//右侧按钮tag

@interface DeviceControlController ()
@property(nonatomic,strong)Reachability *hostReach;

@end

@implementation DeviceControlController{
    NSMutableDictionary * contorlDataModel;
    NSMutableDictionary * runDataModel;
//    NSMutableDictionary *currentControlDataModel;
    ControlDataModel *currentControlDataModel;
    DeviceRunDataModel *  deviceRunDataModel;
    UICollectionView *mainCollectionView;
    DeviceTopView *topView;
    MBProgressHUD *huddL ;
    BOOL isError;
    BOOL isRefreshData;
    BOOL fiveRefresh;
    NSTimer *getCfgInfoTimer;

}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    isError = NO;
    isRefreshData = NO;
    fiveRefresh = NO;
    self.view.backgroundColor = [UIColor whiteColor];
    contorlDataModel = [[NSMutableDictionary alloc]initWithCapacity:8];
    runDataModel = [[NSMutableDictionary alloc]initWithCapacity:8];
    self.fd_prefersNavigationBarHidden = YES;
    [self createUI];
    
//    //开启网络状况的监听
//    
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reachabilityChanged:) name:kReachabilityChangedNotification object:nil];
//    
//    self.hostReach = [Reachability reachabilityWithHostName:@"www.baidu.com"] ;
//    
//    //开始监听，会启动一个run loop
//    
//    [self.hostReach startNotifier];
    
    getCfgInfoTimer = [NSTimer scheduledTimerWithTimeInterval:8 target:self selector:@selector(periodSearchInternetConnect) userInfo:nil repeats:YES];
    
    
    

    

}


-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self deviceControllerStart];
    [[CSBusinessCenter shareInstance].controlBusiness start];
    [CSBusinessCenter shareInstance].setJsonBlock = ^(id data) {
        isRefreshData = YES;
        if (huddL) {
            [huddL hide:YES];
            huddL =nil;
        }
        [HelpMsg showMessage:@"设置成功" inView:[[[UIApplication sharedApplication]delegate]window]];
        
        if([data isKindOfClass:[NSString class]]){
            NSString *jsonStr = data;
            NSData *jsonData = [jsonStr dataUsingEncoding:NSUTF8StringEncoding];
            NSError *err;
            
            NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                 
                                                                options:NSJSONReadingMutableContainers
                                 
                                                                  error:&err];
            
            if(err) {
                
                NSLog(@"json解析失败：%@",err);
                
            }
            if([[contorlDataModel objectForKey:@"updateFlag"] isEqualToString:@"0200"]&&[[contorlDataModel objectForKey:@"Atomizerchannel"] integerValue]==3){
                currentControlDataModel.Atomizerchannel = Model_AB;
            }
            currentControlDataModel.Atomizerchannel = [[dic objectForKey:@"Atomizerchannel"] integerValue];
            currentControlDataModel.power = [[dic objectForKey:@"power"] integerValue];
            currentControlDataModel.Airlevel = [[dic objectForKey:@"Airlevel"] integerValue];
            currentControlDataModel.concentration = [[dic objectForKey:@"concentration"] integerValue];
            currentControlDataModel.sound = [[dic objectForKey:@"sound"] integerValue];
            currentControlDataModel.mode = [[dic objectForKey:@"mode"] integerValue];
            currentControlDataModel.wash = [[dic objectForKey:@"wash"] integerValue];
            [mainCollectionView reloadData];
            
        }

  
    };
    
    [CSBusinessCenter shareInstance].setErrorBlock = ^(id data) {
        if (huddL) {
            [huddL hide:YES];
            huddL =nil;
        }
        [HelpMsg showMessage:@"设置失败" inView:[[[UIApplication sharedApplication]delegate]window]];
    };
    
    //如果是设备不在线状态
    if([self.device.onlineStatus integerValue]==2){
        GetDeviceDataRequest *getDevice1 =[[GetDeviceDataRequest alloc] initWithAccessToken:[HETUserInfo userInfo].accessToken mac:self.device.macAddress dataType:1];
        [getDevice1 startWithSuccess:^(NSDictionary *dictValue) {
//            {
//                data = "{\n  \"Deodorant\" : 1,\n  \"Ammoniahigh\" : 0,\n  \"Ammonialow\" : 0\n}";
//                dateTime = "2017-04-26 08:12:25";
//            }
            
            if(dictValue.count ==2){
                NSString *jsonStr = [dictValue objectForKey:@"data"];
                NSError *parseError = nil;
                 NSData *resData = [[NSData alloc] initWithData:[jsonStr dataUsingEncoding:NSUTF8StringEncoding]];
                NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:resData
                                     
                                                                    options:NSJSONReadingMutableContainers
                                     
                                                                      error:&parseError];
                if (deviceRunDataModel==nil) {
                    deviceRunDataModel = [[DeviceRunDataModel alloc]init];
                }
                
                [deviceRunDataModel setValuesForKeysWithDictionary:dic];
                [self RefreshRunDate];
                
            
            }
            
        } failure:^(NSError *error, NSInteger statusCode) {
            
        }];
        
        
        GetDeviceDataRequest *getDevice2 =[[GetDeviceDataRequest alloc] initWithAccessToken:[HETUserInfo userInfo].accessToken mac:self.device.macAddress dataType:2];
        [getDevice2 startWithSuccess:^(NSDictionary *dictValue) {
            if(dictValue.count ==2){
                NSString *jsonStr = [dictValue objectForKey:@"data"];
                NSError *parseError = nil;
                NSData *resData = [[NSData alloc] initWithData:[jsonStr dataUsingEncoding:NSUTF8StringEncoding]];
                NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:resData
                                     
                                                                    options:NSJSONReadingMutableContainers
                                     
                                                                      error:&parseError];
                
                currentControlDataModel = [[ControlDataModel new] initWithData:dic];
                [mainCollectionView reloadData];
                
                if(currentControlDataModel.mode ==1){
                    [topView.currentModeLab setText:@"智能模式"];
                }else{
                    [topView.currentModeLab setText:@"标准模式"];
                }
            
            
            }
            
        } failure:^(NSError *error, NSInteger statusCode) {
            
        }];

    
    }
    
    
    
}


-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[CSBusinessCenter shareInstance].controlBusiness stop];
    [getCfgInfoTimer invalidate];
    getCfgInfoTimer = nil;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


//-(void)reachabilityChanged:(NSNotification *)note
//
//{
//    
//    Reachability *currReach = [note object];
//    
//    NSParameterAssert([currReach isKindOfClass:[Reachability class]]);
//    
//    //对连接改变做出响应处理动作
//    NetworkStatus status = [currReach currentReachabilityStatus];
//    if (status == ReachableViaWWAN||status == ReachableViaWiFi) {
//       NSString *cerere =  [[NSUserDefaults standardUserDefaults] valueForKey:@"currentRunData"];
//        if ( [[NSUserDefaults standardUserDefaults] valueForKey:@"currentRunData"]!=nil) {
//            [self InsertDeviceDataRequest:1 jsonStr:[[NSUserDefaults standardUserDefaults] valueForKey:@"currentRunData"]];
//        }
//        if ([[NSUserDefaults standardUserDefaults] valueForKey:@"currentControlData"]!=nil) {
//             [self InsertDeviceDataRequest:2 jsonStr:[[NSUserDefaults standardUserDefaults] valueForKey:@"currentControlData"]];
//        }
//        
//    }
//    
//
//
//}
-(void)createUI{
    topView = [[DeviceTopView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight*0.45)];
    [self.view addSubview:topView];
    
        
    UIButton *leftBtn =[UIButton setButtonWithNomalImage:[UIImage imageNamed:@"arrow_back"] AndSelectImage:[UIImage imageNamed:@"arrow_back"] AndFrame:CGRectMake(0, STATUSBARHEIGHT, 60, NAVIBARHEIGHT)];
    
    leftBtn.imageEdgeInsets =UIEdgeInsetsMake(0, 0, 0, 0);
    leftBtn.tag = backTag;
    [leftBtn addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
    [topView addSubview:leftBtn];
    
    _titleLab =[UILabel setLabelWith:@"除臭机" AndFont:[UIFont systemFontOfSize:18] AndIsNumberOfLines:NO AndtextColor:WHITECOLOR AndFrame:CGRectMake((ScreenWidth-100)/2, STATUSBARHEIGHT, 100, NAVIBARHEIGHT) AndAlignment:NSTextAlignmentCenter];
    _titleLab.text = _device.deviceName;
    [topView addSubview:_titleLab];
    
    UIButton *rightBtn =[UIButton setButtonWithNomalImage:[UIImage imageNamed:@"pub_13"] AndSelectImage:[UIImage imageNamed:@"pub_13"] AndFrame:CGRectMake(ScreenWidth -60, STATUSBARHEIGHT, 60, NAVIBARHEIGHT)];
    rightBtn.tag = moreTag;
    rightBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 0);
    [topView addSubview:rightBtn];
    
    [rightBtn addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];


    
    UICollectionViewFlowLayout *flowLayout= [[UICollectionViewFlowLayout alloc]init];
    [flowLayout setItemSize:CGSizeMake(ScreenWidth/3-1, ScreenWidth/3-10)];
    //UIEdgeInsetsMake(CGFloat top, CGFloat left, CGFloat bottom, CGFloat right)
    [flowLayout setScrollDirection:UICollectionViewScrollDirectionVertical];//水平排序
    
    mainCollectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(topView.frame), ScreenWidth, ScreenHeight*0.55) collectionViewLayout:flowLayout];
    mainCollectionView.backgroundColor = [UIColor whiteColor];
    [mainCollectionView registerClass:[DeviceBtnCell class] forCellWithReuseIdentifier:@"myCell"];
    
    mainCollectionView.delegate = self;
    mainCollectionView.dataSource = self;
    [self.view addSubview:mainCollectionView];

}

#pragma mark  ==================== Action  =====================

-(void)buttonClick:(id)sender{
    
    if ([sender isKindOfClass:[UIButton class]]) {
        UIButton *button = (UIButton *)sender;
        switch (button.tag) {
            case moreTag:
            {
                DeviceDetailController *deviceDetail = [[DeviceDetailController alloc]init];
                deviceDetail.device = self.device;
                [self.navigationController pushViewController:deviceDetail animated:YES];
                typeof(self) __weak weakSelf = self;
                deviceDetail.titleStringBlock = ^(NSString *titleStr){
                
                    weakSelf.titleLab.text = titleStr;
                
                };
                
                
            }
                break;
            case backTag:
            {
                [self.navigationController popViewControllerAnimated:YES];
            }
                break;
                
            default:{
                
            }
                break;
                
        }
        
    }
}


-(void)RefreshRunDate{
    if(deviceRunDataModel.Deodorant){
        
        CGFloat MPPM = ([deviceRunDataModel.Ammoniahigh intValue]*256+[deviceRunDataModel.Ammonialow intValue])/100;
        NSString * MPPMStr =[NSString stringWithFormat:@"%.2f",MPPM];
        
        CGSize anaSize1=[MPPMStr sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:30]}];
        [topView.currentMPPMLab setBounds:CGRectMake(0, 0, anaSize1.width, anaSize1.height)];
        topView.currentMPPMLab.text = MPPMStr ;
        [topView setImageValue:[deviceRunDataModel.Deodorant intValue]];
    }
    

    NSString *failStr=@"";
    
    if ([deviceRunDataModel.FanError intValue]== 1) {
        failStr=[failStr stringByAppendingString:@"风扇1故障 "];
    }
    if ([deviceRunDataModel.FanError2 intValue]== 1) {
        failStr=[failStr stringByAppendingString:@"风扇2故障  "];
    }
    if ([deviceRunDataModel.AtomizerError intValue]== 1) {
        failStr=[failStr stringByAppendingString:@"雾化器1故障 "];
    }
    if ([deviceRunDataModel.AtomizerError2 intValue]== 1) {
        failStr=[failStr stringByAppendingString:@"雾化器2故障 "];
    }
    if ([deviceRunDataModel.SolenoidValveError intValue]== 1) {
        failStr=[failStr stringByAppendingString:@"电磁阀1故障 "];
    }
    if ([deviceRunDataModel.SolenoidValveError2 intValue]== 1) {
        failStr=[failStr stringByAppendingString:@"电磁阀2故障 "];
    }
    if ([deviceRunDataModel.FluidPumpError intValue]== 1) {
        failStr=[failStr stringByAppendingString:@"加液泵故障 "];
    }
    if ([deviceRunDataModel.AmmoniaSensorError intValue]== 1) {
        failStr=[failStr stringByAppendingString:@"氨气传感器故障 "];
    }
    if ([deviceRunDataModel.LiquidLevelSensorError intValue]== 1) {
        failStr=[failStr stringByAppendingString:@"液箱液位传感器故障 "];
    }
    if ([deviceRunDataModel.WorkplaceLevelSensorError intValue]== 1) {
        failStr=[failStr stringByAppendingString:@"工作仓液位传感器故障 "];
    }
    
    if (![failStr isEqualToString:@""] && isError == NO) {
        isError = YES;
        [[BaseAlert shareInstance]alertWithAlertStyle:AlertStyleAlert title:@"故障" message:failStr cancelBtnTitle:NSLocalizedString(@"确定", @"") buttonList:nil AndSelectButtonAction:^(NSNumber *num) {
            
        }];
    }

}

//设备控制
-(void)deviceControllerStart{
    
    NSString *userKey =  self.device.userKey ;
    NSString *productId = [NSString stringWithFormat:@"%@",self.device.productId];
    NSString *deviceId =  self.device.deviceId ;
    NSString *deviceMac =  self.device.macAddress ;
    NSString *deviceTypeId =  @"7" ;
    NSString *deviceSubtypeId = @"15";
    [CSBusinessCenter shareInstance].CSDevice = self.device;
    [[CSBusinessCenter shareInstance].controlBusiness setDeviceUserKey:userKey withProductId:productId withDeviceId:deviceId withDeviceMac:deviceMac withDevicetypeId:deviceTypeId withDeviceSubtypeId:deviceSubtypeId deviceRunData:^(id responseObject) {
        
        /*
         故障数据请求成功--->{
         AmmoniaSensorError = 0;
         AtomizerError = 0;
         AtomizerError2 = 0;
         FanError = 0;
         FanError2 = 0;
         FluidPumpError = 0;
         LiquidLevelSensorError = 1;
         SolenoidValveError = 0;
         SolenoidValveError2 = 0;
         WorkplaceLevelSensorError = 0;
         "record_time" = 1492456775192;
         }
         */
         if([responseObject isKindOfClass:[NSDictionary class]])
        {
            NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
            dic=[responseObject mutableCopy];
            NSMutableDictionary *newdic=[[NSMutableDictionary alloc]init];
            [newdic setObject:@"1" forKey:@"type"];
            [newdic setObject:dic forKey:@"data"];
            
//            deviceRunDataModel  = [[DeviceRunDataModel alloc]initWithData:dic];
            
//            if (deviceRunDataModel==nil) {
//                deviceRunDataModel = [[DeviceRunDataModel alloc]init];
//            }
//            deviceRunDataModel = [deviceRunDataModel initWithData:dic];
            if (deviceRunDataModel==nil) {
                deviceRunDataModel = [[DeviceRunDataModel alloc]init];
            }
            
            [deviceRunDataModel setValuesForKeysWithDictionary:dic];
            [self RefreshRunDate];
            
            
            
            if(runDataModel!=nil &&dic!=nil && [[dic allKeys] containsObject:@"Deodorant"]){
                runDataModel = [NSMutableDictionary dictionaryWithDictionary:dic];
                NSLog(@"%@",runDataModel);
            }
        }
        
    } deviceCfgData:^(id responseObject) {
        if([responseObject isKindOfClass:[NSDictionary class]])
        {
            
//            if (contorlDataModel!=nil&&[[contorlDataModel objectForKey:@"Atomizerchannel"] integerValue]==3) {
            if(isRefreshData){
//                NSLog(@"Atomizerchannel:%ld",[[contorlDataModel objectForKey:@"Atomizerchannel"] integerValue]);
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    NSLog(@"该行代码只执行一次");
                
//                    [self performSelector:@selector(changeCfgData:) withObject:responseObject afterDelay:5];
                    
                    double delayInSeconds = 5.0;
                    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
                    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
                        isRefreshData = NO;
                        onceToken = 0;
                        
                    });
                    
                    

                });
                
            }else{
                NSLog(@"----------------------------非等待,刷新数据----------------------------");
                NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
                dic=responseObject;
                NSMutableDictionary *newdic=[[NSMutableDictionary alloc]init];
                [newdic setObject:@"0" forKey:@"type"];
                [newdic setObject:dic forKey:@"data"];
                currentControlDataModel = [[ControlDataModel new] initWithData:dic];
                [mainCollectionView reloadData];
                
                if(currentControlDataModel.mode ==1){
                    [topView.currentModeLab setText:@"智能模式"];
                }else{
                    [topView.currentModeLab setText:@"标准模式"];
                }
                /*
                 {
                 data =     {
                 AddLiquid = 0;
                 Airlevel = 0;
                 Atomizerchannel = 0;
                 QueryTiming = 0;
                 concentration = 0;
                 mode = 0;
                 power = 0;
                 sound = 0;
                 updateFlag = 0;
                 wash = 0;
                 };
                 type = 0;
                 }
                 */
                
                
                if(contorlDataModel!=nil &&dic!=nil){
                    contorlDataModel = [NSMutableDictionary dictionaryWithDictionary:dic];
                    NSLog(@"%@",contorlDataModel);
                    
                }

            }

        }
    }];

    [[CSBusinessCenter shareInstance].controlBusiness start];

}

-(void)changeCfgData:(id)responseObject{
    NSLog(@"----------------------------五秒钟内收到数据不刷新数据----------------------------");
    
    isRefreshData = NO;
    
//    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
//    dic=responseObject;
//    NSMutableDictionary *newdic=[[NSMutableDictionary alloc]init];
//    [newdic setObject:@"0" forKey:@"type"];
//    [newdic setObject:dic forKey:@"data"];
//    currentControlDataModel = [[ControlDataModel new] initWithData:dic];
//    [mainCollectionView reloadData];
//    
//    if(currentControlDataModel.mode ==1){
//        [topView.currentModeLab setText:@"智能模式"];
//    }else{
//        [topView.currentModeLab setText:@"标准模式"];
//    }
 
//    if(contorlDataModel!=nil &&dic!=nil){
//        contorlDataModel = [NSMutableDictionary dictionaryWithDictionary:dic];
//        NSLog(@"%@",contorlDataModel);
//        
//
//    }


}

//定义展示的Section的个数
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

//定义展示的UICollectionViewCell的个数
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 9;
}
//定义每个UICollectionView的间距
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(0, 0, 0, 0);
    
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    DeviceBtnCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"myCell" forIndexPath:indexPath];
    NSArray *titleArr =@[@"雾化器",@"风量",@"浓度",@"清洗",@"音量",@"模式",@"同步",@"",@"电源"];
    NSArray *imgArr =@[@"wuhuaqi1",@"fengliang1",@"nongdu1",@"qingxi",@"yinliang1",@"moshi",@"tongbu",@"",@"dianyuan"];
//    NSArray *imgArr=@[@[@"wuhuaqi1",@"wuhuaqi2",@"wuhuaqi3"],@[@"fengliang1",@"fengliang2",@"fengliang3"],@[@"nongdu1",@"nongdu2",@"nongdu3"]
//                       ,@"qingxi",@[@"yinliang1",@"yinliang2",@"yinliang3"],@"moshi",@"tongbu",@"",@"dianyuan"];
    
    if (indexPath.row ==7) {
        cell.BtnImageView.image = nil;
        [cell.midLabel setText:@""];
    }else if(indexPath.row ==0){
        if(currentControlDataModel !=nil){
            if (currentControlDataModel.Atomizerchannel == 1) {
                cell.BtnImageView.image = [UIImage imageNamed:@"wuhuaqi1"];
            }else if(currentControlDataModel.Atomizerchannel == 2){
                cell.BtnImageView.image = [UIImage imageNamed:@"wuhuaqi2"];
            }else{
                cell.BtnImageView.image = [UIImage imageNamed:@"wuhuaqi3"];
            }
        }else{
            cell.BtnImageView.image = [UIImage imageNamed:@"wuhuaqi1"];
        }
        [cell.midLabel setText:titleArr[indexPath.row]];
    }else if(indexPath.row ==1){
        if(currentControlDataModel !=nil){
            if (currentControlDataModel.Airlevel == 1) {
                cell.BtnImageView.image = [UIImage imageNamed:@"fengliang1"];
            }else if(currentControlDataModel.Airlevel == 2){
                cell.BtnImageView.image = [UIImage imageNamed:@"fengliang2"];
            }else{
                cell.BtnImageView.image = [UIImage imageNamed:@"fengliang3"];
            }
        }else{
            cell.BtnImageView.image = [UIImage imageNamed:@"fengliang1"];
        }
        [cell.midLabel setText:titleArr[indexPath.row]];
    }else if(indexPath.row ==2){
        if(currentControlDataModel !=nil){
            if (currentControlDataModel.concentration == 1) {
                cell.BtnImageView.image = [UIImage imageNamed:@"nongdu1"];
            }else if(currentControlDataModel.concentration == 2){
                cell.BtnImageView.image = [UIImage imageNamed:@"nongdu2"];
            }else{
                cell.BtnImageView.image = [UIImage imageNamed:@"nongdu3"];
            }
        }else{
            cell.BtnImageView.image = [UIImage imageNamed:@"nongdu1"];
        }
        [cell.midLabel setText:titleArr[indexPath.row]];
    }else if(indexPath.row ==4){
        if(currentControlDataModel !=nil){
            if (currentControlDataModel.sound == 1) {
                cell.BtnImageView.image = [UIImage imageNamed:@"yinliang1"];
            }else if(currentControlDataModel.sound == 2){
                cell.BtnImageView.image = [UIImage imageNamed:@"yinliang2"];
            }else{
                cell.BtnImageView.image = [UIImage imageNamed:@"yinliang3"];
            }
        }else{
            cell.BtnImageView.image = [UIImage imageNamed:@"yinliang1"];
        }
        [cell.midLabel setText:titleArr[indexPath.row]];
    }else if(indexPath.row == 8){
        if(currentControlDataModel !=nil){
            //1关机 2开机
            
            [cell.midLabel setText:titleArr[indexPath.row]];
            if(currentControlDataModel.power==1){
//                cell.BtnImageView.alpha = 1;
                cell.BtnImageView.image = [UIImage imageNamed:@"dianyuan_off"];
            }else{
                cell.BtnImageView.image = [UIImage imageNamed:@"dianyuan"];
            }
        }else{
            cell.BtnImageView.image = [UIImage imageNamed:@"dianyuan"];
        }

    }
    else{
        cell.BtnImageView.image = [UIImage imageNamed:imgArr[indexPath.row]];
        [cell.midLabel setText:titleArr[indexPath.row]];

    }
    cell.backgroundColor = [UIColor whiteColor];

    
    return cell;
}

// 设置最小行间距，也就是前一行与后一行的中间最小间隔
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {
    return 4;
}

// 设置最小列间距，也就是左行与右一行的中间最小间隔
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    return 1;
}

//UICollectionView被选中时调用的方法
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"%ld",(long)indexPath.row);
    if(indexPath.row ==5){
        //模式
        ModeSettingController *modeSetting = [[ModeSettingController alloc]init];
        modeSetting.device = self.device;
        [self presentViewController:modeSetting animated:YES completion:nil];
        modeSetting.clickBack=^(NSNumber *mode){
            [contorlDataModel  setObject:mode forKey:@"mode"];
            [contorlDataModel setObject:@"2000" forKey:@"updateFlag"];
            [self sendOrderToDevice:contorlDataModel];
        };
        

        //        NSInteger mode = [currentControlDataModel changeModel:currentControlDataModel.mode withMax:3];
        //        [contorlDataModel  setObject:@(mode) forKey:@"mode"];
        //        [contorlDataModel setObject:@"2000" forKey:@"updateFlag"];
    }else if(indexPath.row ==8){
        NSInteger mode = [currentControlDataModel changeModel:currentControlDataModel.power withMax:2];
        [contorlDataModel  setObject:@(mode) forKey:@"power"];
        [contorlDataModel setObject:@"0100" forKey:@"updateFlag"];
        [self sendOrderToDevice:contorlDataModel];
        
    }else if(indexPath.row ==6){
        //点击同步  有网的时候,直接上传  没网,就保存最新的数据到本地.  有网之后再上传.
        huddL =[HelpMsg showCustomHudtitle:@"数据发送中" targetView:self.view];
        
        //没网的情况下,判断是ap模式直接发送命令去同步
        [contorlDataModel setObject:@"0000" forKey:@"updateFlag"];
        
        if (runDataModel!=nil) {
            NSString *jsonStr =  [self dictionaryToJson:runDataModel];
            [[NSUserDefaults standardUserDefaults] setObject:jsonStr forKey:@"currentRunData"];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
        
        if (contorlDataModel!=nil) {
            NSString *jsonStr =  [self dictionaryToJson:contorlDataModel];
            [[NSUserDefaults standardUserDefaults] setObject:jsonStr forKey:@"currentControlData"];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }
        [self sendOrderToDevice:contorlDataModel];
        /*
        if(![self isInternetConnect]&&([[CSBusinessCenter shareInstance].controlBusiness isLittleLoop])){
            //没网的情况下,判断是ap模式直接发送命令去同步
            [contorlDataModel setObject:@"0000" forKey:@"updateFlag"];
            
            if (runDataModel!=nil) {
                NSString *jsonStr =  [self dictionaryToJson:runDataModel];
                [[NSUserDefaults standardUserDefaults] setValue:jsonStr forKey:@"currentRunData"];
                [[NSUserDefaults standardUserDefaults] synchronize];
            }
            
            if (contorlDataModel!=nil) {
                NSString *jsonStr =  [self dictionaryToJson:contorlDataModel];
                [[NSUserDefaults standardUserDefaults] setValue:jsonStr forKey:@"currentControlData"];
                [[NSUserDefaults standardUserDefaults] synchronize];
            }
            [self sendOrderToDevice:contorlDataModel];
            
            
        }else if([self isInternetConnect]){
            if (runDataModel!=nil&&contorlDataModel!=nil) {
                NSString *runDataJson =  [self dictionaryToJson:runDataModel];
                NSString *contorlDataJson =  [self dictionaryToJson:contorlDataModel];
//                [self InsertDeviceDataRequest:1 jsonStr:runDataJson];
//                dispatch_queue_t queue= dispatch_get_main_queue();
//                //第一个参数为串行队列的名称，是c语言的字符串
//                //第二个参数为队列的属性，一般来说串行队列不需要赋值任何属性，所以通常传空值（NULL） 28 29 //2.添加任务到队列中执行
//                dispatch_async(queue, ^{
//                    [self InsertDeviceDataRequest:1 jsonStr:runDataJson];
//                });
//                dispatch_async(queue, ^{
//                    [self InsertDeviceDataRequest:2 jsonStr:contorlDataJson];
//                });
//                huddL =[HelpMsg showCustomHudtitle:@"数据发送中" targetView:self.view];
                InsertDeviceDataRequest *insertRequest2 = [[InsertDeviceDataRequest alloc]initWithAccessToken:[HETUserInfo userInfo].accessToken mac:self.device.macAddress dataType:1 data:runDataJson];
                [insertRequest2 startWithSuccess:^(NSDictionary *dictValue) {
                    
//                    [HelpMsg showMessage:@"设置成功" inView:[[[UIApplication sharedApplication]delegate]window]];
                    NSLog(@"成功");
                    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"currentRunData"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    
                    [self InsertDeviceDataRequest:2 jsonStr:contorlDataJson];
//                    if (dataType ==1) {
//                        [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"currentRunData"];
//                        [[NSUserDefaults standardUserDefaults] synchronize];
//                    }else if(dataType ==2){
//                        [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"currentControlData"];
//                        [[NSUserDefaults standardUserDefaults] synchronize];
//                    }
                } failure:^(NSError *error, NSInteger statusCode) {
                    [huddL hide:YES];
                    [HelpMsg showMessage:@"设置失败" inView:[[[UIApplication sharedApplication]delegate]window]];
                    NSLog(@"失败");
                }];


            }
            
            
        }*/
        
    }else if(currentControlDataModel !=nil && currentControlDataModel.power ==2){
            if (indexPath.row ==0) {
                
                NSInteger mode = [currentControlDataModel changeModel:currentControlDataModel.Atomizerchannel withMax:3];
                [contorlDataModel  setObject:@(mode) forKey:@"Atomizerchannel"];
                [contorlDataModel setObject:@"0200" forKey:@"updateFlag"];
                
            }else if(indexPath.row ==1){
                NSInteger mode = [currentControlDataModel changeModel:currentControlDataModel.Airlevel withMax:3];
                [contorlDataModel  setObject:@(mode) forKey:@"Airlevel"];
                [contorlDataModel setObject:@"0400" forKey:@"updateFlag"];
            }
            else if(indexPath.row ==2){
                NSInteger mode = [currentControlDataModel changeModel:currentControlDataModel.concentration withMax:3];
                [contorlDataModel  setObject:@(mode) forKey:@"concentration"];
                [contorlDataModel setObject:@"0800" forKey:@"updateFlag"];
            }
            else if(indexPath.row ==3){
                NSInteger mode = [currentControlDataModel changeModel:currentControlDataModel.wash withMax:2];
                [contorlDataModel  setObject:@(mode) forKey:@"wash"];
                [contorlDataModel setObject:@"4000" forKey:@"updateFlag"];
            }
            else if(indexPath.row ==4){
                NSInteger mode = [currentControlDataModel changeModel:currentControlDataModel.sound withMax:3];
                [contorlDataModel  setObject:@(mode) forKey:@"sound"];
                [contorlDataModel setObject:@"1000" forKey:@"updateFlag"];
            }
            
            
            [self sendOrderToDevice:contorlDataModel];
            
        }else{
            [HelpMsg showMessage:@"设备关机状态下不可选择" inView:[[[UIApplication sharedApplication]delegate]window]];
        
        }
    
}

//-(void)InsertDeviceDataRequest:(NSInteger )dataType jsonStr:(NSString *)jsonStr{
//    InsertDeviceDataRequest *insertRequest2 = [[InsertDeviceDataRequest alloc]initWithAccessToken:[HETUserInfo userInfo].accessToken mac:self.device.macAddress dataType:dataType data:jsonStr];
//    [insertRequest2 startWithSuccess:^(NSDictionary *dictValue) {
//        [huddL hide:YES];
//        huddL =nil;
//        [HelpMsg showMessage:@"设置成功" inView:[[[UIApplication sharedApplication]delegate]window]];
//        
//        NSLog(@"成功");
//        if (dataType ==1) {
//            [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"currentRunData"];
//            [[NSUserDefaults standardUserDefaults] synchronize];
//        }else if(dataType ==2){
//            [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"currentControlData"];
//            [[NSUserDefaults standardUserDefaults] synchronize];
//        }
//    } failure:^(NSError *error, NSInteger statusCode) {
//        [huddL hide:YES];
//        huddL =nil;
//        [HelpMsg showMessage:@"设置失败" inView:[[[UIApplication sharedApplication]delegate]window]];
//        NSLog(@"失败");
//    }];
// 
//}
- (NSString*)dictionaryToJson:(NSDictionary*)dic
{
    NSString *str=@"";
    
    NSError *parseError = nil;
    
    
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&parseError];
    
    str = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
    return str;
    
}

-(void)periodSearchInternetConnect{
    
    
    if ([self isInternetConnect]) {
        if ([[NSUserDefaults standardUserDefaults] valueForKey:@"currentRunData"]!=nil&&[[NSUserDefaults standardUserDefaults] valueForKey:@"currentControlData"]!=nil) {
            NSString *runDataJson =  [[NSUserDefaults standardUserDefaults] valueForKey:@"currentRunData"];
            NSString *contorlDataJson =  [[NSUserDefaults standardUserDefaults] valueForKey:@"currentControlData"];

            InsertDeviceDataRequest *insertRequest2 = [[InsertDeviceDataRequest alloc]initWithAccessToken:[HETUserInfo userInfo].accessToken mac:self.device.macAddress dataType:1 data:runDataJson];
            [insertRequest2 startWithSuccess:^(NSDictionary *dictValue) {
                NSLog(@"成功");
                InsertDeviceDataRequest  *insertRequest3 = [[InsertDeviceDataRequest alloc]initWithAccessToken:[HETUserInfo userInfo].accessToken mac:self.device.macAddress dataType:1 data:runDataJson];
                [insertRequest3 startWithSuccess:^(NSDictionary *dictValue) {
                    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"currentRunData"];
                    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"currentControlData"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    
                } failure:^(NSError *error, NSInteger statusCode) {
                    NSLog(@"成功");
                }];
            } failure:^(NSError *error, NSInteger statusCode) {
                NSLog(@"失败");
            }];
  
        }

    }

}

-(BOOL)isInternetConnect{

    BOOL whether = YES;
    NSURL *url1 = [NSURL URLWithString:@"http://www.baidu.com"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url1 cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:10];
    NSHTTPURLResponse *response;
    [NSURLConnection sendSynchronousRequest:request returningResponse: &response error: nil];
    if (response == nil) {
        NSLog(@"没有网络");
        whether = NO;
    }
    else{
        NSLog(@"网络是通的");
    }
    return whether;
}

/// 服务器可达返回true
- (BOOL)socketReachabilityTest {
    // 客户端 AF_INET:ipv4  SOCK_STREAM:TCP链接
    int socketNumber = socket(AF_INET, SOCK_STREAM, 0);
    // 配置服务器端套接字
    struct sockaddr_in serverAddress;
    // 设置服务器ipv4
    serverAddress.sin_family = AF_INET;
    // 百度的ip
    serverAddress.sin_addr.s_addr = inet_addr("202.108.22.5");
    // 设置端口号，HTTP默认80端口
    serverAddress.sin_port = htons(80);
    if (connect(socketNumber, (const struct sockaddr *)&serverAddress, sizeof(serverAddress)) == 0) {
        close(socketNumber);
        return true;
    }
    close(socketNumber);

    return false;
}
-(void)sendOrderToDevice:(NSMutableDictionary *)dic{
    //点击了发送,就五秒后再刷数据
    isRefreshData = YES;
    if (huddL ==nil) {
        huddL =[HelpMsg showCustomHudtitle:@"数据发送中" targetView:self.view];
    }
    //大小循环
    if([[CSBusinessCenter shareInstance].controlBusiness isLittleLoop]){
        NSString *contorlDataModelStr= [self dictionaryToJson:dic];
        //小循环
//        MBProgressHUD *hud =[HelpMsg showCustomHudtitle:@"数据发送中" targetView:self.view];
//        huddL =[HelpMsg showCustomHudtitle:@"数据发送中" targetView:self.view];
        [[CSBusinessCenter shareInstance].controlBusiness nativeUIDeviceControlRequestWithJson:contorlDataModelStr withSuccessBlock:^(id responseObject) {
            [huddL hide:YES];
            huddL =nil;
            NSLog(@"----------------------------发送成功后,刷新数据----------------------------");
            [HelpMsg showMessage:@"设置成功" inView:[[[UIApplication sharedApplication]delegate]window]];
            
            if([[contorlDataModel objectForKey:@"updateFlag"] isEqualToString:@"0200"]&&[[contorlDataModel objectForKey:@"Atomizerchannel"] integerValue]==3){
                currentControlDataModel.Atomizerchannel = Model_AB;
            }
            currentControlDataModel.Atomizerchannel = [[dic objectForKey:@"Atomizerchannel"] integerValue];
            currentControlDataModel.power = [[dic objectForKey:@"power"] integerValue];
            currentControlDataModel.Airlevel = [[dic objectForKey:@"Airlevel"] integerValue];
            currentControlDataModel.concentration = [[dic objectForKey:@"concentration"] integerValue];
            currentControlDataModel.sound = [[dic objectForKey:@"sound"] integerValue];
            currentControlDataModel.mode = [[dic objectForKey:@"mode"] integerValue];
            currentControlDataModel.wash = [[dic objectForKey:@"wash"] integerValue];

            [mainCollectionView reloadData];
        } withFailBlock:^(NSError *error) {
            [huddL hide:YES];
            huddL =nil;
            [HelpMsg showMessage:@"命令发送失败" inView:[[[UIApplication sharedApplication]delegate]window]];
//            [HelpMsg showMessage:@"设备不在线" inView:[[UIApplication sharedApplication].delegate window]];
        }];
        
    }else{
        
        NSString *contorlDataModelStr= [self dictionaryToJson:dic];
    
        
        //json就是发送给设备的报文
        HETDeviceConfigSetRequest *request =[[HETDeviceConfigSetRequest alloc]initWithAccessToken:[HETUserInfo userInfo].accessToken deviceId:self.device.deviceId json:contorlDataModelStr];
//        huddL =[HelpMsg showCustomHudtitle:@"数据发送中" targetView:self.view];
//        typeof(self) __weak weakSelf = self;
        [request startWithSuccess:^{
            [huddL hide:YES];
            huddL =nil;
            NSLog(@"----------------------------发送成功后,刷新数据----------------------------");
            [HelpMsg showMessage:@"设置成功" inView:[[[UIApplication sharedApplication]delegate]window]];
            if([[contorlDataModel objectForKey:@"updateFlag"] isEqualToString:@"0200"]&&[[contorlDataModel objectForKey:@"Atomizerchannel"] integerValue]==3){
                currentControlDataModel.Atomizerchannel = Model_AB;
            }
            currentControlDataModel.Atomizerchannel = [[dic objectForKey:@"Atomizerchannel"] integerValue];
            currentControlDataModel.power = [[dic objectForKey:@"power"] integerValue];
            currentControlDataModel.Airlevel = [[dic objectForKey:@"Airlevel"] integerValue];
            currentControlDataModel.concentration = [[dic objectForKey:@"concentration"] integerValue];
            currentControlDataModel.sound = [[dic objectForKey:@"sound"] integerValue];
            currentControlDataModel.mode = [[dic objectForKey:@"mode"] integerValue];
            currentControlDataModel.wash = [[dic objectForKey:@"wash"] integerValue];
            [mainCollectionView reloadData];
            
        } failure:^(NSError *error, NSInteger statusCode) {
            [huddL hide:YES];
            huddL =nil;
            if (error.code ==100022006) {
                [HelpMsg showMessage:@"设备不在线" inView:[[UIApplication sharedApplication].delegate window]];
            }
//            if (error.code == 0) {
//                [HelpMsg showMessage:@"当前网络不可用" inView:[[UIApplication sharedApplication].delegate window]];
//            }
            [HelpMsg showMessage:@"命令发送失败" inView:[[UIApplication sharedApplication].delegate window]];
        }];
        
        
    }



}




/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
