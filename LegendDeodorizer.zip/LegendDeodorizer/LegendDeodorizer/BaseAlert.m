//
//  BaseAlert.m
//  AVcaptureShow
//
//  Created by starlueng on 16/6/29.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "BaseAlert.h"

@implementation BaseAlert
+ (instancetype)shareInstance{
    
    static BaseAlert *base = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        base = [[self alloc]init];
    });
    return base;
}
- (void)alertWithAlertStyle:(AlertStyle)alertStyle
                      title:(NSString *)title
                    message:(NSString *)message
             cancelBtnTitle:(NSString *)cancelTitle
                 buttonList:(NSArray *)buttonArray
      AndSelectButtonAction:(AlertBlock)actions{
    
    if (!cancelTitle) {
        cancelTitle = @"取消";
    }
    self.buttonList = buttonArray;
    self.actionShow = actions;
    UIViewController *controller = [UIConfig getCurrentVC];//获取当前vc
    
    if (IOS8) {
        
        NSInteger alertShowStyle = alertStyle;
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:alertShowStyle];
        //添加取消按钮
        UIAlertAction *alertAction = [UIAlertAction actionWithTitle:cancelTitle style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            actions(@(0));
        }];
        [alertController addAction:alertAction];
        //添加自定义按钮
        for (NSInteger i=0; i<buttonArray.count; i++) {
            
            UIAlertAction *alertAction = [UIAlertAction actionWithTitle:buttonArray[i] style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                actions(@(i+1));
            }];
            [alertController addAction:alertAction];
        }
        [controller presentViewController:alertController animated:YES completion:nil];
    }else{
    
        switch (alertStyle) {
            case AlertStyleActionSheet:
            {
                UIActionSheet *sheet =[[UIActionSheet alloc]initWithTitle:title delegate:self cancelButtonTitle:cancelTitle destructiveButtonTitle:nil otherButtonTitles:nil, nil];
                for (NSInteger i=0; i<buttonArray.count; i++) {
                    [sheet addButtonWithTitle:buttonArray[i]];
                }
                
                [sheet showInView:controller.view];
            }
                break;
            case AlertStyleAlert:
            {
                UIAlertView *alert = [[UIAlertView alloc]initWithTitle:title message:message delegate:self cancelButtonTitle:cancelTitle otherButtonTitles:nil, nil];
                for (NSInteger i=0; i<buttonArray.count; i++) {
                    [alert addButtonWithTitle:buttonArray[i]];
                }
               
                [alert show];
            }
                break;
            default:
                break;
        }
    
    }
}

#pragma mark-===========UIActionSheetDelegate===============
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (self.actionShow) {
        self.actionShow(@(buttonIndex));
    }

}
#pragma mark-==============UIAlertViewDelegate=================
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (self.actionShow) {
        self.actionShow(@(buttonIndex));
    }
}
@end
