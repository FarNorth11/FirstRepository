//
//  GetDeviceDataRequest.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/26.
//  Copyright © 2017年 Het. All rights reserved.
//
#import "HETRequest+Private.h"
#import "GetDeviceDataRequest.h"

@implementation GetDeviceDataRequest
{
    NSString  *_accessToken;
    NSString *_mac;
    NSInteger _dataType;
}

- (instancetype)initWithAccessToken: (NSString *)accessToken mac:(NSString *)mac dataType:(NSInteger)dataType{
    self = [super init];
    if (self) {
        _accessToken = accessToken;
        _mac = mac;
        _dataType = dataType;
        
    }
    
    return self;
    
}
- (YTKRequestMethod)requestMethod{
    
    return YTKRequestMethodGet;
    
}

-(BOOL)isHttpsType{
    
    return YES;
}

-(NSString *)requestUrl{
    
    return [@"/v1/app/customization/legend" stringByAppendingString: @"/getDeviceData"];
    
}

- (id)requestArgument{
    
    return @{
             @"accessToken":_accessToken,
             @"mac" : _mac,
             @"dataType": @(_dataType)
             };
    
}

- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock{
    [super startWithSuccessBlockDictionaryParameter:successBlock failure:failureBlock];
}
@end
