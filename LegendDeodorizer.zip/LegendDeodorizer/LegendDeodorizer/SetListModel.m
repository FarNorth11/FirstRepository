//
//  SetListModel.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/10.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "SetListModel.h"

@implementation SetListModel
- (void)setValue:(id)value forKey:(NSString *)key{
    
    [super setValue:value forKey:key];
    
}
- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}
@end
