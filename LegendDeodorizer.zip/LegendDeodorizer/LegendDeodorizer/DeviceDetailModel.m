//
//  DeviceDetailModel.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/9.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "DeviceDetailModel.h"
#import "NSDictionary+SAMAdditions.h"

@implementation DeviceDetailModel

-(instancetype)initWithData:(NSDictionary *)dic{
    self = [super init];
    if (self) {
        self.gid = [dic sam_safeObjectForKey:@"gid"];
        self.groupName = [dic sam_safeObjectForKey:@"groupName"];
        self.deviceAddress = [dic sam_safeObjectForKey:@"deviceAddress"];
        self.deviceId = [dic sam_safeObjectForKey:@"deviceId"];
        self.deviceName = [dic sam_safeObjectForKey:@"deviceName"];
        self.headName = [dic sam_safeObjectForKey:@"headName"];
        self.headPhone = [dic sam_safeObjectForKey:@"headPhone"];
        self.intro = [dic sam_safeObjectForKey:@"intro"];
    }
    return self;
}

@end
