//
//  GetErrorDataRequset.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/18.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "HETRequest.h"

/*
 http请求方式: GET
 https://api.clife.cn/v1/device/data/getErrorData
 */

@interface GetErrorDataRequset : HETRequest

- (instancetype)initWithAccessToken: (NSString *)accessToken deviceId:(NSString *)deviceId;

- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock;


@end
