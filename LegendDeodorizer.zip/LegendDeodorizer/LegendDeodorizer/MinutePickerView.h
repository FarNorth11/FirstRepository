//
//  MinutePickerView.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/11.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SetListModel.h"
typedef void (^selectminuteBlock)(SetListModel *);
@interface MinutePickerView : UIView<UIPickerViewDelegate,UIPickerViewDataSource>
@property (copy,nonatomic)selectminuteBlock selectblock;
- (instancetype)initWithFrame:(CGRect)frame andTimeReset:(SetListModel *)timesmodel AndSelectTime:(selectminuteBlock)selectTimeblock;
@end
