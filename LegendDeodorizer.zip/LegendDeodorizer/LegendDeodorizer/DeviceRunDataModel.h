//
//  DeviceRunDataModel.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/8.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DeviceRunDataModel : NSObject

@property (nonatomic,copy) NSNumber *               Deodorant;          //除臭液数量
@property (nonatomic,copy) NSNumber *              Ammonialow;          //氨气值低位
@property (nonatomic,copy) NSNumber *              Ammoniahigh;           //氨气值高位
//错误 0正常 1报警

@property (nonatomic,copy) NSNumber *               FanError;          //风扇
@property (nonatomic,copy) NSNumber *               FanError2;          //风扇2
@property (nonatomic,copy) NSNumber *               AtomizerError;           //雾化器
@property (nonatomic,copy) NSNumber *               AtomizerError2;           //雾化器2
@property (nonatomic,copy) NSNumber *              SolenoidValveError;           //电磁阀
@property (nonatomic,copy) NSNumber *              SolenoidValveError2;           //电磁阀2
@property (nonatomic,copy) NSNumber *              FluidPumpError;           //加液泵
@property (nonatomic,copy) NSNumber *              AmmoniaSensorError;           //氨气传感器
@property (nonatomic,copy) NSNumber *              LiquidLevelSensorError;           //液箱液位传感器
@property (nonatomic,copy) NSNumber *              WorkplaceLevelSensorError;           //工作仓液位传感器





//-(instancetype)initWithData:(NSDictionary *)dic;

-(NSDictionary *) convertModelToDictionary;


@end
