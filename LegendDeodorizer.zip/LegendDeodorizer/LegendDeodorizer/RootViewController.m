//
//  RootViewController.m
//  CSuperAppliances
//
//  Created by starlueng on 16/4/19.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "RootViewController.h"

@implementation RootViewController
- (void)viewDidLoad{
    [super viewDidLoad];
    UIButton *leftBtn =[UIButton setButtonWithNomalImage:[UIImage imageNamed:@"arrow_back_black"] AndSelectImage:[UIImage imageNamed:@"arrow_back_black"] AndFrame:CGRectMake(0, 0, 60, 44)];
  
    leftBtn.imageEdgeInsets = UIEdgeInsetsMake(0, -16, 0, 32);
    self.navigationItem.leftBarButtonItem =[[UIBarButtonItem alloc]initWithCustomView:leftBtn];
    [leftBtn addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
    self.view.backgroundColor = [UIColor colorWithRed:235/255.0 green:238/255.0 blue:245/255.0 alpha:1.0];
    
    self.navigationController.navigationBar.titleTextAttributes =@{NSFontAttributeName:[UIFont systemFontOfSize:18],NSForegroundColorAttributeName:[UIColor blackColor]};
}
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}
- (void)buttonClick:(UIButton *)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
@end
