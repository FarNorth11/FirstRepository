//
//  GroupListModel.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/6.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "GroupListModel.h"
#import "NSDictionary+SAMAdditions.h"

@implementation GroupListModel
-(instancetype)initWithData:(NSDictionary *)dic{
    self = [super init];
    if (self) {
        self.deviceNum = [dic sam_safeObjectForKey:@"deviceNum"];
        if (![dic sam_safeObjectForKey:@"deviceNum"] ) {
            self.deviceNum = @"0";
        }
        self.gid = [[dic sam_safeObjectForKey:@"gid"] integerValue];
        self.groupName = [dic sam_safeObjectForKey:@"groupName"];
        }
    return self;
}

@end
