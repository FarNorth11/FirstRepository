//
//  HomepageCell.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/27.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "HomepageCell.h"

@implementation HomepageCell

@synthesize titleLabel,countBtn;
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        [self fillCell];
    }
    return self;
}

- (void) fillCell
{

    titleLabel    = [[UILabel alloc]init];
    countBtn = [[UIButton alloc]init];
    

    
    UIImage *myimage = [UIImage imageNamed:@"homeCellBg"];
    UIImageView *bgImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 65)];
    bgImageView.image = myimage;
    [self addSubview:bgImageView];
    
    [titleLabel setFrame:CGRectMake(0, 0, 160, 16)];
    titleLabel.textColor = [UIConfig colorFromHexRGB:@"222222"];
    titleLabel.textAlignment = NSTextAlignmentLeft;
    titleLabel.textColor = [UIConfig colorFromHexRGB:@"ffffff"];
    titleLabel.font = [UIFont systemFontOfSize:16.0f];
    titleLabel.center = CGPointMake(88, bgImageView.center.y);
    
    
    UIImageView *rightImageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"arrow_right"]];
    rightImageView.center = CGPointMake( ScreenWidth-30, bgImageView.center.y);
    
    [countBtn setFrame:CGRectMake(0, 0, 34, 34)];
//    [countLabel setBackgroundColor: [UIColor colorWithPatternImage:[UIImage imageNamed:@"iconyuandian"]]];
//    countLabel.textColor = [UIConfig colorFromHexRGB:@"ffffff"];
//    countLabel.textAlignment = NSTextAlignmentCenter;
    
    [countBtn setBackgroundImage:[UIImage imageNamed:@"iconyuandian"] forState:UIControlStateNormal];
    countBtn.center = CGPointMake(rightImageView.center.x-30, rightImageView.center.y);
    [countBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 5, 0, 0)];
    [countBtn setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 0)];
//    countLabel.layer.backgroundColor = [UIColor redColor].CGColor;
//    countLabel.backgroundColor = [UIColor redColor];
//    countBtn.layer.cornerRadius = 17;
//    countBtn.layer.masksToBounds = YES;
//    countBtn.font = [UIFont systemFontOfSize:16.0f];
    
    [bgImageView addSubview:rightImageView];
    [bgImageView addSubview:titleLabel];
    [bgImageView addSubview:countBtn];
}


@end
