//
//  MainDevice.m
//  CSuperAppliances
//
//  Created by starlueng on 16/4/14.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "MainDevice.h"

@implementation MainDevice
- (void)setValue:(id)value forKey:(NSString *)key{
    [super setValue:value forKey:key];
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key{

}
@end
