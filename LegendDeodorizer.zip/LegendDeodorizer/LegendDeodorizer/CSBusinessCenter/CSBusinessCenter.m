//
//  CSBusinessCenter.m
//  CSuperAppliances
//
//  Created by Starlueng on 2017/2/23.
//  Copyright © 2017年 starlueng. All rights reserved.
//
/**
 *  除开交互json数据，额外需要传递给h5的数据（设备名称：deviceName 设备是否在线：online 设备网络是否正常:networkavailable）
 */
static NSString *const CurrentDeviceH5Name     = @"deviceName";
static NSString *const CurrentDeviceH5OnLine   = @"online";
static NSString *const CurrentDeviceH5NetAble  = @"networkavailable";

#import "CSBusinessCenter.h"
#import "GetErrorDataRequset.h"
//#import "HETHealthyPotWarningRecord.h"
//#import "EnumClass.h"
#import "Reachability.h"
@interface CSBusinessCenter()<HETDeviceControlBusinessDataSource>
@end
@implementation CSBusinessCenter
+ (instancetype)shareInstance{
    
    static CSBusinessCenter *center = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        center = [[CSBusinessCenter alloc]init];
    });
    return center;
}
- (HETDeviceControlBusiness *)controlBusiness{

    if (!_controlBusiness) {
        _controlBusiness = [[HETDeviceControlBusiness alloc]init];
        _controlBusiness.needReplay = YES;
        _controlBusiness.packetSendTimes = 5;
        _controlBusiness.packetSendTimeInterval = 2;
        _controlBusiness.dataSource = self;
    }
    return _controlBusiness;
}
#pragma mark-================HETDeviceControlBusinessDataSource==============
//设备控制的网络请求接口实现
- (HETRequest *)deviceControlRequestWithJson:(NSString *)jsonString :(HETDeviceControlBusiness *)business :(id)successCallBlock :(id)failCallBlock{
    NSLog(@"设置：%@",jsonString);
    if (self.CSDevice&&[self.CSDevice.onlineStatus integerValue]==1) {
        __weak typeof(self)Wself = self;
        
        if(![self isInternetConnect]) {
            if (Wself.setErrorBlock) {
                Wself.setErrorBlock(failCallBlock);
            }
            return nil;
            
        }else{
            HETDeviceConfigSetRequest *request =[[HETDeviceConfigSetRequest alloc]initWithAccessToken:[HETUserInfo userInfo].accessToken deviceId:business.deviceId json:jsonString];
            
            [request startWithSuccess:^{
                
                if (Wself.setJsonBlock) {
                    Wself.setJsonBlock(jsonString);
                }
                
            } failure:^(NSError *error, NSInteger statusCode) {
                if (Wself.setErrorBlock) {
                    Wself.setErrorBlock(failCallBlock);
                }
                if (error.code ==100022006) {
//                    [HelpMsg showMessage:@"设备不在线" inView:[[UIApplication sharedApplication].delegate window]];
                }
                
            }];
            return request;
        
        }

    }else{
        return nil;
    }
}


-(BOOL)isInternetConnect{
    
    BOOL whether = YES;
    NSURL *url1 = [NSURL URLWithString:@"http://www.baidu.com"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url1 cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData timeoutInterval:10];
    NSHTTPURLResponse *response;
    [NSURLConnection sendSynchronousRequest:request returningResponse: &response error: nil];
    if (response == nil) {
        NSLog(@"没有网络");
        whether = NO;
    }
    else{
        NSLog(@"网络是通的");
    }
    return whether;
}
//设备基本信息的网络请求接口实现
- (HETRequest *)refreshCfgInfo:(HETDeviceControlBusiness *)business{
    if (self.CSDevice&&[self.CSDevice.onlineStatus integerValue]==1) {
        NSString *deviceId = business.deviceId;
        HETDeviceConfigGetRequest * request =[[HETDeviceConfigGetRequest alloc]initWithAccessToken:[HETUserInfo userInfo].accessToken deviceId:business.deviceId];
        
        [request startWithSuccessBlockDictionaryParameter:^(NSDictionary *dictValue) {
            NSLog(@"NSDictionaryNSDictionaryNSDictionary%@",dictValue);
            if (![deviceId isEqualToString:business.deviceId]) {
                return ;
            }
            if (business.cfgDataBlock) {
                business.cfgDataBlock(dictValue);
            }
        } failure:^(NSError *error, NSInteger statusCode) {
            
            
        }];
        return request;
    }else{
        return nil;
    }
    
}
//设备基本信息的网络请求接口实现
- (HETRequest *)refreshDeviceInfo:(HETDeviceControlBusiness *)business{
    if (![business.deviceId isEqualToString:self.CSDevice.deviceId]) {
        NSLog(@"设备ID不一致 business.deviceId=%@ _mainDevice.deviceId=%@",business.deviceId,self.CSDevice.deviceId);
        return nil;
    }
    
    if (self.CSDevice) {
//        NSMutableDictionary *mutabeDic =[self upgradeH5DataDic];
        NSMutableDictionary *mutabeDic = [[NSMutableDictionary alloc]initWithCapacity:8];
        HETDeviceGetDeviceInfoRequest * request =[[HETDeviceGetDeviceInfoRequest alloc]initWithAppType:2 accessToken:[HETUserInfo userInfo].accessToken andDeviceId:business.deviceId];
        __weak typeof(self) Wself = self;
        [request startWithSuccess:^(NSDictionary *dictValue) {
            
//            NSLog(@"send H5 DeviceCFG%@",dictValue);
          
            if ([dictValue.allKeys containsObject:@"onlineStatus"]&&!business.isLittleLoop) {
                
                Wself.CSDevice.onlineStatus = dictValue[@"onlineStatus"];
                
                [mutabeDic setObject:dictValue[@"onlineStatus"] forKey:CurrentDeviceH5OnLine];
                
            }
            [Wself.CSDevice setValuesForKeysWithDictionary:dictValue];
            
            if (business.runDataBlock) {
                business.runDataBlock(mutabeDic);
            }
            
        } failure:^(NSError *error, NSInteger statusCode) {
            
            
            
            if (error.code ==100022006) {
                [mutabeDic setObject:@"2" forKey:CurrentDeviceH5OnLine];
                if (business.runDataBlock) {
                    business.runDataBlock(mutabeDic);
                }
                
            }else if (error.code ==100022000||error.code ==100022009) {
                
                if (Wself.deviceInfoBlock) {
                    Wself.deviceInfoBlock(error);
                }
            }
            
            else if (error.code ==0||(error.code>400&&error.code<510)){
                
                [mutabeDic setObject:@"2" forKey:CurrentDeviceH5NetAble];
                
                if (business.runDataBlock) {
                    business.runDataBlock(mutabeDic);
                }
            }
            
            
        }];
        return request;
    }else{
        return nil;
    }
    
}

//设备运行数据的网络请求接口实现
- (HETRequest *)refreshRunData:(HETDeviceControlBusiness *)business{
    
    if (self.CSDevice&&[self.CSDevice.onlineStatus integerValue]==1) {
//        NSMutableDictionary *mutabeDic =[self upgradeH5DataDic];
        NSMutableDictionary *mutabeDic = [[NSMutableDictionary alloc]initWithCapacity:8];
        HETDeviceDataGetRequest * request = [[HETDeviceDataGetRequest alloc]initWithAccessToken:[HETUserInfo userInfo].accessToken deviceId:business.deviceId];
        NSString *deviceId = business.deviceId;
        [request startWithSuccessBlockDictionaryParameter:^(NSDictionary *dictValue) {
            NSLog(@"%@",dictValue);
            
            if (![deviceId isEqualToString:business.deviceId]) {
                return ;
            }
            for (NSString *key in dictValue.allKeys) {
                [mutabeDic setObject:[dictValue objectForKey:key] forKey:key];
            }
            NSLog(@"rundata--------------------------------------%@",mutabeDic);
            if (business.runDataBlock) {
                business.runDataBlock(mutabeDic);
            }
        } failure:^(NSError *error, NSInteger statusCode) {
            /**
             *  根据错误返回码 100022006为设备不在线 0是网络不可用，404 和500为链接错误，后台接口错误
             */
            if (error.code ==100022006) {
                [mutabeDic setObject:@"2" forKey:CurrentDeviceH5OnLine];
                if (business.runDataBlock) {
                    business.runDataBlock(mutabeDic);
                }
                
            }else if (error.code ==0||(error.code>400&&error.code<510)){
                NSMutableDictionary *mutabeDic =[[NSMutableDictionary alloc]init];
                [mutabeDic setObject:@"2" forKey:CurrentDeviceH5NetAble];
                if (business.runDataBlock) {
                    business.runDataBlock(mutabeDic);
                }
            }
        }];
        return request;
    }else{
        return nil;
    }
    
}
//设备故障信息的网络请求接口实现
- (HETRequest *)refreshDeviceError:(HETDeviceControlBusiness *)business{
    if (self.CSDevice ) {
        
        //获取故障数据
        GetErrorDataRequset *warningRequest = [[GetErrorDataRequset alloc] initWithAccessToken:[HETUserInfo userInfo].accessToken deviceId:business.deviceId];
        NSString *deviceId = business.deviceId;
        [warningRequest startWithSuccess:^(NSDictionary *dict) {
            NSLog(@"故障数据请求成功--->%@",dict);
            if ([dict isKindOfClass:[NSNull class]]) {
                return ;
            }
            if (![deviceId isEqualToString:business.deviceId]) {
                return ;
            }
            if (business.runDataBlock) {
                business.runDataBlock(dict);
            }
        } failure:^(NSError *error, NSInteger statusCode) {
            NSLog(@"故障数据请求失败--->%@",error);
        }];
        
        
        return warningRequest;
    }
    else{
        return nil;
    }
    
}
//- (NSMutableDictionary *)upgradeH5DataDic{
//    
//    NSMutableDictionary *mutabeDic =[[NSMutableDictionary alloc]init];
//    if (self.CSDevice.deviceName) {
//        if ([self.CSDevice.deviceTypeId integerValue]==1) {
//            NSString *setName = [NSString stringWithFormat:@"%@(%@)",self.CSDevice.deviceName,self.CSDevice.productCode];
//            [mutabeDic setObject:setName forKey:CurrentDeviceH5Name];
//        }else{
//            [mutabeDic setObject:self.CSDevice.deviceName forKey:CurrentDeviceH5Name];
//        }
//    }
//    
//    [mutabeDic setObject:@"1" forKey:CurrentDeviceH5OnLine];
//    NSString *deviceId = self.CSDevice.deviceId?:@"";
//    [mutabeDic setObject:deviceId forKey:@"deviceId"];
//    if (![mutabeDic.allKeys containsObject:CurrentDeviceH5NetAble]) {
//        [mutabeDic setObject:@"1" forKey:CurrentDeviceH5NetAble];
//    }
//    if ([self.CSDevice.deviceTypeId integerValue]== DeviceAirClean) {
//        if (self.weather.wtext) {
//            [mutabeDic setObject:self.weather.wtext forKey:@"wtext"];
//        }
//        if (self.weather.temp) {
//            [mutabeDic setObject:self.weather.temp forKey:@"temp"];
//        }
//        if ([CSAppUserSettings shareInstance].userLocation) {
//            NSDictionary *locations = [CSAppUserSettings shareInstance].userLocation;
//            [mutabeDic setObject:locations[@"LocationCity"] forKey:@"cityName"];
//        }
//        if (self.weather.pm25) {
//            [mutabeDic setObject:self.weather.pm25 forKey:@"pm25"];
//        }else{
//            [mutabeDic setObject:@0 forKey:@"pm25"];
//        }
//    }
//    return mutabeDic;
//}

@end
