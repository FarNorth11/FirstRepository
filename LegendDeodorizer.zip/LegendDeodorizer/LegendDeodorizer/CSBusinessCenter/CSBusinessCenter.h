//
//  CSBusinessCenter.h
//  CSuperAppliances
//
//  Created by Starlueng on 2017/2/23.
//  Copyright © 2017年 starlueng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HETDeviceControlBusiness.h"
#import "MainDevice.h"
//#import "WeatherModel.h"
typedef void (^businessBlock)(id);
@interface CSBusinessCenter : NSObject

+ (instancetype)shareInstance;
//配置当前所属的设备信息
@property (strong,nonatomic) MainDevice *CSDevice;

//当前wifi设备控制model
@property (strong,nonatomic) HETDeviceControlBusiness * controlBusiness;

//当前天气model
//@property (strong,nonatomic) WeatherModel *weather;

@property (copy,nonatomic) businessBlock setJsonBlock;//执行成功后的回调

@property (copy,nonatomic) businessBlock setErrorBlock;//执行失败后的回调

@property (copy,nonatomic) businessBlock deviceInfoBlock;//设备状态异常回调

//- (NSMutableDictionary *)upgradeH5DataDic;


- (HETRequest *)deviceControlRequestWithJson:(NSString *)jsonString :(HETDeviceControlBusiness *)business :(id)successCallBlock :(id)failCallBlock;

@end
