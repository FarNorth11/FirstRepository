//
//  MainDevice.h
//  CSuperAppliances
//
//  Created by starlueng on 16/4/14.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MainDevice : NSObject
@property (nonatomic, copy) NSString * authUserId;
@property (nonatomic, copy) NSString * bindTime;
@property (nonatomic, copy) NSNumber * bindType;
@property (nonatomic, copy) NSNumber * deviceBrandId;
@property (nonatomic, copy) NSString * deviceBrandName;
@property (nonatomic, copy) NSString * deviceId;
@property (nonatomic, copy) NSString * moduleName;
@property (nonatomic, copy) NSString * deviceName;
@property (nonatomic, copy) NSNumber * deviceSubtypeId;
@property (nonatomic, copy) NSString * deviceSubtypeName;
@property (nonatomic, copy) NSNumber * deviceTypeId;
@property (nonatomic, copy) NSString * deviceTypeName;
@property (nonatomic, copy) NSString * macAddress;
@property (nonatomic, copy) NSNumber * onlineStatus;
@property (nonatomic, copy) NSNumber * roomId;
@property (nonatomic, copy) NSString * roomName;
@property (nonatomic, copy) NSNumber * share;
@property (nonatomic, copy) NSString * userKey;
@property (nonatomic, copy) NSNumber * productId;
@property (nonatomic, copy) NSNumber * moduleId;
@property (nonatomic, copy) NSNumber * moduleType;
@property (nonatomic, copy) NSString * productName;
@property (nonatomic, copy) NSString * productIcon;
@property (nonatomic, copy) NSString * productCode;
@property (nonatomic, copy) NSNumber * controlType;
@property (nonatomic, copy) NSString * modelStyle;

@property (nonatomic, copy) NSString *h5Path;
@property (assign,nonatomic) BOOL isExperience;//是否是体验设备
@property (assign,nonatomic) NSInteger WIFISupportType;//wifi支持的协议
//@property (assign,nonatomic) BOOL isSuportLittleCircle;//是否支持小循环
@property (copy,nonatomic) NSDictionary *DeviceInfo;//设备信息

@property (copy,nonatomic) NSDictionary *h5readCfgDic;//h5初始数据
@end
