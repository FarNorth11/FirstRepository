//
//  MinutePickerView.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/11.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "MinutePickerView.h"

@implementation MinutePickerView{
    UIPickerView *selPartView;
    NSMutableArray *selectArr;
    SetListModel *_timesmodel;
}

- (instancetype)initWithFrame:(CGRect)frame andTimeReset:(SetListModel *)timesmodel AndSelectTime:(selectminuteBlock)selectTimeblock
{
    self = [super initWithFrame:frame];
    if (self) {
        _timesmodel = timesmodel;
        self.selectblock = selectTimeblock;
        [self createUI];
    }
    return self;
}

-(void)createUI{
    
    self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.4];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(actionCancel:)];
    [self addGestureRecognizer:tap];
    
    //    control=[[UIControl  alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
    //    control.backgroundColor=[UIColor colorWithRed:0 green:0 blue:0 alpha:0.4];
    //    [self.window  addSubview:control];
    //    [control  addTarget:self action:@selector(actionCancel:)   forControlEvents:UIControlEventTouchUpInside];
    
    //Toolbar
    UIToolbar  *toolbar=[[UIToolbar  alloc]  initWithFrame:CGRectMake(0,ScreenHeight*0.6,ScreenWidth,50)];
    toolbar.backgroundColor = WHITECOLOR;
    toolbar.autoresizingMask=UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleWidth;
    
    UIBarButtonItem *itemCancelDone=[[UIBarButtonItem alloc]initWithTitle:@"确定" style:UIBarButtonItemStylePlain  target:self action:@selector(actionConfirm:)];
    
    UIBarButtonItem  *itemCancel=[[UIBarButtonItem  alloc]initWithTitle:@"取消"  style:UIBarButtonItemStylePlain   target:self action:@selector(actionCancel:)];
    
    UIBarButtonItem  *itemTitle=[[UIBarButtonItem  alloc]initWithTitle:@"时段"  style:UIBarButtonItemStylePlain   target:self action:nil];
    
    
    UIBarButtonItem  *space=[[UIBarButtonItem  alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace  target:nil action:nil];
    [toolbar setItems:[NSArray  arrayWithObjects:space,itemCancel,space,space,itemTitle,space,space,itemCancelDone,space,nil]];
    [self  addSubview:toolbar];
    
    selPartView=[[UIPickerView alloc]initWithFrame:CGRectMake(0, self.frame.size.height*0.6+50, ScreenWidth, ScreenHeight *0.4- 50)];
    selPartView.backgroundColor=[UIColor whiteColor];
    selPartView.delegate=self;
    selPartView.dataSource=self;
    
    NSMutableArray *Arr_10 = [[NSMutableArray alloc]initWithCapacity:10];

    
    for(int i=0;i<10;i++){
        if (i<10) {
            [Arr_10 addObject:[NSString stringWithFormat:@"0%d",i]];
        }else{
            [Arr_10 addObject:[NSString stringWithFormat:@"%d",i]];
        }
        
    }
    selectArr=[[NSMutableArray alloc]initWithCapacity:2];
    [selectArr addObject:Arr_10];
    [selectArr addObject:Arr_10];
    
    //增加选中行说明文字
    [self addSelectCellStr];
    [self addSubview:selPartView];
    
    //选择当前选中的数据行
    [self selectBeforeDataRow];
    
    
    [selPartView selectRow:[_timesmodel.openTime integerValue] inComponent:0 animated:YES];
    [selPartView selectRow:[_timesmodel.stopTime integerValue] inComponent:1 animated:YES];
    
    
}

- (void)addSelectCellStr{
    //选中行的附属文字说明
    UIView *titleView = [[UIView alloc]initWithFrame:CGRectMake(0, selPartView.frame.size.height*0.43, ScreenWidth, 25)];
    //    titleView.backgroundColor = [UIColor lightGrayColor];
    //    titleView.layer.opacity =0.5;
    
    CGSize anaSize1=[@"开" sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:13]}];
    
    UILabel *diandian1 = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth*0.1, 0, anaSize1.width, 25)];
    diandian1.text=@"开";
    //    [diandian1 setBackgroundColor:[UIColor redColor]];
    diandian1.font = [UIFont systemFontOfSize:13];
    [titleView addSubview:diandian1];
    
    
    UILabel *diandian2 = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth*0.35, 0, anaSize1.width, 25)];
    diandian2.text=@"分";
    diandian2.font = [UIFont systemFontOfSize:13];
    //    [diandian2 setBackgroundColor:[UIColor redColor]];
    [titleView addSubview:diandian2];
    
    
    UILabel *diandian3 = [[UILabel alloc]initWithFrame:CGRectMake(self.center.x-12.5, 0, 10, 25)];
    diandian3.text=@"-";
    //    [diandian3 setBackgroundColor:[UIColor redColor]];
    [titleView addSubview:diandian3];
    
    UILabel *diandian4 = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth*0.6, 0, anaSize1.width, 25)];
    diandian4.text=@"停";
    //    [diandian4 setBackgroundColor:[UIColor redColor]];
    diandian4.font = [UIFont systemFontOfSize:13];
    [titleView addSubview:diandian4];
    
    
    UILabel *diandian5 = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth*0.85, 0, anaSize1.width, 25)];
    diandian5.text=@"分";
    diandian5.font = [UIFont systemFontOfSize:13];
    //    [diandian5 setBackgroundColor:[UIColor redColor]];
    [titleView addSubview:diandian5];
    
    
    [selPartView addSubview:titleView];
}

-(void)selectBeforeDataRow{
    
    
    
}

-(void)actionCancel:(id)sender
{
    [self removeFromSuperview];
    
}


#pragma mark  -----发送配置请求
-(void)actionConfirm:(id)sender{
    //    NSLog(@"%ld,%ld,%ld,%ld",(long)[selPartView numberOfRowsInComponent:0],(long)[selPartView numberOfRowsInComponent:1],(long)[selPartView numberOfRowsInComponent:2],(long)[selPartView numberOfRowsInComponent:3]) ;
    
    //    NSLog(@"%@",currentPickArr);//(1,39,6,48)
    //把选定的数组解析成特定形式发送 threshold = "1.35,1.05";
    //    for(int i=0;i<currentPickArr.count;i++){
    //        if (<#condition#>) {
    //            <#statements#>
    //        }
    //
    //
    //    }
    //    if (currentPickArr.count==4) {
    //        NSString *thresholdStr = [NSString stringWithFormat:@"%@.%@,%@.%@",currentPickArr[0],currentPickArr[1],currentPickArr[2],currentPickArr[3]];
    //
    //        [self.delegate returnModeSetting:1 week:_smartModeDic.week  threshold:thresholdStr setList:nil];
    //
    //    }
    _timesmodel.openTime =@([selPartView selectedRowInComponent:0]);
    _timesmodel.stopTime =@([selPartView selectedRowInComponent:1]);
  
    if (self.selectblock) {
        self.selectblock(_timesmodel);
    }
    
    [self removeFromSuperview];
    
    
}


#pragma mark  ------------UIPickerViewDelegate,UIPickerViewDataSource------------
//点击
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    //    selectLab.text=[NSString stringWithFormat:@"%@",[selectArr[row] valueForKey:@"partName"]];
    //    selectPart=row;
    //        threshold = "1.35,1.05";
    //        week = "1,2,3,4,5";
    //    NSString *threshold = _smartModeDic.threshold;
    NSLog(@"didselect:%@",selectArr[component][row]);
    //    [currentPickArr replaceObjectAtIndex:component withObject:selectArr[component][row]];
    
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    //    return 1;
    return selectArr.count;
}

- (NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    NSArray *arr =  selectArr[component];
    return arr.count;
}

//-(CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component{
//    CGFloat width;
//    if (component == 0 ||component == 6 ){
//        width = ScreenWidth *0.25;
//    }else if (component == 1 || component == 2 ||component == 3||component == 4 ||component == 5) {
//        width = ScreenWidth *0.1;
//    }
//
//    return width;
//}

//自定义指定列的每行的视图.
- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    UILabel* pickerLabel = (UILabel*)view;
    
    if (!pickerLabel){
        pickerLabel = [[UILabel alloc] init];
        pickerLabel.adjustsFontSizeToFitWidth = YES;
        [pickerLabel setTextAlignment:NSTextAlignmentRight];
        [pickerLabel setBackgroundColor:[UIColor clearColor]];
        [pickerLabel setTextColor:[UIConfig colorFromHexRGB:@"0dc7a5"]];
        [pickerLabel setFont:[UIFont boldSystemFontOfSize:18]];
    }
    if(component == 0){
        [pickerLabel setTextAlignment:NSTextAlignmentCenter];
    }else if(component == 1){
        [pickerLabel setTextAlignment:NSTextAlignmentCenter];
    }
    // Fill the label text here
    pickerLabel.text=[self pickerView:pickerView titleForRow:row forComponent:component];
    return pickerLabel;
}

//显示的标题,选项名字
- (NSString *) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    NSArray *arr =  selectArr[component];
    NSString *str = [NSString stringWithFormat:@"%@",arr[row]];
    //    NSLog(@"Str:%@",str);
    return str;
    //    return [NSString stringWithFormat:@"%@",[selectArr[row] valueForKey:@"partName"]];
}


@end
