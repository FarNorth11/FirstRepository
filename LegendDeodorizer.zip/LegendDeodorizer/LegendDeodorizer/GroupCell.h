//
//  GroupCell.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/28.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GroupCell : UITableViewCell

@property (nonatomic,strong) UIImageView *leftImageView;//左视图

@property (nonatomic,strong) UILabel *midLabel;

@property (nonatomic,strong) UILabel *locationLabel ;

@property (nonatomic,strong) UILabel *DeviceLabel ;

@property (nonatomic,strong) UILabel *onlineLabel ;

@end
