//
//  InsertDeviceDataRequest.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/25.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "HETRequest+Private.h"
#import "InsertDeviceDataRequest.h"

@implementation InsertDeviceDataRequest

{
    NSString  *_accessToken;
    NSString *_mac;
    NSInteger _dataType;
    NSString *_data;
}

- (instancetype)initWithAccessToken: (NSString *)accessToken mac:(NSString *)mac dataType:(NSInteger)dataType data:(NSString *)data{
    self = [super init];
    if (self) {
        _accessToken = accessToken;
        _mac = mac;
        _dataType = dataType;
        _data = data;
        
    }
    
    return self;
    
}
- (YTKRequestMethod)requestMethod{
    
    return YTKRequestMethodGet;
    
}

-(BOOL)isHttpsType{
    
    return YES;
}

-(NSString *)requestUrl{
    
    return [@"/v1/app/customization/legend" stringByAppendingString: @"/insertDeviceData"];
    
}

- (id)requestArgument{
    
    return @{
             @"accessToken":_accessToken,
             @"mac" : _mac,
             @"dataType": @(_dataType),
             @"data":_data
             };
    
}

- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock{
    [super startWithSuccessBlockDictionaryParameter:successBlock failure:failureBlock];
}



@end
