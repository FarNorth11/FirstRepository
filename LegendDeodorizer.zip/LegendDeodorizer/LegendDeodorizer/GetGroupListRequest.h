//
//  GetGroupListRequest.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/5.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "HETRequest.h"
/*
 http请求方式: GET
 https://api.clife.cn/v1/app/customization/legend/getGroupList
 */

@interface GetGroupListRequest : HETRequest

- (instancetype)initWithAccessToken: (NSString *)accessToken pageIndex:(NSNumber *)pageIndex pageRows:(NSNumber *)pageRows;

//- (void)startWithSuccessBlockArrayParameter: (HETHttpSuccessBlockArrayParameter)successBlock
//                                    failure: (HETHttpFailureBlock)failureBlock;

- (void)startWithSuccessBlockDictionaryParameter: (HETHttpSuccessBlockDictionaryParameter)successBlock
                                         failure: (HETHttpFailureBlock)failureBlock;

@end
