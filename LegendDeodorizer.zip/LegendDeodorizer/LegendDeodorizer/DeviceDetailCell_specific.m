//
//  DeviceDetailCell_specific.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/7.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "DeviceDetailCell_specific.h"

@implementation DeviceDetailCell_specific

@synthesize leftLabel;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        [self fillCellSpecific];
    }
    return self;
}

-(void) fillCellSpecific{
    
    
    leftLabel    = [[UILabel alloc]init];
    [leftLabel setFrame:CGRectMake(10*NewBasicWidth, 5*NewBasicHeight, ScreenWidth-(100*NewBasicWidth), self.frame.size.height)];
    leftLabel.textAlignment = NSTextAlignmentLeft;
    leftLabel.textColor = [UIColor blackColor];
    leftLabel.numberOfLines = 0;
    leftLabel.font = [UIFont systemFontOfSize:16.0f];
    //    leftLabel.center = CGPointMake(50, self.center.y);
    [self addSubview:leftLabel];
    
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(CGRectGetMaxX(leftLabel.frame), 0, 100*NewBasicWidth, 70)];
    [btn setImage:[UIImage imageNamed:@"dingwei"] forState:UIControlStateNormal];
    [btn setTitle:@"定位" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont systemFontOfSize:13];
    [btn addTarget:self action:@selector(ScanQuickMark:) forControlEvents:UIControlEventTouchUpInside];
    [btn setImageEdgeInsets:UIEdgeInsetsMake(-15, 30, 0, 0)];
    [btn setTitleEdgeInsets:UIEdgeInsetsMake(40, 0, 0, 17)];
    
    CALayer *lineLayer = [[CALayer alloc]init];
    lineLayer.frame = CGRectMake(1, 10, SINGLE_LINE_WIDTH, 50);
    lineLayer.backgroundColor = KCOLOR(@"c7c7c7").CGColor;
    [btn.layer addSublayer:lineLayer];

    [self addSubview:btn];
    
}


-(void)ScanQuickMark:(id)sender{
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"scanQuickMark" object:nil];
}
@end
