//
//  Edit_DeviceDetailCell.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/9.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "Edit_DeviceDetailCell.h"

@implementation Edit_DeviceDetailCell

@synthesize leftTextField;

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        [self fillCell];
    }
    return self;
}

- (void) fillCell
{
    
    leftTextField    = [[UITextField alloc]init];
    [leftTextField setFrame:CGRectMake(10*NewBasicWidth, 5*NewBasicHeight, self.frame.size.width-10, self.frame.size.height)];
    leftTextField.textAlignment = NSTextAlignmentLeft;
    leftTextField.textColor = [UIColor blackColor];
    leftTextField.font = [UIFont systemFontOfSize:16.0f];
    leftTextField.delegate = self;
    leftTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    //    leftLabel.center = CGPointMake(50, self.center.y);
    [self addSubview:leftTextField];
    
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

//-(void)textFieldDidBeginEditing:(UITextField *)textField{
//    NSLog(@"tesdfasdf:%ld",(long)textField.tag);

    //创建通知
//    
//    NSNotification *notification =[NSNotification notificationWithName:@"textFieldTag" object:nil userInfo:@{@"tag":@(textField.tag)}];
//                                   
//    //通过通知中心发送通知
//    
//    [[NSNotificationCenter defaultCenter] postNotification:notification];
//}
@end
