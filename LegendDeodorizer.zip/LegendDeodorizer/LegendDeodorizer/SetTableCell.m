//
//  SetTableCell.m
//  Common_Refrigerator
//
//  Created by starlueng on 16/1/11.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "SetTableCell.h"

@implementation SetTableCell


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createUI];
    }
    return self;
}
- (void)createUI{
    
//    _leftImageView =[[UIImageView alloc]init];
//    [self.contentView addSubview:_leftImageView];
    
    _midLabel =[[UILabel alloc]init];
    _midLabel.font =[UIFont systemFontOfSize:16];
    _midLabel.textColor =[UIConfig colorFromHexRGB:@"323232"];
    [self.contentView addSubview:_midLabel];
    
//    _rightImageView =[[UIImageView alloc]init];
//    [self.contentView addSubview:_rightImageView];
//    
//    _noticeView =[[UIImageView alloc]init];
//    [self.contentView addSubview:_noticeView];
    
}
- (void)setcellFrameWith:(BOOL)isLoginView AndRadius:(BOOL)radius AndShowNotice:(BOOL)show{
    _midLabel.frame =CGRectMake(16 *NewBasicWidth, 12*NewBasicHeight, 200*NewBasicWidth, 18);
    
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
