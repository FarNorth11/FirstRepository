//
//  DeviceDetailModel.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/9.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DeviceDetailModel : NSObject

@property (nonatomic,strong)NSString * deviceAddress;
@property (nonatomic,strong)NSString * deviceId ;
@property (nonatomic,strong)NSString * deviceName ;
@property (nonatomic,strong)NSNumber * gid ;
@property (nonatomic,strong)NSString * groupName ;
@property (nonatomic,strong)NSString * headName;
@property (nonatomic,strong)NSString * headPhone ;
@property (nonatomic,strong)NSString * intro;
@property (nonatomic,strong)NSString * macAddress;

-(instancetype)initWithData:(NSDictionary *)dic;

@end
