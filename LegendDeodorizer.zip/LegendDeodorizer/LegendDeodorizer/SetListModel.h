//
//  SetListModel.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/10.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SetListModel : NSObject
@property (copy,nonatomic) NSString *endTime ;
@property (copy,nonatomic) NSNumber *isUsed ;
@property (copy,nonatomic) NSNumber *openTime ;
@property (copy,nonatomic) NSString *startTime ;
@property (copy,nonatomic) NSNumber *stopTime;
@end
