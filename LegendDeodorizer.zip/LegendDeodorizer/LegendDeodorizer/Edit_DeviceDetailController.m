//
//  Edit_DeviceDetailController.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/9.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "Edit_DeviceDetailController.h"
#import "UINavigationController+FDFullscreenPopGesture.h"
#import "GetDeviceInfoRequest.h"
#import "NSDictionary+SAMAdditions.h"
#import "DeviceDetailCell.h"
#import "DeviceDetailCell_specific.h"
#import "Edit_DeviceDetailCell.h"
#import "EditDeviceInfoRequest.h"
#import "DeviceGroupVC.h"

static const NSInteger backTag           =5;//右侧按钮tag
static const NSInteger saveTag           =2;//右侧按钮tag

static const NSInteger nameTag           =50;//右侧按钮tag
static const NSInteger addressTag           =51;//右侧按钮tag

@interface Edit_DeviceDetailController ()<UIGestureRecognizerDelegate>{

    UITableView *mainTableView;
}

@end

@implementation Edit_DeviceDetailController
- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    self.fd_prefersNavigationBarHidden = YES;
    [self createNavUI];
    [self createTableView];
    [self addNoticeForKeyboard];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(keyboardOut)];
    tap.delegate = self;
    [self.view addGestureRecognizer:tap];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
//    [self getDeviceInfo];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self  name:UITextFieldTextDidChangeNotification  object:nil];
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"textFieldTag" object:nil];


}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}

#pragma mark - 键盘通知
- (void)addNoticeForKeyboard {
    //添加textField被编辑时的监听
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getTextFieldTag:) name:@"textFieldTag"object:nil];
    //text被修改后的通知
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(textChanged:)
                                                 name:UITextFieldTextDidChangeNotification object:nil];
    //text被修改后的通知
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(getTextFieldTag:)
                                                 name:UITextFieldTextDidBeginEditingNotification object:nil];

    
    //注册键盘出现的通知
//    [[NSNotificationCenter defaultCenter] addObserver:self
//                                             selector:@selector(keyboardWillShow:)
//                                                 name:UIKeyboardWillShowNotification object:nil];
    //注册键盘消失的通知
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification object:nil];
}

#pragma mark - ===================Request===================
-(void) saveDeviceDetailInfo{
    EditDeviceInfoRequest *editDeviceInfo = [[EditDeviceInfoRequest alloc]initWithAccessToken:[HETUserInfo userInfo].accessToken mac:_deviceDetailModel.macAddress deviceName:_deviceDetailModel.deviceName deviceAddress:_deviceDetailModel.deviceAddress headName:_deviceDetailModel.headName headPhone:_deviceDetailModel.headPhone gid:[_deviceDetailModel.gid intValue] intro:_deviceDetailModel.intro];
    WEAKSELF;
    [editDeviceInfo startWithSuccess:^(NSDictionary *dictValue) {
        [HelpMsg showMessage:@"设置成功" inView:[[[UIApplication sharedApplication]delegate]window]];
        [weakSelf.navigationController  popViewControllerAnimated:YES ];
        NSLog(@"成功");
        [[NSNotificationCenter defaultCenter] postNotificationName:@"RefreshGroupList" object:nil];
    } failure:^(NSError *error, NSInteger statusCode) {
        [HelpMsg showMessage:@"设置失败" inView:[[[UIApplication sharedApplication]delegate]window]];
        [weakSelf.navigationController  popViewControllerAnimated:YES ];
        NSLog(@"失败");
    }];
    

}
//-(void)getDeviceInfo{
//    GetDeviceInfoRequest *getDeviceInfo = [[GetDeviceInfoRequest alloc]initWithAccessToken:[HETUserInfo userInfo].accessToken mac:self.device.macAddress];
//    [getDeviceInfo startWithSuccess:^(NSDictionary *dictValue) {
//        NSLog(@"dictValue:%@",dictValue);
//        deviceAddress = [dictValue sam_safeObjectForKey:@"deviceAddress"];
//        deviceId = [dictValue sam_safeObjectForKey:@"deviceId"];
//        deviceName = [dictValue sam_safeObjectForKey:@"deviceName"];
//        gid = [dictValue sam_safeObjectForKey:@"gid"];
//        groupName = [dictValue sam_safeObjectForKey:@"groupName"];
//        headName = [dictValue sam_safeObjectForKey:@"headName"];
//        headPhone = [dictValue sam_safeObjectForKey:@"headPhone"];
//        intro = [dictValue sam_safeObjectForKey:@"intro"];
//        [mainTableView reloadData];
//        
//    } failure:^(NSError *error, NSInteger statusCode) {
//        
//    }];
//    
//}
#pragma mark ===================UI===================
-(void)createNavUI{
    
    UIView *navView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, NAVIBARHEIGHT+STATUSBARHEIGHT)];
    navView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:navView];
    
    CALayer *lineLayer = [[CALayer alloc]init];
    lineLayer.frame = CGRectMake(0, NAVIBARHEIGHT+STATUSBARHEIGHT-1, ScreenWidth, SINGLE_LINE_WIDTH);
    lineLayer.backgroundColor = KCOLOR(@"c7c7c7").CGColor;
    [navView.layer addSublayer:lineLayer];
    
    UIButton *leftBtn =[UIButton setButtonWithNomalImage:[UIImage imageNamed:@"arrow_back_black"] AndSelectImage:[UIImage imageNamed:@"arrow_back_black"] AndFrame:CGRectMake(0, STATUSBARHEIGHT, 60, NAVIBARHEIGHT)];
    leftBtn.imageEdgeInsets =UIEdgeInsetsMake(0, 0, 0, 0);
    leftBtn.tag = backTag;
    [leftBtn addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
    [navView addSubview:leftBtn];
    
    UILabel *label =[UILabel setLabelWith:@"设备详情" AndFont:[UIFont systemFontOfSize:18] AndIsNumberOfLines:NO AndtextColor:[UIColor blackColor] AndFrame:CGRectMake((ScreenWidth-100)/2, STATUSBARHEIGHT, 100, NAVIBARHEIGHT) AndAlignment:NSTextAlignmentCenter];
    [navView addSubview:label];
    
    
    UIButton *rightBtn =[UIButton setButtonWith:@"保存" AndNomalColor:[UIColor blackColor]  AndSelectColor:[UIColor blackColor]  AndFont:KFONT(16) AndFrame:CGRectMake(ScreenWidth-60, 20, 60, 44)];
    rightBtn.tag = saveTag;
    [navView addSubview:rightBtn];
    
    [rightBtn addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
    //    self.tableView.frame = CGRectMake(0, NAVIBARHEIGHT+STATUSBARHEIGHT, ScreenWidth, ScreenHeight-NAVIBARHEIGHT-STATUSBARHEIGHT);
    
    
}

- (void)createTableView{
    mainTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, NAVIBARHEIGHT+STATUSBARHEIGHT, ScreenWidth, ScreenHeight - NAVIBARHEIGHT-STATUSBARHEIGHT) style:UITableViewStyleGrouped];
    mainTableView.delegate =self;
    mainTableView.dataSource =self;
    
        UIView *footView =[[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, SINGLE_LINE_WIDTH)];
        footView.backgroundColor =[UIConfig colorFromHexRGB:@"c7c8cc"];
    mainTableView.tableFooterView = footView;
    [self.view addSubview:mainTableView];
}


#pragma mark ===================action===================

-(void)buttonClick:(id)sender{
    
    if ([sender isKindOfClass:[UIButton class]]) {
        UIButton *button = (UIButton *)sender;
        switch (button.tag) {
            case saveTag:
            {
                [self saveDeviceDetailInfo];
            }
                break;
            case backTag:
            {
                //                AppDelegate *app =(AppDelegate *)[UIApplication sharedApplication].delegate;
                //                app.root.tabBar.hidden = NO;
                //                app.root.button.hidden = NO;
                //                app.root.selectedIndex =0;
//                [self dismissViewControllerAnimated:YES completion:nil];
                [self.navigationController popViewControllerAnimated:YES];
            }
                break;
                
            default:{
                
            }
                break;
                
        }
        
    }
}

//-(void)getTextFieldTag:(NSNotification *)text{
//    NSLog(@"%@",text.userInfo[@"tag"]);
//    
//    NSLog(@"－－－－－接收到通知------");
//    
//
//
//}
//滑动键盘的时候,滑动self.view
-(void)getTextFieldTag:(NSNotification *)notification{
    //获得textfield
    UITextField *textField = notification.object;
    if(textField.tag ==0){
        [UIView animateWithDuration:0.5 animations:^{
            self.view.frame = CGRectMake(0.0f, -ScreenHeight/2, self.view.frame.size.width, self.view.frame.size.height);
        }];

    }



}

- (void)textChanged:(NSNotification *)notification
{
    //获得textfield
    UITextField *textField = notification.object;
    
    if (textField) {
        
        //获取改变了的textfield对应的NSIndexPath
        //获取到对应的NSIndexPath就可以设置对应的数据源了
        CGPoint point = [textField.superview convertPoint:textField.frame.origin toView:mainTableView];
        
        NSIndexPath *indexPath = [mainTableView indexPathForRowAtPoint:point];
        
        NSLog(@"indexPath:%@",indexPath);
        
        if (indexPath.section == 0) {
            if ([textField.text length] > 10) { //如果输入框内容大于10则弹出警告
                textField.text = [textField.text substringToIndex:10];
                _deviceDetailModel.deviceName = [textField.text substringToIndex:10];
                //        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"超过最大字数不能输入了" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
                //        [alert show];
            }else{
                _deviceDetailModel.deviceName = textField.text;
            }
            
        }else if (indexPath.section == 1) {
            
            if ([textField.text length] > 100) { //如果输入框内容大于100则弹出警告
                textField.text = [textField.text substringToIndex:100];
                _deviceDetailModel.deviceAddress = [textField.text substringToIndex:100];
            }else{
                _deviceDetailModel.deviceAddress = textField.text;
            }
    
            
        }else if(indexPath.section == 2){
            if (indexPath.row == 0) {
                if ([textField.text length] > 10){
                    textField.text = [textField.text substringToIndex:10];
                    _deviceDetailModel.headName = [textField.text substringToIndex:10];
                }else{
                    _deviceDetailModel.headName = textField.text;
                }
                
            }else{
                if ([textField.text length] > 20){
                    textField.text = [textField.text substringToIndex:20];
                    _deviceDetailModel.headPhone = [textField.text substringToIndex:20];
                }else{
                    _deviceDetailModel.headPhone = textField.text;
                }
            }
        }else if(indexPath.section == 4){
            if ([textField.text length] > 100){
                textField.text = [textField.text substringToIndex:100];
                _deviceDetailModel.intro = [textField.text substringToIndex:100];
            }else{
                _deviceDetailModel.intro = textField.text;
            }
        }
    }
    
}
///键盘显示事件
//- (void) keyboardWillShow:(NSNotification *)notification {
//    //获取键盘高度，在不同设备上，以及中英文下是不同的
//    CGFloat kbHeight = [[notification.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size.height;
//    
////    //计算出键盘顶端到inputTextView panel底端的距离(加上自定义的缓冲距离INTERVAL_KEYBOARD)
////    CGFloat offset = (textView.frame.origin.y+textView.frame.size.height+INTERVAL_KEYBOARD) - (self.view.frame.size.height - kbHeight);
//    CGFloat offset = kbHeight;
//    
//    // 取得键盘的动画时间，这样可以在视图上移的时候更连贯
//    double duration = [[notification.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];

    //将视图上移计算好的偏移
//    if(offset > 0) {
//        [UIView animateWithDuration:duration animations:^{
//            self.view.frame = CGRectMake(0.0f, -offset, self.view.frame.size.width, self.view.frame.size.height);
//        }];
//    }
//}

///键盘消失事件
- (void) keyboardWillHide:(NSNotification *)notify {
    // 键盘动画时间
    double duration = [[notify.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    
    //视图下沉恢复原状
    [UIView animateWithDuration:duration animations:^{
        self.view.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    }];
}


- (void)keyboardOut{
    for (NSInteger i=0; i<5; i++) {
        if (i==2) {
            for (NSInteger j=0; j<2; j++) {
                Edit_DeviceDetailCell *cell = (Edit_DeviceDetailCell *)[mainTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:j inSection:i]];
                [cell.leftTextField resignFirstResponder];
            }
        }else{
            Edit_DeviceDetailCell *cell = (Edit_DeviceDetailCell *)[mainTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:i]];
            [cell.leftTextField resignFirstResponder];
        }
       
    }
//    [feedTextFied.FeedField resignFirstResponder];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 5;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if(section == 2){
        return 2;
    }else{
        return 1;
    }
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if(section ==0){
        return @"设备名称";
    }else if(section ==1){
        return @"设备地址";
    }else if(section ==2){
        return @"负责人";
    }else if(section ==3){
        return @"设备分组";
    }else if(section ==4){
        return @"备注";
    }else{
        return @" ";
    }
}

//section底部间距
- (CGFloat)tableView:(UITableView* )tableView heightForFooterInSection:(NSInteger)section
{
    return 5;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.section == 1 && indexPath.row == 0){
        
        return 70;
    }
    
    return 50;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
        Edit_DeviceDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ssss"];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
        if(!cell){
            cell = [[Edit_DeviceDetailCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"ssss"];
            
        }
    if (indexPath.section == 0) {
        [cell.leftTextField setText:_deviceDetailModel.deviceName];
        cell.leftTextField.tag = nameTag;
        cell.leftTextField.placeholder = @"最多10个中英文字符";
    }else if (indexPath.section == 1) {
        [cell.leftTextField setText:_deviceDetailModel.deviceAddress];
        cell.leftTextField.placeholder = @"最多100个中英文字符";
        cell.leftTextField.tag = addressTag;
    }else if(indexPath.section == 2){
        if (indexPath.row == 0) {
            [cell.leftTextField setText:_deviceDetailModel.headName];
            cell.leftTextField.placeholder = @"最多10个中英文字符";
        }else{
            [cell.leftTextField setText:_deviceDetailModel.headPhone];
            cell.leftTextField.placeholder = @"请输入电话号码 最多20个中英文字符";
        }
    }else if(indexPath.section == 3){
        cell.accessoryType =UITableViewCellAccessoryDisclosureIndicator;
        [cell.leftTextField setText:_deviceDetailModel.groupName];
        cell.leftTextField.enabled = NO;
    }else if(indexPath.section == 4){
        [cell.leftTextField setText:_deviceDetailModel.intro];
        cell.leftTextField.placeholder = @"最多100个中英文字符";
    }
    
    return cell;

    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    Edit_DeviceDetailCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    NSLog(@"%@",cell.leftTextField.text);
    if(indexPath.section == 0){
        
        
        
    }else if(indexPath.section == 1){
    
    }
    else if(indexPath.section == 2){
        if (indexPath.row == 0) {
//            [cell.leftTextField setText:_deviceDetailModel.headName];
        }else{
//            [cell.leftTextField setText:_deviceDetailModel.headPhone];
        }
    }else if(indexPath.section == 3){
        DeviceGroupVC *deviceGroupVC = [[DeviceGroupVC alloc]init];
        deviceGroupVC.groupName = _deviceDetailModel.groupName;
        [self presentViewController:deviceGroupVC animated:YES completion:nil];
        deviceGroupVC.block=^(NSString * groupName,NSInteger gid){
            _deviceDetailModel.groupName = groupName;
            _deviceDetailModel.gid = [NSNumber numberWithInteger:gid];
            [mainTableView reloadData];
        };


    }else if(indexPath.section == 4){
//        [cell.leftTextField setText:_deviceDetailModel.intro];
    }
    

}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch{
    
    if ([touch.view isKindOfClass:NSClassFromString(@"UITableViewCellContentView")]) {
        return NO;
    }else{
        return YES;
    }
}
@end
