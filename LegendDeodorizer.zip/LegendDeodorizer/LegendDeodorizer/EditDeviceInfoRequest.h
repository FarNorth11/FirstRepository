//
//  EditDeviceInfoRequest.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/5.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "HETRequest.h"

@interface EditDeviceInfoRequest : HETRequest

- (instancetype)initWithAccessToken: (NSString *)accessToken mac:(NSString *)mac deviceName:(NSString *)deviceName deviceAddress:(NSString *)deviceAddress headName:(NSString *)headName  headPhone:(NSString *)headPhone gid:(NSInteger )gid intro:(NSString *)intro;

- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock;

@end
