//
//  SmartModeView.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/31.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SmartModel.h"

@class SmartModeView;

@protocol returnModeSettingDelegate <NSObject>

@optional

- (void)returnModeSetting:(NSInteger)modeType week:(NSString *)week threshold:(NSString *) threshold setList:(NSArray *)setList;

@end
//typedef void (^ returnModeSetting)(NSInteger modeType,NSString *week,NSString *threshold,NSArray * setList);
@interface SmartModeView : UIView<UITableViewDelegate,UITableViewDataSource,UIPickerViewDelegate,UIPickerViewDataSource>
@property(nonatomic,strong)SmartModel *smartModeDic;
@property(weak,nonatomic) id<returnModeSettingDelegate> delegate;
- (void)getDataModel;
@end
