//
//  DeviceGroupCell.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/10.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeviceGroupCell : UITableViewCell

@property (nonatomic,strong) UILabel    *titleLabel;
@property (nonatomic,strong) UIButton *rightButton;

@end
