//
//  HelpMsg.h
//  SmartHome
//
//  Created by luojie on 14-10-20.
//  Copyright (c) 2014年 Het. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <SystemConfiguration/SystemConfiguration.h>
#include <netdb.h>
#import "MBProgressHUD.h"

typedef enum{
    ClientiPhone4=1,
    ClientiPod1G=2,
    ClientiPhone4S=3,
    ClientiPad1=4,
    ClientiPhone5=5,
    ClientiPhone1G=6,
    ClientiPhone2G=7,
    ClientiPhone3GS=8,
    ClientiPod2G=9,
    ClientiPod3G=10,
    ClientiPod4G=11,
    ClientiPad2=12,
    ClientiPad3=13,
} ClientType;//客户端机器型号

//#import "Constants.h"

@interface HelpMsg : NSObject

+(MBProgressHUD *)showCustomHudtitle:(NSString *)title targetView:(UIView *)targetView;
+(void) showCustomHud:(UIImage *)image title:(NSString *)title targetView:(UIView *)targetView;
+(BOOL) connectedToNetwork;
+(void)showAlert:(NSString *)title msg:(NSString *)msg;
+(ClientType)getClientTypeID;
+(BOOL)showMsg:(NSString *)msg;
+(void)showMessage:(NSString *)message inView:(UIView *)view;
+(MBProgressHUD *)showCustomHudtitleTowindow:(NSString *)title duration:(NSTimeInterval)duration;
+(void)showAlert:(NSString *)title msg:(NSString *)msg duration:(NSTimeInterval)duration;
+(MBProgressHUD *)showCustomHudtitleTowindow:(NSString *)title;
@end
