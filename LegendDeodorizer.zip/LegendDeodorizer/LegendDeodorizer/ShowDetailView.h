//
//  ShowDetailView.h
//  LegendDeodorizer
//
//  Created by Starlueng on 2017/3/31.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SetListModel.h"
typedef void (^tapBlock)(id);
@interface ShowDetailView : UIView

@property (assign,nonatomic) BOOL isHightSelect;//是否gao liang
@property (copy,nonatomic) UILabel *detailLabel;//设置详情label
@property (copy,nonatomic)tapBlock block;
-(instancetype)initWithFrame:(CGRect)frame Item:(NSString *)item detail:(SetListModel *)detail TapAction:(tapBlock)tapblock;
@end
