//
//  GetGroupListRequest.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/5.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "GetGroupListRequest.h"
#import "HETRequest+Private.h"

@implementation GetGroupListRequest{
    NSString  *_accessToken;
    NSNumber *_pageIndex;
    NSNumber *_pageRows;
}
-(instancetype)initWithAccessToken:(NSString *)accessToken pageIndex:(NSNumber *)pageIndex pageRows:(NSNumber *)pageRows{
    self = [super init];
    if (self) {
        _accessToken = accessToken;
        _pageIndex = pageIndex;
        _pageRows = pageRows;
    }
    
    return self;

}
- (YTKRequestMethod)requestMethod{
    
    return YTKRequestMethodGet;
    
}

-(BOOL)isHttpsType{
    
    return YES;
}

-(NSString *)requestUrl{
    
    return [@"/v1/app/customization/legend" stringByAppendingString: @"/getGroupList"];
    
}

- (id)requestArgument{
    
    return @{
             @"accessToken":_accessToken,
             @"pageIndex" : _pageIndex,
             @"pageRows" : _pageRows
             };
    
}

//- (void)startWithSuccessBlockArrayParameter: (HETHttpSuccessBlockArrayParameter)successBlock
//                                    failure: (HETHttpFailureBlock)failureBlock{
//    [super startWithSuccessBlockArrayParameter:successBlock failure:failureBlock];
//}

- (void)startWithSuccessBlockDictionaryParameter: (HETHttpSuccessBlockDictionaryParameter)successBlock
                                         failure: (HETHttpFailureBlock)failureBlock{
    [super startWithSuccessBlockDictionaryParameter:successBlock failure:failureBlock];
}

@end
