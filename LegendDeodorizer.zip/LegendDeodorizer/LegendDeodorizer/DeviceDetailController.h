//
//  DeviceDetailController.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/28.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainDevice.h"


typedef void (^titleStringBlock)(NSString *);



@interface DeviceDetailController : UIViewController<UITableViewDelegate,UITableViewDataSource>

@property (copy,nonatomic)titleStringBlock titleStringBlock;

@property(nonatomic,strong)MainDevice *device ;

@end
