//
//  HelpMsg.m
//  SmartHome
//
//  Created by luojie on 14-10-20.
//  Copyright (c) 2014年 Het. All rights reserved.
//

#import "HelpMsg.h"
#import "sys/utsname.h"
#import "MessageView.h"
#import "AppDelegate.h"
@interface ModalAlertDelegate : NSObject <UIAlertViewDelegate>
{
    CFRunLoopRef currentLoop;
    NSUInteger index;
}
@property (readonly) NSUInteger index;
@end

@implementation ModalAlertDelegate
@synthesize index;

// Initialize with the supplied run loop
-(id) initWithRunLoop: (CFRunLoopRef)runLoop
{
    if (self = [super init]) currentLoop = runLoop;
    return self;
}

// User pressed button. Retrieve results
-(void) alertView: (UIAlertView*)aView clickedButtonAtIndex: (NSInteger)anIndex
{
    index = anIndex;
    CFRunLoopStop(currentLoop);
}

@end

@implementation HelpMsg


+(void)showMessage:(NSString *)message inView:(UIView *)view
{
    MessageView *msgView=[[MessageView alloc] initWithText:message];
    [msgView setAlpha:0];
    [view addSubview:msgView];
    [UIView beginAnimations:nil context:nil];
    [msgView setAlpha:0.8];
    [UIView commitAnimations];
    
    [msgView performSelector:@selector(hideView:) withObject:[NSNumber numberWithBool:YES] afterDelay:0.8f];
}

+(MBProgressHUD *)showCustomHudtitle:(NSString *)title targetView:(UIView *)targetView
{
    MBProgressHUD *hud=[[MBProgressHUD alloc] initWithView:targetView] ;
    [targetView addSubview:hud];
    hud.dimBackground = YES;
    [hud setLabelText:title];
    [hud show:YES];
    return hud;
}

+(MBProgressHUD *)showCustomHudtitleTowindow:(NSString *)title duration:(NSTimeInterval)duration
{
    AppDelegate *appDeelgate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    MBProgressHUD *hud=[[MBProgressHUD alloc] initWithView:appDeelgate.window] ;
    hud.dimBackground = YES;
    [appDeelgate.window addSubview:hud];
    [hud setLabelText:title];
    [hud show:YES];
    hud.removeFromSuperViewOnHide=YES;
    [hud hide:YES afterDelay:duration];
    return hud;
}

+(MBProgressHUD *)showCustomHudtitleTowindow:(NSString *)title
{
    AppDelegate *appDeelgate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
    MBProgressHUD *hud=[[MBProgressHUD alloc] initWithView:appDeelgate.window] ;
    hud.dimBackground = YES;
    [appDeelgate.window addSubview:hud];
    [hud setLabelText:title];
    [hud show:YES];
    hud.removeFromSuperViewOnHide=YES;
    return hud;
}

+(void)showCustomHud:(UIImage *)image title:(NSString *)title targetView:(UIView *)targetView
{
    MBProgressHUD *hud=[[MBProgressHUD alloc] initWithView:targetView];
    [targetView addSubview:hud];
    UIImageView *imgView=[[UIImageView alloc] initWithImage:image];
    hud.customView=imgView;
    imgView=nil;
    hud.mode=MBProgressHUDModeCustomView;
    //hud.canPointInside=NO;
    [hud setLabelText:title];
    [hud show:YES];
    hud.removeFromSuperViewOnHide=YES;
    [hud hide:YES afterDelay:1.5];
}

+(BOOL) connectedToNetwork
{
    // Create zero addy
    struct sockaddr_in zeroAddress;
    bzero(&zeroAddress, sizeof(zeroAddress));
    zeroAddress.sin_len = sizeof(zeroAddress);
    zeroAddress.sin_family = AF_INET;
    
    // Recover reachability flags
    SCNetworkReachabilityRef defaultRouteReachability = SCNetworkReachabilityCreateWithAddress(NULL, (struct sockaddr *)&zeroAddress);
    SCNetworkReachabilityFlags flags;
    
    BOOL didRetrieveFlags = SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags);
    CFRelease(defaultRouteReachability);
    
    if (!didRetrieveFlags)
    {
        printf("Error. Could not recover network reachability flags\n");
        return NO;
    }
    
    BOOL isReachable = ((flags & kSCNetworkFlagsReachable) != 0);
    BOOL needsConnection = ((flags & kSCNetworkFlagsConnectionRequired) != 0);
    return (isReachable && !needsConnection) ? YES : NO;
}

+(void)showAlert:(NSString *)title msg:(NSString *)msg
{
    /*
     if(title==nil)
     {
     title=@"温馨提示";
     }
     */
    UIAlertView *alert=[[UIAlertView alloc] initWithTitle:title message:msg delegate:nil cancelButtonTitle:NSLocalizedString(@"确定",nil) otherButtonTitles: nil];
    [alert show];
}

+(ClientType)getClientTypeID
{
    ClientType type=0;
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString *device=[NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
    if( [device isEqualToString:@"i386"] || [device isEqualToString:@"x86_64"] ) type=0;
    else if( [device isEqualToString:@"iPhone1,1"] ) type=ClientiPhone1G;
    else if( [device isEqualToString:@"iPhone1,2"] ) type=ClientiPhone2G;
    else if( [device isEqualToString:@"iPhone2,1"] ) type=ClientiPhone3GS;
    else if( [device isEqualToString:@"iPhone3,1"] ) type=ClientiPhone4;
    else if( [device isEqualToString:@"iPod1,1"] ) type=ClientiPod1G;
    else if( [device isEqualToString:@"iPod2,1"] ) type=ClientiPod2G;
    else if( [device isEqualToString:@"iPod3,1"] ) type=ClientiPod3G;
    else if( [device isEqualToString:@"iPod4,1"] ) type=ClientiPod4G;
    else if( [device isEqualToString:@"iPad1,1"] ) type=ClientiPad1;
    else if( [device isEqualToString:@"iPad2,1"] ) type=ClientiPad2;
    else if( [device isEqualToString:@"iPad3,1"] ) type=ClientiPad3;
    else if( [device isEqualToString:@"iPhone4,1"]) type=ClientiPhone4S;
    else if( [device isEqualToString:@"iPhone5,1"]) type=ClientiPhone5;
    return type;
}

+(BOOL)showMsg:(NSString *)msg
{
    CFRunLoopRef currentLoopRef=CFRunLoopGetCurrent();
    
    // Create Alert
    ModalAlertDelegate *madelegate = [[ModalAlertDelegate alloc] initWithRunLoop:currentLoopRef];
    UIAlertView *alert=[[UIAlertView alloc] initWithTitle:NSLocalizedString(@"提示",nil) message:msg delegate:madelegate
                                        cancelButtonTitle:NSLocalizedString(@"是",nil)
                                        otherButtonTitles:NSLocalizedString(@"否", nil),nil];
    [alert show];
    
    CFRunLoopRun();
    
    NSInteger index=madelegate.index;
    if(index==0)
    {
        return YES;
    }
    else {
        return NO;
    }
}

+(void)showAlert:(NSString *)title msg:(NSString *)msg duration:(NSTimeInterval)duration
{
    UIAlertView *alert=[[UIAlertView alloc] initWithTitle:title message:msg delegate:nil cancelButtonTitle:NSLocalizedString(@"确定",nil) otherButtonTitles: nil];
    [alert show];
    [alert performSelector:@selector(dismissAnimated:) withObject:[NSNumber numberWithBool:YES] afterDelay:duration];
}

@end

