//
//  ModeSettingController.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/30.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "ModeSettingController.h"
#import "UINavigationController+FDFullscreenPopGesture.h"
#import "ModeSetting_ScrollView.h"
#import "GetDeviceModeRequest.h"
#import "SetDeviceModeRequest.h"
#import "K_ModeSettingView.h"

@interface ModeSettingController ()

@end

@implementation ModeSettingController{
    NSMutableArray *ModeDataArr;
//    ModeSetting_ScrollView *modeSetting;
    K_ModeSettingView *modeSetting;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.fd_prefersNavigationBarHidden = YES;
    self.view.backgroundColor = WHITECOLOR;
    [self createNaviView];
    [self createMainView];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    AppDelegate *app =(AppDelegate *)[UIApplication sharedApplication].delegate;
    app.root.tabBar.hidden = YES;
    app.root.button.hidden = YES;
    [self getDeviceMode];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark-=====================Request====================
- (void)getDeviceMode{
    GetDeviceModeRequest *getDeviceMode = [[GetDeviceModeRequest alloc]initWithAccessToken:[HETUserInfo userInfo].accessToken  mac:self.device.macAddress];
    ModeDataArr = [[NSMutableArray alloc]initWithCapacity:8];
    [getDeviceMode startWithSuccessBlockArrayParameter:^(NSArray *arrayValue) {
        NSLog(@"GetDeviceModeRequest成功");
        if (arrayValue.count>0) {
            ModeDataArr = [arrayValue mutableCopy];
            
        }
//        NSDictionary *dic = arrayValue[0];
//        NSString *string = dic[@"week"];
        if (modeSetting.modeDataArr) {
            modeSetting.modeDataArr= ModeDataArr;
        }else{
            modeSetting.modeDataArr = [NSMutableArray arrayWithArray:ModeDataArr];
        }
        [modeSetting getDataMode];
        [modeSetting.smartModeView getDataModel];
        [modeSetting.manualModeView getDataModel];
        /*
         <__NSCFArray 0x14ef10c0>(
         {
         modeType = 1;
         setList = "<null>";
         threshold = "1.35,1.05";
         week = "1,2,3,4,5";
         },
         {
         modeType = 2;
         setList =     (
         {
         endTime = "07:30";
         isUsed = 0;
         openTime = 5;
         startTime = "07:00";
         stopTime = 5;
         },
         {
         endTime = "08:30";
         isUsed = 0;
         openTime = 5;
         startTime = "08:00";
         stopTime = 5;
         }
         );
         threshold = "<null>";
         week = "1,2,3,4,5";
         }
         )
         */

        
    } failure:^(NSError *error, NSInteger statusCode) {
        if (error.code == 0) {
            [HelpMsg showMessage:@"当前网络不可用" inView:[[UIApplication sharedApplication].delegate window]];
        }
        
    }];
}

-(void)setDeviceModeByModeType:(NSInteger)modeType  week:(NSString *)week threshold:(NSString *)threshold setList:(NSArray  *)setList{
    
    [self  dismissViewControllerAnimated:YES completion:nil];
    NSString *setListStr = @"[";
    if (modeType == 1) {
        setListStr=nil;
//        if (self.clickBack) {
//            self.clickBack(@1);
//        }
    }else{
//        if (self.clickBack) {
//            self.clickBack(@2);
//        }
        
        for (NSDictionary *dic in setList) {
            setListStr = [setListStr stringByAppendingString:[self dictionaryToJson:dic]];
            setListStr = [setListStr stringByAppendingString:@","];
        }
        
        setListStr = [setListStr substringToIndex:setListStr.length-1 ];
        setListStr = [setListStr stringByAppendingString:@"]"];
    }
    
    SetDeviceModeRequest *setDeviceMode = [[SetDeviceModeRequest alloc]initWithAccessToken:[HETUserInfo userInfo].accessToken appType:3 mac:self.device.macAddress modeType:modeType week:week threshold:threshold setList:setListStr];
    [setDeviceMode startWithSuccess:^(NSDictionary *dictValue) {
//        [HelpMsg showMessage:@"设置成功" inView:[[[UIApplication sharedApplication]delegate]window]];
        if (modeType == 1) {
            if (self.clickBack) {
                self.clickBack(@1);
            }

        }else{
            if (self.clickBack) {
                self.clickBack(@2);
            }
        }


        
    } failure:^(NSError *error, NSInteger statusCode) {
        [HelpMsg showMessage:@"设置失败" inView:[[[UIApplication sharedApplication]delegate]window]];
        if (error.code == 0) {
            [HelpMsg showMessage:@"当前网络不可用" inView:[[UIApplication sharedApplication].delegate window]];
        }
        
        if (modeType == 1) {
            if (self.clickBack) {
                self.clickBack(@1);
            }
            
        }else{
            if (self.clickBack) {
                self.clickBack(@2);
            }
        }

    }];

}

- (NSString*)dictionaryToJson:(NSDictionary *)dic

{
    NSString *str=@"";
    
    NSError *parseError = nil;
    
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&parseError];
    
    str = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    return str;
    
}
#pragma mark-=====================UI====================
- (void)createNaviView{

    
    
    UIButton *leftBtn =[UIButton setButtonWithNomalImage:[UIImage imageNamed:@"arrow_back_black"] AndSelectImage:[UIImage imageNamed:@"arrow_back_black"] AndFrame:CGRectMake(0, STATUSBARHEIGHT, 60, NAVIBARHEIGHT)];
    
    leftBtn.imageEdgeInsets =UIEdgeInsetsMake(0, 0, 0, 0);
    [leftBtn addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
    
    UILabel *label =[UILabel setLabelWith:@"模式设置" AndFont:[UIFont systemFontOfSize:18] AndIsNumberOfLines:NO AndtextColor:[UIColor blackColor] AndFrame:CGRectMake((ScreenWidth-100)/2, STATUSBARHEIGHT, 100, NAVIBARHEIGHT) AndAlignment:NSTextAlignmentCenter];
    [self.view addSubview:leftBtn];
    [self.view addSubview:label];
    
    CALayer *lineLayer = [[CALayer alloc]init];
    lineLayer.frame = CGRectMake(0, NAVIBARHEIGHT+STATUSBARHEIGHT-1, ScreenWidth, SINGLE_LINE_WIDTH);
    lineLayer.backgroundColor = KCOLOR(@"c7c7c7").CGColor;
    [self.view.layer addSublayer:lineLayer];
    
    
}
- (void)createMainView{
//    modeSetting = [[ModeSetting_ScrollView alloc]initWithFrame:CGRectMake(0, NAVIBARHEIGHT+STATUSBARHEIGHT, ScreenWidth, ScreenHeight-NAVIBARHEIGHT-STATUSBARHEIGHT)];
//    modeSetting.modeDataArr = ModeDataArr;
//    modeSetting.backgroundColor = [UIColor whiteColor];
//    @weakify(self);
//    modeSetting.block =^(NSInteger modeType,NSString *week,NSString *threshold,NSArray * setList){
//        @strongify(self);
//        [self setDeviceModeByModeType:modeType week:week threshold:threshold setList:setList];
//    };
//    
//    [self.view addSubview:modeSetting];
//
    
    modeSetting = [[K_ModeSettingView alloc]initWithFrame:CGRectMake(0, NAVIBARHEIGHT+STATUSBARHEIGHT, ScreenWidth, ScreenHeight-NAVIBARHEIGHT-STATUSBARHEIGHT) ModeDataArr:ModeDataArr];
    modeSetting.backgroundColor = [UIColor whiteColor];
    @weakify(self);
    modeSetting.block =^(NSInteger modeType,NSString *week,NSString *threshold,NSArray * setList){
        @strongify(self);
        [self setDeviceModeByModeType:modeType week:week threshold:threshold setList:setList];
    };
    
    [self.view addSubview:modeSetting];
    

}
#pragma mark-=====================ACTION====================
-(void)buttonClick:(id)sender{
//    AppDelegate *app =(AppDelegate *)[UIApplication sharedApplication].delegate;
//    app.root.tabBar.hidden = NO;
//    app.root.button.hidden = NO;
//    app.root.selectedIndex =0;
    [self  dismissViewControllerAnimated:YES completion:nil];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
