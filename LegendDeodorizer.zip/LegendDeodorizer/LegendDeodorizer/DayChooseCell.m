//
//  DayChooseCell.m
//  LegendDeodorizer
//
//  Created by Starlueng on 2017/3/31.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "DayChooseCell.h"

@implementation DayChooseCell
static NSInteger const firstDayTag  = 1001;
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        NSString * string = @"星期";
        CGSize size = [string sizeWithAttributes:@{NSFontAttributeName:KFONT(16)}];
        UILabel *label = [UILabel setLabelWith:@"星期" AndFont: KFONT(16) AndIsNumberOfLines:YES AndtextColor: KCOLOR(@"000000") AndFrame:CGRectMake(16 *NewBasicWidth, 15, size.width, 18) AndAlignment:NSTextAlignmentLeft];
        [self.contentView addSubview:label];
        
        NSArray *days = @[@"一",@"二",@"三",@"四",@"五",@"六",@"日"];
        for (NSInteger i=0; i<days.count; i++) {
            UIButton *button = [UIButton setButtonWith:days[i] AndNomalColor:WHITECOLOR AndSelectColor:WHITECOLOR AndFont:KFONT(16) AndFrame:CGRectMake(CGRectGetMaxX(label.frame)+24 *NewBasicWidth +(14 *NewBasicWidth+24) *i, 12, 24, 24)];
            [button setBackgroundImage:[UIImage imageNamed:@"yuandian_gray"] forState:UIControlStateNormal];
            [button setBackgroundImage:[UIImage imageNamed:@"yuandian_green"] forState:UIControlStateSelected];
            button.tag = firstDayTag + i;
            [self.contentView addSubview:button];
            [button addTarget:self action:@selector(changestate:) forControlEvents:UIControlEventTouchUpInside];
        }
    }
    return self;
}

//选择dayCell的工作状态(初始状态)
- (void)setRetState:(NSArray *)selects{
    if (selects&&selects.count==7) {
        for (NSInteger i=0; i<7; i++) {
            UIButton *button = (UIButton *)[self viewWithTag:i+firstDayTag];
            NSInteger selectNum = [selects[i]integerValue];
            if (selectNum ==YES) {
                button.selected = YES;
            }else{
                button.selected = NO;
            }
            
        }
    }
  
    
//    for
}

//daycell被点击后,数据被改变
- (void)changestate:(UIButton *)button{
    
    button.selected =! button.selected;
    NSMutableArray *selectArray = [NSMutableArray array];
    
    for (NSInteger i=0; i<7; i++) {
        UIButton *button = (UIButton *)[self viewWithTag:i+firstDayTag];
        if (button.selected) {
            [selectArray addObject:@(i+1)];
        }
    }
    
    NSString *s = [selectArray componentsJoinedByString:@","];
   
    if (self.click) {
        self.click(s);
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
