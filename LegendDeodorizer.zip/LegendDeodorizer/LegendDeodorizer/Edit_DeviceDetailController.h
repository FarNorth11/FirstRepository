//
//  Edit_DeviceDetailController.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/9.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainDevice.h"
#import "DeviceDetailModel.h"

@interface Edit_DeviceDetailController : UIViewController<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,strong)DeviceDetailModel *deviceDetailModel ;

@end
