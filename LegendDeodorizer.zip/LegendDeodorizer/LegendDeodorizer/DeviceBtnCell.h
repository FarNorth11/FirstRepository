//
//  DeviceBtnCell.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/29.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeviceBtnCell : UICollectionViewCell

@property (nonatomic,strong) UIImageView *BtnImageView;//左视图

@property (nonatomic,strong) UILabel *midLabel;


- (void)createUI;

@end

