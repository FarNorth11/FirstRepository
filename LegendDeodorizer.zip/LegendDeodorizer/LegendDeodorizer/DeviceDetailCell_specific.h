//
//  DeviceDetailCell_specific.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/7.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DeviceDetailCell_specific : UITableViewCell
@property (nonatomic,strong) UILabel *leftLabel;

@end
