//
//  GetGroupDeviceListRequest.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/5.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "GetGroupDeviceListRequest.h"
#import "HETRequest+Private.h"

@implementation GetGroupDeviceListRequest{
    NSString  *_accessToken;
    NSInteger _gid;
    NSNumber *_pageIndex;
    NSNumber *_pageRows;
}

-(instancetype)initWithAccessToken:(NSString *)accessToken gid:(NSInteger)gid pageIndex:(NSNumber *)pageIndex pageRows:(NSNumber *)pageRows{
    self = [super init];
    if (self) {
        _accessToken = accessToken;
        _gid = gid;
        _pageIndex = pageIndex;
        _pageRows = pageRows;
    }
    
    return self;
    
}
- (YTKRequestMethod)requestMethod{
    
    return YTKRequestMethodGet;
    
}

-(BOOL)isHttpsType{
    
    return YES;
}

-(NSString *)requestUrl{
    
    return [@"/v1/app/customization/legend" stringByAppendingString: @"/getGroupDeviceList"];
    
}

- (id)requestArgument{
    
    return @{
             @"accessToken":_accessToken,
             @"gid" : @(_gid),
             @"pageIndex":_pageIndex,
             @"pageRows":_pageRows
             };
    
}

- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock{
    [super startWithSuccessBlockDictionaryParameter:successBlock failure:failureBlock];
}


@end
