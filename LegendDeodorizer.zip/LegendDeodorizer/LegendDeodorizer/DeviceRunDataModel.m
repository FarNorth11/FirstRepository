//
//  DeviceRunDataModel.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/8.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "DeviceRunDataModel.h"
#import "NSDictionary+SAMAdditions.h"
#import <objc/runtime.h>

@implementation DeviceRunDataModel

- (void)setValue:(id)value forKey:(NSString *)key{
    if ([key isEqualToString:@"setList"]) {
        NSArray *list  = (NSArray *)value;
        NSMutableArray *mutableArray = [[NSMutableArray alloc]init];
        if (list.count >0) {
            for (NSDictionary *dic in list) {
                DeviceRunDataModel *model = [[DeviceRunDataModel alloc]init];
                [model setValuesForKeysWithDictionary:dic];
                [mutableArray addObject:model];
            }
            
        }
        [super setValue:mutableArray forKey:key];
    }else{
        [super setValue:value forKey:key];
    }
}
- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    
}

//-(instancetype)initWithData:(NSDictionary *)dic{
//    self = [super init];
//    if (self) {
//        //sam_safeObjectForKey是为了回避出现nil的情况,是SAMCategarys中带的类,会把NULL替换成nil
//        self.Deodorant = [[dic sam_safeObjectForKey:@"Deodorant"] integerValue];
////        self.Ammonialow = [[dic sam_safeObjectForKey:@"Ammonialow"]integerValue ];
//        
//        NSNumber *Ammonialow = [dic objectForKey:@"Ammonialow"];
//        if ([Ammonialow  isEqual: @(0)] ){
//            self.Ammonialow = 0;
//        }else{
//            self.Ammonialow = [Ammonialow integerValue];
//        }
//        
//        NSNumber *ammonia = [dic objectForKey:@"Ammoniahigh"];
//        if ([ammonia  isEqual: @(0)] ) {
//            self.Ammoniahigh = 0;
//        }else{
//            self.Ammoniahigh = [ammonia integerValue];
//        }
//        
//        self.FanError = [[dic sam_safeObjectForKey:@"FanError"] integerValue];
//        self.FanError2 = [[dic sam_safeObjectForKey:@"FanError2"]integerValue ];
//        self.AtomizerError = [[dic sam_safeObjectForKey:@"AtomizerError"] integerValue];
//        self.AtomizerError2 = [[dic sam_safeObjectForKey:@"AtomizerError2"] integerValue];
//        self.SolenoidValveError = [[dic sam_safeObjectForKey:@"SolenoidValveError"]integerValue ];
//        self.SolenoidValveError2 = [[dic sam_safeObjectForKey:@"SolenoidValveError2"] integerValue];
//        self.FluidPumpError = [[dic sam_safeObjectForKey:@"FluidPumpError"] integerValue];
//        self.AmmoniaSensorError = [[dic sam_safeObjectForKey:@"AmmoniaSensorError"]integerValue ];
//        self.LiquidLevelSensorError = [[dic sam_safeObjectForKey:@"LiquidLevelSensorError"] integerValue];
//        self.WorkplaceLevelSensorError = [[dic sam_safeObjectForKey:@"WorkplaceLevelSensorError"] integerValue];
//    }
//    return self;
//
//
//}

-(NSDictionary *) convertModelToDictionary
{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init
                                ];
    
    
    for (NSString *key in [self propertyKeys]) {
        
        id propertyValue = [self
                            valueForKey:key];
        
        //该值不为NSNULL，并且也不为nil
        
        [dic setObject:propertyValue forKey:key];
    }
    
    
    return
    dic;
}


- (NSArray*)propertyKeys

{
    
    unsigned int outCount, i;
    
    objc_property_t *properties = class_copyPropertyList([self class], &outCount);
    
    NSMutableArray *keys = [[NSMutableArray alloc] initWithCapacity:outCount];
    
    for (i = 0; i < outCount; i++) {
        
        objc_property_t property = properties[i];
        
        NSString *propertyName = [[NSString alloc] initWithCString:property_getName(property) encoding:NSUTF8StringEncoding];
        
        [keys addObject:propertyName];
        
    }
    
    free(properties);
    
    return keys;
    
}

@end
