//
//  GetGroupDeviceListRequest.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/5.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "HETRequest.h"

@interface GetGroupDeviceListRequest : HETRequest

- (instancetype)initWithAccessToken: (NSString *)accessToken gid:(NSInteger )gid pageIndex:(NSNumber*)pageIndex  pageRows:(NSNumber* )pageRows;


- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock;

@end
