//
//  BaseAlert.h
//  AVcaptureShow
//
//  Created by starlueng on 16/6/29.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef void (^AlertBlock)(NSNumber *num);
/**
 *  alertVc设置风格
 */
typedef NS_ENUM(NSInteger, AlertStyle) {
    /**
     *  sheet
     */
    AlertStyleActionSheet = 0,
    /**
     *  alert
     */
    AlertStyleAlert       = 1,
};
@interface BaseAlert : NSObject<UIActionSheetDelegate,UIAlertViewDelegate>

@property (copy,nonatomic) NSArray *buttonList;
@property (copy,nonatomic) AlertBlock actionShow;

/**
 *  alert版本忽略
 *
 *  @param alertStyle  alert风格
 *  @param title       标题
 *  @param message     信息
 *  @param buttonArray 按钮数组
 *
 */

+ (instancetype)shareInstance;

- (void)alertWithAlertStyle:(AlertStyle)alertStyle
                      title:(NSString *)title
                    message:(NSString *)message
             cancelBtnTitle:(NSString *)cancelTitle
                 buttonList:(NSArray *)buttonArray
      AndSelectButtonAction:(AlertBlock)actions;

@end
