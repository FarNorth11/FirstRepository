//
//  TimePickerView.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/11.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "TimePickerView.h"

@implementation TimePickerView{
    UIPickerView *selPartView;
    NSMutableArray *selectArr;
    NSString *_times;

}

- (instancetype)initWithFrame:(CGRect)frame andTimeReset:(NSString *)times AndSelectTime:(selectTimeBlock)selectTimeblock
{
    self = [super initWithFrame:frame];
    if (self) {
        _times = times;
        self.selectblock = selectTimeblock;
        [self createUI];
    }
    return self;
}

-(void)createUI{
    
    self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.4];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(actionCancel:)];
    [self addGestureRecognizer:tap];
    
//    control=[[UIControl  alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
//    control.backgroundColor=[UIColor colorWithRed:0 green:0 blue:0 alpha:0.4];
//    [self.window  addSubview:control];
//    [control  addTarget:self action:@selector(actionCancel:)   forControlEvents:UIControlEventTouchUpInside];
    
    //Toolbar
    UIToolbar  *toolbar=[[UIToolbar  alloc]  initWithFrame:CGRectMake(0,ScreenHeight*0.6,ScreenWidth,50)];
    toolbar.backgroundColor = WHITECOLOR;
    toolbar.autoresizingMask=UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleWidth;
    
    UIBarButtonItem *itemCancelDone=[[UIBarButtonItem alloc]initWithTitle:@"确定" style:UIBarButtonItemStylePlain  target:self action:@selector(actionConfirm:)];
    
    UIBarButtonItem  *itemCancel=[[UIBarButtonItem  alloc]initWithTitle:@"取消"  style:UIBarButtonItemStylePlain   target:self action:@selector(actionCancel:)];
    
    UIBarButtonItem  *itemTitle=[[UIBarButtonItem  alloc]initWithTitle:@"时段"  style:UIBarButtonItemStylePlain   target:self action:nil];
    
    
    UIBarButtonItem  *space=[[UIBarButtonItem  alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace  target:nil action:nil];
    [toolbar setItems:[NSArray  arrayWithObjects:space,itemCancel,space,space,itemTitle,space,space,itemCancelDone,space,nil]];
    [self  addSubview:toolbar];
    
    selPartView=[[UIPickerView alloc]initWithFrame:CGRectMake(0, self.frame.size.height*0.6+50, ScreenWidth, ScreenHeight *0.4- 50)];
    selPartView.backgroundColor=[UIColor whiteColor];
    selPartView.delegate=self;
    selPartView.dataSource=self;
    
    NSMutableArray *Arr_24 = [[NSMutableArray alloc]initWithCapacity:10];
    NSMutableArray *Arr_60 = [[NSMutableArray alloc]initWithCapacity:100];
    
    for(int i=0;i<24;i++){
        if (i<10) {
            [Arr_24 addObject:[NSString stringWithFormat:@"0%d",i]];
        }else{
            [Arr_24 addObject:[NSString stringWithFormat:@"%d",i]];
        }
        
    }
    for(int i=0;i<60;i++){
        if (i<10) {
            [Arr_60 addObject:[NSString stringWithFormat:@"0%d",i]];
        }else{
            [Arr_60 addObject:[NSString stringWithFormat:@"%d",i]];
        }
    }
    selectArr=[[NSMutableArray alloc]initWithCapacity:4];
    [selectArr addObject:Arr_24];
    [selectArr addObject:Arr_60];
    [selectArr addObject:Arr_24];
    [selectArr addObject:Arr_60];
    
    //增加选中行说明文字
    [self addSelectCellStr];
    [self addSubview:selPartView];
    
    //选择当前选中的数据行
    [self selectBeforeDataRow];

    
}

- (void)addSelectCellStr{
    //选中行的附属文字说明
    UIView *titleView = [[UIView alloc]initWithFrame:CGRectMake(0, selPartView.frame.size.height*0.43, ScreenWidth, 25)];
    //    titleView.backgroundColor = [UIColor lightGrayColor];
    //    titleView.layer.opacity =0.5;
    
    CGSize anaSize1=[@"时" sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:10]}];
    
    UILabel *diandian1 = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth*0.27, 0, anaSize1.width, 25)];
    diandian1.text=@"时";
    //    [diandian1 setBackgroundColor:[UIColor redColor]];
    diandian1.font = [UIFont systemFontOfSize:10];
    [titleView addSubview:diandian1];
    
    
    UILabel *diandian2 = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth*0.42, 0, anaSize1.width, 25)];
    diandian2.text=@"分";
    diandian2.font = [UIFont systemFontOfSize:10];
    //    [diandian2 setBackgroundColor:[UIColor redColor]];
    [titleView addSubview:diandian2];
    
    
    UILabel *diandian3 = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(diandian2.frame)+10, 0, 10, 25)];
    diandian3.text=@"-";
    //    [diandian3 setBackgroundColor:[UIColor redColor]];
    [titleView addSubview:diandian3];
    
    UILabel *diandian4 = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth*0.7, 0, anaSize1.width, 25)];
    diandian4.text=@"时";
    //    [diandian4 setBackgroundColor:[UIColor redColor]];
    diandian4.font = [UIFont systemFontOfSize:8];
    [titleView addSubview:diandian4];
    
    
    UILabel *diandian5 = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth*0.85, 0, anaSize1.width, 25)];
    diandian5.text=@"分";
    diandian5.font = [UIFont systemFontOfSize:10];
    //    [diandian5 setBackgroundColor:[UIColor redColor]];
    [titleView addSubview:diandian5];
    
    
    [selPartView addSubview:titleView];
}

-(void)selectBeforeDataRow{
    NSArray *timesArray = [_times componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@":-"]];
    if (timesArray.count ==4) {
        [selPartView selectRow:[timesArray[0]integerValue] inComponent:0 animated:YES];
        [selPartView selectRow:[timesArray[1]integerValue] inComponent:1 animated:YES];
        [selPartView selectRow:[timesArray[2]integerValue] inComponent:2 animated:YES];
        [selPartView selectRow:[timesArray[3]integerValue] inComponent:3 animated:YES];
    }

}

-(void)actionCancel:(id)sender
{

    [self removeFromSuperview];
    
}


#pragma mark  -----发送配置请求
-(void)actionConfirm:(id)sender{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"HH:mm"];
    NSString *startTimeStr = [NSString stringWithFormat:@"%02ld:%02ld",(long)[selPartView selectedRowInComponent:0],(long)[selPartView selectedRowInComponent:1]];
    
    NSString *endTimeStr = [NSString stringWithFormat:@"%02ld:%02ld",(long)[selPartView selectedRowInComponent:2],(long)[selPartView selectedRowInComponent:3]];
    
    NSDate *current_startTime= [dateFormatter dateFromString:startTimeStr ];
    
    NSDate *current_endTime = [dateFormatter dateFromString:endTimeStr ];
    
    if ([current_startTime compare:current_endTime]==NSOrderedAscending) {
        NSString *times = [NSString stringWithFormat:@"%02ld:%02ld-%02ld:%02ld",(long)[selPartView selectedRowInComponent:0],(long)[selPartView selectedRowInComponent:1],(long)[selPartView selectedRowInComponent:2],(long)[selPartView selectedRowInComponent:3]];
        if (self.selectblock) {
            self.selectblock(times);
        }
        
        
        [self removeFromSuperview];
    }else{
    
        [HelpMsg showMessage:@"开始时间大于结束时间,请重新选择!" inView:[[[UIApplication sharedApplication]delegate]window]];
    
    }
    
}


#pragma mark  ------------UIPickerViewDelegate,UIPickerViewDataSource------------
//点击
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    //    selectLab.text=[NSString stringWithFormat:@"%@",[selectArr[row] valueForKey:@"partName"]];
    //    selectPart=row;
    //        threshold = "1.35,1.05";
    //        week = "1,2,3,4,5";
    //    NSString *threshold = _smartModeDic.threshold;
    NSLog(@"didselect:%@",selectArr[component][row]);
//    [currentPickArr replaceObjectAtIndex:component withObject:selectArr[component][row]];
    
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    //    return 1;
    return selectArr.count;
}

- (NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    NSArray *arr =  selectArr[component];
    return arr.count;
}

//-(CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component{
//    CGFloat width;
//    if (component == 0 ||component == 6 ){
//        width = ScreenWidth *0.25;
//    }else if (component == 1 || component == 2 ||component == 3||component == 4 ||component == 5) {
//        width = ScreenWidth *0.1;
//    }
//
//    return width;
//}

//自定义指定列的每行的视图.
- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    UILabel* pickerLabel = (UILabel*)view;
    
    if (!pickerLabel){
        pickerLabel = [[UILabel alloc] init];
        pickerLabel.adjustsFontSizeToFitWidth = YES;
        [pickerLabel setTextAlignment:NSTextAlignmentRight];
        [pickerLabel setBackgroundColor:[UIColor clearColor]];
        [pickerLabel setTextColor:[UIConfig colorFromHexRGB:@"0dc7a5"]];
        [pickerLabel setFont:[UIFont boldSystemFontOfSize:18]];
    }
    if(component == 0){
        [pickerLabel setTextAlignment:NSTextAlignmentRight];
    }else if(component == 1){
        [pickerLabel setTextAlignment:NSTextAlignmentCenter];
    }else if(component == 2){
        [pickerLabel setTextAlignment:NSTextAlignmentCenter];
    }else if(component == 3){
        [pickerLabel setTextAlignment:NSTextAlignmentLeft];
    }
    // Fill the label text here
    pickerLabel.text=[self pickerView:pickerView titleForRow:row forComponent:component];
    return pickerLabel;
}

//显示的标题,选项名字
- (NSString *) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    NSArray *arr =  selectArr[component];
    NSString *str = [NSString stringWithFormat:@"%@",arr[row]];
    //    NSLog(@"Str:%@",str);
    return str;
    //    return [NSString stringWithFormat:@"%@",[selectArr[row] valueForKey:@"partName"]];
}

@end
