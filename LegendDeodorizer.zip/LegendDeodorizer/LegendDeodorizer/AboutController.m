//
//  AboutController.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/30.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "AboutController.h"
#import "UINavigationController+FDFullscreenPopGesture.h"

@interface AboutController ()

@end

@implementation AboutController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    self.fd_prefersNavigationBarHidden = YES;
    [self createNaviView];
    [self creactMainView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    AppDelegate *app =(AppDelegate *)[UIApplication sharedApplication].delegate;
    app.root.tabBar.hidden = YES;
    app.root.button.hidden = YES;

}

#pragma mark-=====================UI====================
- (void)createNaviView{
    
    UIButton *leftBtn =[UIButton setButtonWithNomalImage:[UIImage imageNamed:@"arrow_back_black"] AndSelectImage:[UIImage imageNamed:@"arrow_back_black"] AndFrame:CGRectMake(0, STATUSBARHEIGHT, 60, NAVIBARHEIGHT)];
    
    leftBtn.imageEdgeInsets =UIEdgeInsetsMake(0, 0, 0, 0);
    [leftBtn addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:leftBtn];
    
    UILabel *label =[UILabel setLabelWith:@"关于传奇舟" AndFont:[UIFont systemFontOfSize:18] AndIsNumberOfLines:NO AndtextColor:[UIColor blackColor] AndFrame:CGRectMake((ScreenWidth-100)/2, STATUSBARHEIGHT, 100, NAVIBARHEIGHT) AndAlignment:NSTextAlignmentCenter];
    [self.view addSubview:label];
}

- (void)creactMainView{
    UIView *mainView = [[UIView alloc]initWithFrame:CGRectMake(0, STATUSBARHEIGHT+NAVIBARHEIGHT, ScreenWidth, ScreenHeight-(STATUSBARHEIGHT+NAVIBARHEIGHT))];
    mainView.backgroundColor = [UIConfig colorFromHexRGB:@"fbfbfb"];
    CALayer *lineLayer = [[CALayer alloc]init];
    lineLayer.frame = CGRectMake(0, 0, ScreenWidth, SINGLE_LINE_WIDTH);
    lineLayer.backgroundColor = KCOLOR(@"c7c7c7").CGColor;
    [mainView.layer addSublayer:lineLayer];
    [self.view addSubview:mainView];
    
    
    UIImageView *logoView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"about_logo"]];
    logoView.center = CGPointMake(mainView.center.x, 100);
    [mainView addSubview:logoView];
    
    
    NSString *str = @"  杭州传奇环境科技有限公司专业从事除臭净化技术研发,产品设计制造一体化的高新科技环保企业.\n  公司掌握多项全球领先的自主专利技术.同时与浙大生命科学研究院共同研发拥有国际顶尖的生物制品技术研发团队及软硬件研发团队,提供全方位除臭空气污染解决方案的科技创新型企业";

    CGRect RectS =[str boundingRectWithSize:CGSizeMake(ScreenWidth-80*NewBasicWidth,10000.0f) options:NSStringDrawingUsesLineFragmentOrigin attributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIFont systemFontOfSize:15.0],NSFontAttributeName, nil] context:nil];
    UILabel *textView = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(logoView.frame)+20, RectS.size.width, RectS.size.height)];
    textView.center = CGPointMake(mainView.center.x, CGRectGetMaxY(logoView.frame)+30*NewBasicHeight+RectS.size.height/2);
    textView.numberOfLines = 0;
    
    NSDictionary *attributeDict = [NSDictionary  dictionaryWithObjectsAndKeys:
                                   
                                   [UIFont systemFontOfSize:15.0],NSFontAttributeName,
                                   
                                   [UIConfig colorFromHexRGB:@"424242"],NSForegroundColorAttributeName,nil];
    
    NSMutableAttributedString *AttributedStr = [[NSMutableAttributedString alloc]initWithString:str  attributes:attributeDict];
    
    textView.attributedText = AttributedStr;
    
    [mainView addSubview:textView];
    
    
    UILabel *lab1 =[[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 20)];
    lab1.text = @"全国免费服务热线";
    lab1.font = [UIFont fontWithName:@"FZLTHK--GBK1-0" size:15];
    lab1.textColor = [UIConfig colorFromHexRGB:@"00aeac"];
    lab1.textAlignment = NSTextAlignmentCenter;
    lab1.center = CGPointMake(mainView.center.x, CGRectGetMaxY(textView.frame)+30*NewBasicHeight+lab1.frame.size.height/2);
    UILabel *lab2 =[[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 30)];
    lab2.text = @"400-155-0118";
    lab2.font = [UIFont fontWithName:@"DINCond-Black" size:30];
    lab2.textColor = [UIConfig colorFromHexRGB:@"00aeac"];
    lab2.textAlignment = NSTextAlignmentCenter;
    lab2.center = CGPointMake(mainView.center.x, CGRectGetMaxY(lab1.frame)+5*NewBasicHeight+lab2.frame.size.height/2);
    UIButton *callbutton =[[UIButton alloc]initWithFrame:CGRectMake(0, 0, 50, 50)];
//    callbutton.imageView.image = [UIImage imageNamed:@"call_icon"] ;
    [callbutton setImage:[UIImage imageNamed:@"call_icon"]  forState:UIControlStateNormal];
    callbutton.center = CGPointMake(mainView.center.x, CGRectGetMaxY(lab2.frame)+15*NewBasicHeight+callbutton.frame.size.height/2);
    [callbutton addTarget:self action:@selector(Calling) forControlEvents:UIControlEventTouchUpInside];
    [mainView addSubview:lab1];
    [mainView addSubview:lab2];
    [mainView addSubview:callbutton];



}

-(void)Calling{
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"tel://400-155-0118"]];
}

#pragma mark-=====================UI====================
-(void)buttonClick:(id)sender{

    [self.navigationController popViewControllerAnimated:YES];

}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
