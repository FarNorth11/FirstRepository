//
//  FeedBackCount.m
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/30.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "FeedBackCount.h"
#import "HETRequest+Private.h"
#import "HETDeviceGetBindRequest.h"
@implementation FeedBackCount
{
    
    NSString *_accessToken;
    
}
- (instancetype)initWithAccessToken:(NSString *)accessToken {
    NSAssert(accessToken, @"Parameter 'accessToken' should not be nil.");
    
    self = [super init];
    if (self) {
        _accessToken = accessToken;
        
    }
    
    return self;
    
}
- (YTKRequestMethod)requestMethod{
    
    return YTKRequestMethodGet;
}

-(BOOL)isHttpsType{
    
    return YES;
}

- (BOOL)needRefreshToken{
    
    return YES;
}

-(NSString *)requestUrl{
    
    return [@"/v1/app/cms" stringByAppendingString: @"/feedback/getCount"];
}

- (id)requestArgument{
    
    
    return @{
             @"accessToken":_accessToken,

             };
}

- (void)startWithSuccess:(HETHttpSuccessBlockNumberParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock{
    
    [super startWithSuccessBlockNumberParameter:successBlock failure:failureBlock];
}


@end
