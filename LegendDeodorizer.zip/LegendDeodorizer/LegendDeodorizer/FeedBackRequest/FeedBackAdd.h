//
//  FeedBackAdd.h
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/29.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "HETRequest.h"

@interface FeedBackAdd : HETRequest
- (instancetype)initWithAccessToken: (NSString *)accessToken contact: (NSString *)contact content:(NSString *)content productId:(NSNumber *)productId feedbackType:(NSNumber *)feedbackType;

- (void)startWithSuccess:(HETHttpSuccessBlockNumberParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock;
@end
