//
//  FeedBackCount.h
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/30.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "HETRequest.h"

@interface FeedBackCount : HETRequest
- (instancetype)initWithAccessToken:(NSString *)accessToken;
- (void)startWithSuccess:(HETHttpSuccessBlockNumberParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock;
@end
