//
//  FeedBackReply.m
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/29.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "FeedBackReply.h"
#import "HETRequest+Private.h"
#import "HETDeviceGetBindRequest.h"
@implementation FeedBackReply
{
    
    NSString *_accessToken;//访问凭证
    NSString *_replyContent;//回复内容
    NSNumber *_feedbackId;//意见反馈id
   
}
- (instancetype)initWithAccessToken: (NSString *)accessToken feedbackId: (NSNumber *)feedbackId replyContent:(NSString *)replyContent{
    NSAssert(accessToken, @"Parameter 'accessToken' should not be nil.");
    
    self = [super init];
    if (self) {
        _accessToken = accessToken;
        _replyContent =replyContent;
        _feedbackId = feedbackId;
    }
    
    return self;
    
}
- (YTKRequestMethod)requestMethod{
    
    return YTKRequestMethodGet;
}

-(BOOL)isHttpsType{
    
    return YES;
}

- (BOOL)needRefreshToken{
    
    return YES;
}

-(NSString *)requestUrl{
    
    return [@"/v1/app/cms" stringByAppendingString: @"/feedback/reply"];
}

- (id)requestArgument{
    
    
    return @{
             @"accessToken":_accessToken,
             @"feedbackId":_feedbackId,
             @"replyContent":_replyContent
             };
}

- (void)startWithSuccess:(HETHttpSuccessBlockNumberParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock{
    
    [super startWithSuccessBlockNumberParameter:successBlock failure:failureBlock];
}



@end
