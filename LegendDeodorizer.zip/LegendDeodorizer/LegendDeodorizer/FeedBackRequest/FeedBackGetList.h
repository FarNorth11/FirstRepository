//
//  FeedBackGetList.h
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/29.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "HETRequest.h"

@interface FeedBackGetList : HETRequest
- (instancetype)initWithAccessToken: (NSString *)accessToken pageIndex:(NSInteger )pageIndex pageRows:(NSInteger )pageRows;

- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock;
@end
