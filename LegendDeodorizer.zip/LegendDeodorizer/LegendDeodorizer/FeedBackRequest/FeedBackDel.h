//
//  FeedBackDel.h
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/29.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "HETRequest.h"

@interface FeedBackDel : HETRequest

- (instancetype)initWithAccessToken:(NSString *)accessToken feedbackId:(NSNumber *)feedbackId;
- (void)startWithSuccess:(HETHttpSuccessBlockNumberParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock;
@end
