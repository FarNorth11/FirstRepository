//
//  FeedBackDetail.m
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/29.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "FeedBackDetail.h"
#import "HETRequest+Private.h"
#import "HETDeviceGetBindRequest.h"

@implementation FeedBackDetail
{
    
    NSString *_accessToken;
    NSNumber *_feedbackId;

}
- (instancetype)initWithAccessToken:(NSString *)accessToken feedbackId:(NSNumber *)feedbackId{
    NSAssert(accessToken, @"Parameter 'accessToken' should not be nil.");
    
    self = [super init];
    if (self) {
        _accessToken = accessToken;
        _feedbackId =feedbackId;
  
    }
    
    return self;
    
}
- (YTKRequestMethod)requestMethod{
    
    return YTKRequestMethodGet;
}

-(BOOL)isHttpsType{
    
    return YES;
}

- (BOOL)needRefreshToken{
    
    return YES;
}

-(NSString *)requestUrl{
    
    return [@"/v1/app/cms" stringByAppendingString: @"/feedback/getList"];
}

- (id)requestArgument{
    
    
    return @{
             @"accessToken":_accessToken,
             @"feedbackId":_feedbackId,
            
             
             };
}

- (void)startWithSuccess:(HETHttpSuccessBlockArrayParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock {
    
    [super startWithSuccessBlockArrayParameter:successBlock failure:failureBlock];
}

@end
