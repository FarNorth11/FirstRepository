//
//  FeedBackDel.m
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/29.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "FeedBackDel.h"
#import "HETRequest+Private.h"
#import "HETDeviceGetBindRequest.h"
@implementation FeedBackDel
{
    
    NSString *_accessToken;
    NSNumber *_feedbackId;
    
}
- (instancetype)initWithAccessToken:(NSString *)accessToken feedbackId:(NSNumber *)feedbackId{
    NSAssert(accessToken, @"Parameter 'accessToken' should not be nil.");
    
    self = [super init];
    if (self) {
        _accessToken = accessToken;
        _feedbackId =feedbackId;
        
    }
    
    return self;
    
}
- (YTKRequestMethod)requestMethod{
    
    return YTKRequestMethodGet;
}

-(BOOL)isHttpsType{
    
    return YES;
}

- (BOOL)needRefreshToken{
    
    return YES;
}

-(NSString *)requestUrl{
    
    return [@"/v1/app/cms" stringByAppendingString: @"/feedback/del"];
}

- (id)requestArgument{
    
    
    return @{
             @"accessToken":_accessToken,
             @"feedbackId":_feedbackId,
             
             
             };
}

- (void)startWithSuccess:(HETHttpSuccessBlockNumberParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock{
    
    [super startWithSuccessBlockNumberParameter:successBlock failure:failureBlock];
}



@end
