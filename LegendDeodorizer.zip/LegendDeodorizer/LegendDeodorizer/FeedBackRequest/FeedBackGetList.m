//
//  FeedBackGetList.m
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/29.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "FeedBackGetList.h"
#import "HETRequest+Private.h"
#import "HETDeviceGetBindRequest.h"
@implementation FeedBackGetList
{
    
    NSString *_accessToken;
    NSInteger _pageIndex;
    NSInteger _pageRows;
}
- (instancetype)initWithAccessToken: (NSString *)accessToken pageIndex:(NSInteger )pageIndex pageRows:(NSInteger )pageRows{
    NSAssert(accessToken, @"Parameter 'accessToken' should not be nil.");
    
    self = [super init];
    if (self) {
        _accessToken = accessToken;
        _pageRows =pageRows;
        _pageIndex = pageIndex;
    }
    
    return self;
    
}
- (YTKRequestMethod)requestMethod{
    
    return YTKRequestMethodGet;
}

-(BOOL)isHttpsType{
    
    return YES;
}

- (BOOL)needRefreshToken{
    
    return YES;
}

-(NSString *)requestUrl{
    
    return [@"/v1/app/cms" stringByAppendingString: @"/feedback/getList"];
}

- (id)requestArgument{
    
    
    return @{
             @"accessToken":_accessToken,
             @"pageIndex":@(_pageIndex),
             @"pageRows":@(_pageRows)
             
             };
}

- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock {
    
    [super startWithSuccessBlockDictionaryParameter:successBlock
                                            failure:failureBlock];
}


@end
