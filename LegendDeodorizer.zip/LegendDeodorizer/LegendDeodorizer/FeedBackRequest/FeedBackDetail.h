//
//  FeedBackDetail.h
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/29.
//  Copyright © 2016年 starlueng. All rights reserved.
//
//3、意见反馈详情
#import "HETRequest.h"

@interface FeedBackDetail : HETRequest

- (instancetype)initWithAccessToken:(NSString *)accessToken feedbackId:(NSNumber *)feedbackId;

- (void)startWithSuccess:(HETHttpSuccessBlockArrayParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock;
@end
