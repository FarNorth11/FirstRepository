//
//  HotRequest.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/14.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "HotRequest.h"
#import "FeedBackGetList.h"
#import "FeedBackAdd.h"
#import "FeedBackDetail.h"
#import "FeedBackReplylist.h"
#import "FeedBackReply.h"
#import "FeedBackDel.h"
#import "FeedBackCount.h"



@implementation HotRequest



+ (instancetype)shareInstance{
    
    static HotRequest * requset = nil;
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        requset =[[HotRequest alloc]init];
    });
    return requset;
}


@end



@implementation HotRequest (FeedBack)
//1、意见反馈列表
- (void)getFeedBackListWithAccessToken: (NSString *)accessToken pageIndex:(NSInteger )pageIndex pageRows:(NSInteger )pageRows AndSuccess:(sendBlock)success AndFaliBlock:(sendBlock)faliBlock{
    
    FeedBackGetList * list = [[FeedBackGetList alloc]initWithAccessToken:accessToken pageIndex:pageIndex pageRows:pageRows];
    [list startWithSuccess:^(NSDictionary *dictValue) {
        if (success) {
            success(dictValue);
        }
    } failure:^(NSError *error, NSInteger statusCode) {
        if (error) {
            faliBlock(error);
        }
    }];
}
//2、意见反馈 添加
- (void)addFeedBackWithAccessToken: (NSString *)accessToken contact: (NSString *)contact content:(NSString *)content productId:(NSNumber *)productId feedbackType:(NSNumber *)feedbackType AndSuccess:(sendBlock)success AndFaliBlock:(sendBlock)faliBlock{
    
    FeedBackAdd * feed = [[FeedBackAdd alloc]initWithAccessToken:accessToken contact:contact content:content productId:productId feedbackType:feedbackType];
    [feed startWithSuccess:^(NSNumber *numberValue) {
        if (success) {
            success(numberValue);
        }
    } failure:^(NSError *error, NSInteger statusCode) {
        if (error) {
            faliBlock(error);
        }
    }];
}
//3、意见反馈详情
- (void)getFeedBackDetailWithAccessToken:(NSString *)accessToken feedbackId:(NSNumber *)feedbackId AndSuccess:(sendBlock)success AndFaliBlock:(sendBlock)faliBlock{
    FeedBackDetail * feed = [[FeedBackDetail alloc]initWithAccessToken:accessToken feedbackId:feedbackId];
    [feed startWithSuccess:^(NSArray *arrayValue) {
        if (success) {
            success(arrayValue);
        }
    } failure:^(NSError *error, NSInteger statusCode) {
        if (error) {
            faliBlock(error);
        }
    }];
}
//4、意见反馈 回复列表
- (void)getFeedBackReplyListWithAccessToken: (NSString *)accessToken feedbackId:(NSNumber *)feedbackId pageIndex:(NSInteger )pageIndex pageRows:(NSInteger )pageRows AndSuccess:(sendBlock)success AndFaliBlock:(sendBlock)faliBlock{
    
    FeedBackReplylist * feed = [[FeedBackReplylist alloc]initWithAccessToken:accessToken feedbackId:feedbackId pageIndex:pageIndex pageRows:pageRows];
    [feed startWithSuccess:^(NSDictionary *dictValue) {
        if (success) {
            success(dictValue);
        }
    } failure:^(NSError *error, NSInteger statusCode) {
        if (error) {
            faliBlock(error);
        }
    }];
}
//5、意见反馈 回复
- (void)replyFeedBackWithAccessToken: (NSString *)accessToken feedbackId: (NSNumber *)feedbackId replyContent:(NSString *)replyContent AndSuccess:(sendBlock)success AndFaliBlock:(sendBlock)faliBlock{
    
    FeedBackReply *feed = [[FeedBackReply alloc]initWithAccessToken:accessToken feedbackId:feedbackId replyContent:replyContent];
    [feed startWithSuccess:^(NSNumber *numberValue) {
        if (success) {
            success(numberValue);
        }
    } failure:^(NSError *error, NSInteger statusCode) {
        if (error) {
            faliBlock(error);
        }
    }];
}
//6、意见反馈 删除
- (void)delFeedBackWithAccessToken:(NSString *)accessToken feedbackId:(NSNumber *)feedbackId AndSuccess:(sendBlock)success  AndFaliBlock:(sendBlock)faliBlock{
    
    FeedBackDel *feed = [[FeedBackDel alloc]initWithAccessToken:accessToken feedbackId:feedbackId];
    [feed startWithSuccess:^(NSNumber *numberValue) {
        if (success) {
            success(numberValue);
        }
    } failure:^(NSError *error, NSInteger statusCode) {
        if (error) {
            faliBlock(error);
        }
    }];
}
- (void)isExistFeedBackWithAccessToken:(NSString *)accessToken  AndSuccess:(sendBlock)success AndFaliBlock:(sendBlock)faliBlock{
    
    FeedBackCount *feed = [[FeedBackCount alloc]initWithAccessToken:accessToken];
    [feed startWithSuccess:^(NSNumber *numberValue) {
        if (success) {
            success(numberValue);
        }
    } failure:^(NSError *error, NSInteger statusCode) {
        if (error) {
            faliBlock(error);
        }
    }];
}
@end
