//
//  HotRequest.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/14.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface HotRequest : NSObject


+ (instancetype)shareInstance;


@end

#pragma mark-===================意见反馈====================
@interface HotRequest (FeedBack)
//1、意见反馈列表
- (void)getFeedBackListWithAccessToken: (NSString *)accessToken pageIndex:(NSInteger )pageIndex pageRows:(NSInteger )pageRows AndSuccess:(sendBlock)success AndFaliBlock:(sendBlock)faliBlock;
//2、意见反馈 添加
- (void)addFeedBackWithAccessToken: (NSString *)accessToken contact: (NSString *)contact content:(NSString *)content productId:(NSNumber *)productId feedbackType:(NSNumber *)feedbackType AndSuccess:(sendBlock)success AndFaliBlock:(sendBlock)faliBlock;
//3、意见反馈详情
- (void)getFeedBackDetailWithAccessToken:(NSString *)accessToken feedbackId:(NSNumber *)feedbackId AndSuccess:(sendBlock)success AndFaliBlock:(sendBlock)faliBlock;
//4、意见反馈 回复列表
- (void)getFeedBackReplyListWithAccessToken: (NSString *)accessToken feedbackId:(NSNumber *)feedbackId pageIndex:(NSInteger )pageIndex pageRows:(NSInteger )pageRows AndSuccess:(sendBlock)success AndFaliBlock:(sendBlock)faliBlock;
//5、意见反馈 回复
- (void)replyFeedBackWithAccessToken: (NSString *)accessToken feedbackId: (NSNumber *)feedbackId replyContent:(NSString *)replyContent AndSuccess:(sendBlock)success AndFaliBlock:(sendBlock)faliBlock;
//6、意见反馈 删除
- (void)delFeedBackWithAccessToken:(NSString *)accessToken feedbackId:(NSNumber *)feedbackId AndSuccess:(sendBlock)success AndFaliBlock:(sendBlock)faliBlock;
//7、用户反馈记录条数
- (void)isExistFeedBackWithAccessToken:(NSString *)accessToken  AndSuccess:(sendBlock)success AndFaliBlock:(sendBlock)faliBlock;
@end
