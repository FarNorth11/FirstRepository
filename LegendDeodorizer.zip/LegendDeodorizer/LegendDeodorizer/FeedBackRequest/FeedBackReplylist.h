//
//  FeedBackReplylist.h
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/29.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "HETRequest.h"

@interface FeedBackReplylist : HETRequest
- (instancetype)initWithAccessToken: (NSString *)accessToken feedbackId:(NSNumber *)feedbackId pageIndex:(NSInteger )pageIndex pageRows:(NSInteger )pageRows;

- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock;
@end
