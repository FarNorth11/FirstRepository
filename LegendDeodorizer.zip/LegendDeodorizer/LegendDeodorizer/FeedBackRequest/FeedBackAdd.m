//
//  FeedBackAdd.m
//  CSuperAppliances
//
//  Created by Starlueng on 2016/12/29.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "FeedBackAdd.h"
#import "HETRequest+Private.h"
#import "HETDeviceGetBindRequest.h"
@implementation FeedBackAdd
{
    
    NSString *_accessToken;//访问凭证
    NSString *_contact;//联系方式
    NSString *_content;//反馈内容
    NSNumber *_productId;//产品id
    NSNumber *_feedbackType;//问题类型（1-APP问题，2-硬件设备，3-配网相关，4-意见建议 ，5 -其它）
}
- (instancetype)initWithAccessToken: (NSString *)accessToken contact: (NSString *)contact content:(NSString *)content productId:(NSNumber *)productId feedbackType:(NSNumber *)feedbackType{
    NSAssert(accessToken, @"Parameter 'accessToken' should not be nil.");
    
    self = [super init];
    if (self) {
        _accessToken = accessToken;
        _contact =contact;
        _content = content;
        _productId = productId;
        _feedbackType = feedbackType;
    }
    
    return self;
    
}
- (YTKRequestMethod)requestMethod{
    
    return YTKRequestMethodGet;
}

-(BOOL)isHttpsType{
    
    return YES;
}

- (BOOL)needRefreshToken{
    
    return YES;
}

-(NSString *)requestUrl{
    
    return [@"/v1/app/cms" stringByAppendingString: @"/feedback/addFeedback"];
}

- (id)requestArgument{
    if (_productId) {
        return @{
                 @"accessToken":_accessToken,
                 @"contact":_contact,
                 @"content":_content,
                 @"productId":_productId,
                 @"feedbackType":_feedbackType
                 };

    }else{
        return @{
                 @"accessToken":_accessToken,
                 @"contact":_contact,
                 @"content":_content,
      
                 @"feedbackType":_feedbackType
                 };

    }
    
}

- (void)startWithSuccess:(HETHttpSuccessBlockNumberParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock{
    
    [super startWithSuccessBlockNumberParameter:successBlock failure:failureBlock];
}


@end
