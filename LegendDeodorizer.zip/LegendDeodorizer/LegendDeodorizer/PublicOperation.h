//
//  PublicOperation.h
//  CSuperAppliances
//
//  Created by starlueng on 16/8/3.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef void (^loginBlock)();
typedef void (^bellBlock)(id);
typedef void (^VersionBlock)(id);
typedef void (^unBindBlock) (id);
@interface PublicOperation : NSObject

@property (copy,nonatomic) unBindBlock bindBlock;

+ (instancetype)shareInstance;

- (void)publicSet;//页面设置

- (BOOL)isExistNewVersion:(VersionBlock)block;//app是否存在新版本

- (void)login;//登录后返回首页

- (void)loginAndPopWith:(loginBlock)success;//登录后返回当前页面

- (void)bind;//绑定


-(void)unbind:(NSString*)deviceId;//解绑

@end
