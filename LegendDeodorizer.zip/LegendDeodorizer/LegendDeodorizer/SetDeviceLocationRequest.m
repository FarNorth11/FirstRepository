//
//  SetDeviceLocationRequest.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/5.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "SetDeviceLocationRequest.h"
#import "HETRequest+Private.h"

@implementation SetDeviceLocationRequest{
    NSString  *_accessToken;
    NSString *_mac;
    NSString *_identify;
    NSNumber *_deviceLongitude;
    NSNumber *_deviceLatitude;
    NSString *_deviceAddress;
}
-(instancetype)initWithAccessToken:(NSString *)accessToken identify:(NSString *)identify mac:(NSString *)mac deviceLongitude:(NSNumber *)deviceLongitude deviceLatitude:(NSNumber *)deviceLatitude deviceAddress:(NSString *)deviceAddress{

    self = [super init];
    if (self) {
        _accessToken = accessToken;
        _identify = identify;
        _deviceLongitude = deviceLongitude;
        _deviceLatitude = deviceLatitude;
        _mac = mac;
        _deviceAddress = deviceAddress;
        
    }
    
    return self;


}
- (YTKRequestMethod)requestMethod{
    
    return YTKRequestMethodGet;
    
}

-(BOOL)isHttpsType{
    
    return YES;
}

-(NSString *)requestUrl{
    
    return [@"/v1/app/customization/legend" stringByAppendingString: @"/setDeviceLocation"];
    
}

- (id)requestArgument{
    
    return @{
             @"accessToken":_accessToken,
             @"identify" :_identify,
             @"mac" : _mac,
             @"deviceAddress" : _deviceAddress,
             @"deviceLongitude" : _deviceLongitude,
             @"deviceLatitude" : _deviceLatitude
             };
    
}

- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock{
    [super startWithSuccessBlockDictionaryParameter:successBlock failure:failureBlock];
}


@end
