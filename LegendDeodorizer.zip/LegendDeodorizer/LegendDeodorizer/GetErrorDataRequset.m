//
//  GetErrorDataRequset.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/18.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "GetErrorDataRequset.h"
#import "HETRequest+Private.h"

@implementation GetErrorDataRequset{
    NSString  *_accessToken;
    NSString  * _deviceId;
}

-(instancetype)initWithAccessToken:(NSString *)accessToken deviceId:(NSString *)deviceId{
    self = [super init];
    if (self) {
        _accessToken = accessToken;
        _deviceId  = deviceId;
        
    }
    
    return self;
    
    
    
}
- (YTKRequestMethod)requestMethod{
    
    return YTKRequestMethodGet;
    
}

-(BOOL)isHttpsType{
    
    return YES;
}

-(NSString *)requestUrl{
    
    return [@"/v1/device/data" stringByAppendingString: @"/getErrorData"];
    
}

- (id)requestArgument{
    

        return @{
                 @"accessToken":_accessToken,
                 @"deviceId" :_deviceId,
                 
                 };

    
    
}

- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock{
    [super startWithSuccessBlockDictionaryParameter:successBlock failure:failureBlock];
}


@end
