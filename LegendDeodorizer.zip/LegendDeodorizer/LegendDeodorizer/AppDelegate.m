//
//  AppDelegate.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/27.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "AppDelegate.h"
#import "HETNetworkConfig.h"
#import "BaseAlert.h"
#import "WechatProxy.h"
#import "PublicOperation.h"
#import "JSObjection.h"
#import "HETPublicUIConfig.h"
#import "HETLoginProtocols.h"
#define WX_APP_KEY      @"wxc55a828b36974454"
#define WX_APP_SECRET   @"6c2e9c16e4adfe199f4bfd88e92ad9c1"


@interface AppDelegate ()

@end

@implementation AppDelegate

#if 0
static const NSString *kHostName = @"https://200.200.200.50";// //@"https://dp.clife.net";//@"https://200.200.200.50";/*@"http://192.148.47.1";*//*@"https://61.141.158.190:1443";*/
#else
static const NSString *kHostName =@"https://api.clife.cn"; // @"https://test.api.clife.cn"; //  // //@"https://api.clife.cn";


#endif

static NSString *const CSALoginNotification           = @"kNotificationLogin";

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    _root =[[RootTabBarViewController alloc]init];
    self.window.rootViewController =_root;
    
    HETNetworkConfig *config = [HETNetworkConfig sharedInstance];
    config.baseUrl = (NSString *)kHostName;
    config.appSecret = @"3962b4ce51d248a7b66feae4ae5c072f";
    HETURLArgumentFilter *urlFilter =
    [HETURLArgumentFilter filterWithArguments: @{ @"appId": @(ServerAPPID)}];
    [config addUrlFilter:urlFilter];
    [self configShareSDK];
    /**
     *  异地登录监听
     */
    [self startObserveLoginNotification];
    [[NSNotificationCenter defaultCenter] addObserver: self
                                             selector: @selector(startObserveLoginNotification)
                                                 name: @"addLoginNotification"
                                               object: nil];
    self.window.backgroundColor =[UIColor whiteColor];
    [self.window makeKeyAndVisible];
    
    return YES;
}


#pragma mark - 配置第三方登录和分享
#pragma mark - 配置第三方登录和分享
- (void)configShareSDK
{
    [[Diplomat sharedInstance] registerWithConfigurations:
     @{
       kDiplomatTypeWechat: @{
               kDiplomatAppIdKey: WX_APP_KEY,
               kDiplomatAppSecretKey: WX_APP_SECRET
               }
     
       }];
}


#pragma mark - Login Observe Notification
- (void)startObserveLoginNotification{
    
    [self stopObserveLoginNotification];
    
    // accessToken失效  异地登陆
    [[NSNotificationCenter defaultCenter] addObserver: self
                                             selector: @selector(presentLoginViewController:)
                                                 name: CSALoginNotification
                                               object: nil];
}

- (void)stopObserveLoginNotification{
    
    [[NSNotificationCenter defaultCenter] removeObserver: self
                                                    name: CSALoginNotification
                                                  object:nil];
}

#pragma mark - Notification Methods
- (void)presentLoginViewController: (NSNotification *)notification{
    for (UIView *view in self.window.subviews) {
        if ([view isKindOfClass:[MBProgressHUD class]]) {
            [view removeFromSuperview];
        }
    }
    
    [self stopObserveLoginNotification];
    HETUserInfoRecord *preferences = [HETUserInfo userInfo];
    preferences.isLogin = NO;
    NSDictionary *loginStatusDic = notification.userInfo;
    if ([[loginStatusDic objectForKey:@"loginStatus"] isEqualToString:@"loginRepeat"]) {
        
        NSString *msgStr = [loginStatusDic objectForKey:@"error"];
        NSLog(@"--%@",msgStr);
        NSMutableArray *msgArr = [[NSMutableArray alloc]initWithArray:[msgStr componentsSeparatedByString:@"#"]];
        if (msgArr.count == 3) {
            NSString *utcTimeStr = msgArr[1];
            NSDateFormatter * formatter = [[NSDateFormatter alloc] init];
            [formatter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0]];
            [formatter setDateFormat:@"HH:mm"];
            NSDate * utcDate = [formatter dateFromString:utcTimeStr];
            NSDate * nowDate = [self getNowDateFromatAnDate:utcDate];
            NSString *nowStr = [formatter stringFromDate:nowDate];
            [msgArr replaceObjectAtIndex:1 withObject:nowStr];
        }
        
        NSString *msg = [msgArr componentsJoinedByString:@""];
//        [JPUSHService setTags:nil alias: @"" fetchCompletionHandle:^(int iResCode, NSSet *iTags, NSString *iAlias) {
//            NSLog(@"iTags--%@ iAlias----%@",iTags,iAlias);
//        }];
        __weak typeof(self)Wself = self;
        [[BaseAlert shareInstance]alertWithAlertStyle:AlertStyleAlert title:nil message:msg cancelBtnTitle:NSLocalizedString(@"确定", @"") buttonList:nil AndSelectButtonAction:^(NSNumber *num) {
            
            if (Wself.root.selectedIndex != 0) {
                UINavigationController *nav = (UINavigationController *)self.root.selectedViewController;
                [nav popToRootViewControllerAnimated:NO];
            }
            Wself.root.selectedIndex = 0;
            UINavigationController *nav = (UINavigationController *)self.root.selectedViewController;
            UIViewController *Vc =[nav.viewControllers firstObject];
            
            /**
             *  解除推送绑定
             */
//            [[HotRequest shareInstance]unbindNotificationWith:[HETUserInfo userInfo].accessToken deviceId:[CSAppUserSettings shareInstance].registrationID  Success:^(NSNumber *code) {
//                NSLog(@"解绑成功");
//                
//            } AndFail:^(NSError *error) {
//                NSLog(@"解绑失败%@",error);
//            }];
            
//            [CSAppUserSettings shareInstance].userRecord = [[HETUserInfo userInfo]userAccount];
//            [[HETUserDefaultsPreference sharedInstance] clearData];
            [HETUserInfo logout];
            [HETUserInfo userInfo].accessToken = @"";
            /**
             *  设备状态改变修改（登录登出，新添设备修改此项）
             *
             */
//            [CSAppUserSettings shareInstance].userAcountChange = YES;
            
            
            if (![nav.visibleViewController isEqual:Vc]) {
                [nav popToViewController:Vc animated:YES];
                
            }else{
//                [[HotRequest shareInstance] CheckLogin];
                PublicOperation  *publicOp = [PublicOperation shareInstance];
                [publicOp publicSet];
                if ([HETUserInfo userInfo].isLogin) {
                    
                    [publicOp bind];
                    
                }else{
                    typeof(self) __weak weakSelf = self;
                    [publicOp loginAndPopWith:^{
                        [weakSelf startObserveLoginNotification];
                    }];
                    


                    
                }

            }
        }];
    }
}


- (NSDate *)getNowDateFromatAnDate:(NSDate *)anyDate
{
    //设置源日期时区
    NSTimeZone* sourceTimeZone = [NSTimeZone timeZoneWithAbbreviation:@"UTC"];//或GMT
    //设置转换后的目标日期时区
    NSTimeZone* destinationTimeZone = [NSTimeZone localTimeZone];
    //得到源日期与世界标准时间的偏移量
    NSInteger sourceGMTOffset = [sourceTimeZone secondsFromGMTForDate:anyDate];
    //目标日期与本地时区的偏移量
    NSInteger destinationGMTOffset = [destinationTimeZone secondsFromGMTForDate:anyDate];
    //得到时间偏移量的差值
    NSTimeInterval interval = destinationGMTOffset - sourceGMTOffset;
    //转为现在时间
    NSDate* destinationDateNow = [[NSDate alloc] initWithTimeInterval:interval sinceDate:anyDate];
    return destinationDateNow;
}

- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<NSString *,id> *)options{
    
    
    if ([[Diplomat sharedInstance]handleOpenURL:url]){
        return YES;
    }
    
    return YES;
}

-(BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url{
    if ([[Diplomat sharedInstance]handleOpenURL:url]){
        return YES;
    }
    return YES;
}



-(BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation{
    if ([[Diplomat sharedInstance]handleOpenURL:url]){
        return YES;
    }
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end
