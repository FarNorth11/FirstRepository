//
//  DeviceBtnCell.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/29.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "DeviceBtnCell.h"

@implementation DeviceBtnCell



- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}




- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        _BtnImageView = [[UIImageView alloc]init];
        [self.contentView addSubview:_BtnImageView];
        
        _midLabel =[[UILabel alloc]init];
        _midLabel.font =[UIFont systemFontOfSize:16];
        _midLabel.textColor =[UIConfig colorFromHexRGB:@"323232"];
        _midLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_midLabel];
        
        [self createUI];
    }

    return self;
}


- (void)createUI{
    
    _BtnImageView.frame =CGRectMake((self.bounds.size.width-60*NewBasicHeight)/2,(self.bounds.size.height-60*NewBasicHeight)/2 , 60 *NewBasicHeight, 60*NewBasicHeight);
    
    _BtnImageView.contentMode = UIViewContentModeScaleAspectFit;

    
    _midLabel.frame =CGRectMake(0,CGRectGetMaxY(_BtnImageView.frame)+5*NewBasicHeight, self.bounds.size.width, 18);
    
    
}


@end
