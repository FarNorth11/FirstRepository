//
//  DeviceDetailController.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/28.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "DeviceDetailController.h"
#import "UINavigationController+FDFullscreenPopGesture.h"
#import "GetDeviceInfoRequest.h"
#import "NSDictionary+SAMAdditions.h"
#import "DeviceDetailCell.h"
#import "DeviceDetailCell_specific.h"
#import "Edit_DeviceDetailController.h"
#import "DeviceDetailModel.h"
#import "DeviceGroupVC.h"
#import "CodeScanViewController.h"
#import "SetDeviceLocationRequest.h"
#import "PublicOperation.h"
#import "SelectMapLocationVC.h"

static const NSInteger backTag           =5;//右侧按钮tag
static const NSInteger moreTag           =2;//右侧按钮tag

@interface DeviceDetailController (){
    UITableView *mainTableView;
    DeviceDetailModel *deviceDetailModel;
//    NSString * deviceAddress;
//    NSString * deviceId ;
//    NSString * deviceName ;
//    NSString * gid ;
//    NSString * groupName ;
//    NSString * headName;
//    NSString * headPhone ;
//    NSString * intro;

}

@end

@implementation DeviceDetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    self.fd_prefersNavigationBarHidden = YES;
    [self createNavUI];
    [self createTableView];
    
    [[NSNotificationCenter defaultCenter]  addObserver:self selector:@selector (scanQuickMark) name:@"scanQuickMark" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(editLocation:) name:@"editLocation"object:nil];

    
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self getDeviceInfo];
}


-(void)dealloc{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"scanQuickMark" object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:@"editLocation" name:nil object:self];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}
#pragma mark ===================Request===================
//获取设备的详情参数
-(void)getDeviceInfo{
    GetDeviceInfoRequest *getDeviceInfo = [[GetDeviceInfoRequest alloc]initWithAccessToken:[HETUserInfo userInfo].accessToken mac:self.device.macAddress];
    [getDeviceInfo startWithSuccess:^(NSDictionary *dictValue) {
        NSLog(@"dictValue:%@",dictValue);
        deviceDetailModel = [[DeviceDetailModel alloc]initWithData:dictValue];
        deviceDetailModel.macAddress = _device.macAddress;
        
//        deviceAddress = [dictValue sam_safeObjectForKey:@"deviceAddress"];
//        deviceId = [dictValue sam_safeObjectForKey:@"deviceId"];
//        deviceName = [dictValue sam_safeObjectForKey:@"deviceName"];
//        gid = [dictValue sam_safeObjectForKey:@"gid"];
//        groupName = [dictValue sam_safeObjectForKey:@"groupName"];
//        headName = [dictValue sam_safeObjectForKey:@"headName"];
//        headPhone = [dictValue sam_safeObjectForKey:@"headPhone"];
//        intro = [dictValue sam_safeObjectForKey:@"intro"];
        [mainTableView reloadData];
        
    } failure:^(NSError *error, NSInteger statusCode) {
        if (error.code == 0) {
            [HelpMsg showMessage:@"当前网络不可用" inView:[[UIApplication sharedApplication].delegate window]];
        }
        
    }];
    
}


//修改设备定位

-(void) setDeviceLocation:(NSString *)identify  deviceLongitude:(NSNumber *)deviceLongitude deviceLatitude:(NSNumber *)deviceLatitude deviceAddress:(NSString *)deviceAddress{
    SetDeviceLocationRequest *setDeviceLocation = [[SetDeviceLocationRequest alloc]initWithAccessToken:[HETUserInfo userInfo].accessToken identify:identify mac:self.device.macAddress deviceLongitude:deviceLongitude deviceLatitude:deviceLatitude deviceAddress:deviceAddress];
    [setDeviceLocation startWithSuccess:^(NSDictionary *dictValue) {
        [HelpMsg showMessage:@"设置成功" inView:[[[UIApplication sharedApplication]delegate]window]];
        
    } failure:^(NSError *error, NSInteger statusCode) {
        [HelpMsg showMessage:@"设置失败" inView:[[[UIApplication sharedApplication]delegate]window]];
        if (error.code == 0) {
            [HelpMsg showMessage:@"当前网络不可用" inView:[[UIApplication sharedApplication].delegate window]];
        }
    }];

}
#pragma mark ===================UI===================
-(void)createNavUI{
    
    UIView *navView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, NAVIBARHEIGHT+STATUSBARHEIGHT)];
    navView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:navView];
    
    CALayer *lineLayer = [[CALayer alloc]init];
    lineLayer.frame = CGRectMake(0, NAVIBARHEIGHT+STATUSBARHEIGHT-1, ScreenWidth, SINGLE_LINE_WIDTH);
    lineLayer.backgroundColor = KCOLOR(@"c7c7c7").CGColor;
    [navView.layer addSublayer:lineLayer];
    
    UIButton *leftBtn =[UIButton setButtonWithNomalImage:[UIImage imageNamed:@"arrow_back_black"] AndSelectImage:[UIImage imageNamed:@"arrow_back_black"] AndFrame:CGRectMake(0, STATUSBARHEIGHT, 60, NAVIBARHEIGHT)];
    leftBtn.imageEdgeInsets =UIEdgeInsetsMake(0, 0, 0, 0);
    leftBtn.tag = backTag;
    [leftBtn addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
    [navView addSubview:leftBtn];
    
    UILabel *label =[UILabel setLabelWith:@"设备详情" AndFont:[UIFont systemFontOfSize:18] AndIsNumberOfLines:NO AndtextColor:[UIColor blackColor] AndFrame:CGRectMake((ScreenWidth-100)/2, STATUSBARHEIGHT, 100, NAVIBARHEIGHT) AndAlignment:NSTextAlignmentCenter];
    [navView addSubview:label];
    
    
    UIButton *rightBtn =[UIButton setButtonWith:@"编辑" AndNomalColor:[UIColor blackColor]  AndSelectColor:[UIColor blackColor]  AndFont:KFONT(16) AndFrame:CGRectMake(ScreenWidth-60, 20, 60, 44)];
    rightBtn.tag = moreTag;
    [navView addSubview:rightBtn];
    
    [rightBtn addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
//    self.tableView.frame = CGRectMake(0, NAVIBARHEIGHT+STATUSBARHEIGHT, ScreenWidth, ScreenHeight-NAVIBARHEIGHT-STATUSBARHEIGHT);
    

}

- (void)createTableView{
    mainTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, NAVIBARHEIGHT+STATUSBARHEIGHT, ScreenWidth, ScreenHeight - NAVIBARHEIGHT-STATUSBARHEIGHT) style:UITableViewStyleGrouped];
    mainTableView.delegate =self;
    mainTableView.dataSource =self;
    
//    UIView *footView =[[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, SINGLE_LINE_WIDTH)];
//    footView.backgroundColor =[UIConfig colorFromHexRGB:@"c7c8cc"];
    mainTableView.tableFooterView = [self createFootView];
    [self.view addSubview:mainTableView];
}
- (UIView *)createFootView{
    UIView *footView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 90) ];
    footView.backgroundColor = [UIColor clearColor];
//    footView.backgroundColor = [UIConfig colorFromHexRGB:@"fbfbfb"];
//    UILabel *textLab = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 50, 150)];
//    textLab.text = @"解除绑定";
//    textLab.textColor = [UIColor redColor];
//    textLab.font = [UIFont systemFontOfSize:15];
//    textLab.center = footView.center;
//    [footView addSubview:textLab];
    
    UIButton *unBindBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 20, ScreenWidth, 50)];
    [unBindBtn setBackgroundColor:WHITECOLOR];
    [unBindBtn setTitle:@"解除绑定" forState:UIControlStateNormal];
    [unBindBtn addTarget:self action:@selector(unBindRequest:) forControlEvents:UIControlEventTouchUpInside];
    [unBindBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [footView addSubview:unBindBtn];
    return footView;

}


#pragma mark ===================action===================


- (void)editLocation:(NSNotification *)text{
    //(NSString * identify,NSString  *currentLoactionStr,NSNumber *deviceLongitude,NSNumber *deviceLatitude)
    
    //    scanVC.block=^(NSString * identify,NSString  *currentLoactionStr,NSNumber *deviceLongitude,NSNumber *deviceLatitude){
    //        [self setDeviceLocation:identify deviceLongitude:deviceLongitude deviceLatitude:deviceLatitude deviceAddress:currentLoactionStr];
    //    };
    
    NSString *identify = text.userInfo[@"identify"];
    NSString *currentLoactionStr = text.userInfo[@"currentLoactionStr"];
    NSNumber *deviceLongitude = text.userInfo[@"deviceLongitude"];
    NSNumber *deviceLatitude = text.userInfo[@"deviceLatitude"];
    
    
    [self setDeviceLocation:identify deviceLongitude:deviceLongitude deviceLatitude:deviceLatitude deviceAddress:currentLoactionStr];
    
    NSLog(@"－－－－－接收到通知------");
    
    
    
}

-(void)unBindRequest:(id)sender{
    
    
    UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:NSLocalizedString(@"解除当前绑定设备", nil) message:NSLocalizedString(@"您确定要解除绑定吗?", nil) delegate:self cancelButtonTitle:NSLocalizedString(@"取消", nil) otherButtonTitles:NSLocalizedString(@"解除绑定", nil), nil];
    alertView.tag = 105;
    [alertView show];
    
    

}

#pragma mark UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag==105&&buttonIndex==1)
    {
        
        
        PublicOperation  *publicOp = [PublicOperation shareInstance];
        
        [publicOp unbind:self.device.deviceId];
        publicOp.bindBlock = ^(NSString *ss){
            
            
            [self.navigationController popToRootViewControllerAnimated:YES];
//            self.navigationController popToViewController:<#(nonnull UIViewController *)#> animated:YES
        };

//        HETDeviceUnbindRequest *unbindRequest = [[HETDeviceUnbindRequest alloc] initWithAccessToken:[HETUserInfo userInfo].accessToken deviceId:currentDeviceModel.deviceId];
//        [unbindRequest startWithSuccess:^{
//            [HelpMsg showAlert:@"解绑成功" msg:nil duration:1.0];
//            MBProgressHUD *hud = [HelpMsg showCustomHudtitleTowindow:nil];
//            [self getDeviceInfo:^{
//                [hud hide:YES];
//            } fail:^{
//                [hud hide:YES];
//            }];
//        } failure:^(NSError *error, NSInteger statusCode) {
//            NSLog(@"%@",error);
//        }];
        
    }
}

-(void)buttonClick:(id)sender{
    
    if ([sender isKindOfClass:[UIButton class]]) {
        UIButton *button = (UIButton *)sender;
        switch (button.tag) {
            case moreTag:
            {
                Edit_DeviceDetailController *editVC = [[Edit_DeviceDetailController alloc] init];
                editVC.deviceDetailModel = deviceDetailModel;
//                [self presentViewController:editVC animated:YES completion:nil];
                [self.navigationController pushViewController:editVC animated:YES];
//                DeviceDetailController *deviceDetail = [[DeviceDetailController alloc]init];
//                //                [self.navigationController pushViewController:deviceDetail animated:YES];
//                [self presentViewController:deviceDetail animated:YES completion:nil];
//                
            }
                break;
            case backTag:
            {
                //                AppDelegate *app =(AppDelegate *)[UIApplication sharedApplication].delegate;
                //                app.root.tabBar.hidden = NO;
                //                app.root.button.hidden = NO;
                //                app.root.selectedIndex =0;
//                [self dismissViewControllerAnimated:YES completion:nil];
                [self.navigationController popViewControllerAnimated:YES];
                self.titleStringBlock(deviceDetailModel.deviceName);
            }
                break;
                
            default:{
                
            }
                break;
                
        }
        
    }

    
    
}

-(void)scanQuickMark{

    CodeScanViewController *scanVC = [[CodeScanViewController alloc]init];
    [self.navigationController pushViewController:scanVC animated:YES];
    
//    SelectMapLocationVC *vc = [[SelectMapLocationVC alloc]init];
//    [self.navigationController pushViewController:vc animated:YES];

}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {

    return 5;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    if(section == 2){
        return 2;
    }else{
        return 1;
    }
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if(section ==0){
        return @"设备名称";
    }else if(section ==1){
        return @"设备地址";
    }else if(section ==2){
        return @"负责人";
    }else if(section ==3){
        return @"设备分组";
    }else if(section ==4){
        return @"备注";
    }else{
        return @" ";
    }
}

//section底部间距
- (CGFloat)tableView:(UITableView* )tableView heightForFooterInSection:(NSInteger)section
{
    return 5;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if(indexPath.section == 1 && indexPath.row == 0){
    
        return 70;
    }

    return 50;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 1) {
        [tableView registerClass:[DeviceDetailCell_specific class] forCellReuseIdentifier:@"DeviceDetailCell_specific"];
        DeviceDetailCell_specific *cell = [tableView dequeueReusableCellWithIdentifier:@"DeviceDetailCell_specific" forIndexPath:indexPath];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [cell.leftLabel setText:deviceDetailModel.deviceAddress];
        
        
        
          return cell;
    }else{
        [tableView registerClass:[DeviceDetailCell class] forCellReuseIdentifier:@"deviceHeadCell"];
        DeviceDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:@"deviceHeadCell" forIndexPath:indexPath];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        if (indexPath.section == 0) {
            [cell.leftLabel setText:deviceDetailModel.deviceName];
        }else if(indexPath.section == 2){
            if (indexPath.row == 0) {
                [cell.leftLabel setText:deviceDetailModel.headName];
            }else{
                [cell.leftLabel setText:deviceDetailModel.headPhone];
            }
        }else if(indexPath.section == 3){
            [cell.leftLabel setText:deviceDetailModel.groupName];
        }else if(indexPath.section == 4){
            [cell.leftLabel setText:deviceDetailModel.intro];
        }
        
        return cell;
    }

}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//    if(indexPath.section ==3){
//        DeviceGroupVC *deviceGroupVC = [[DeviceGroupVC alloc]init];
//        [self presentViewController:deviceGroupVC animated:YES completion:nil];
//    }


}
@end
