//
//  TimePickerView.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/11.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^selectTimeBlock)(NSString *);
@interface TimePickerView : UIView<UIPickerViewDelegate,UIPickerViewDataSource>

@property (copy,nonatomic)selectTimeBlock selectblock;
- (instancetype)initWithFrame:(CGRect)frame andTimeReset:(NSString *)times AndSelectTime:(selectTimeBlock)selectTimeblock;
@end
