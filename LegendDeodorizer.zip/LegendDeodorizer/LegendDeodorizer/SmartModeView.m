//
//  SmartModeView.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/31.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "SmartModeView.h"
#import "DayChooseCell.h"
#import "HETPublicPickerView.h"
#import "SetDeviceModeRequest.h"
@implementation SmartModeView{
    UIControl *control;
    UIPickerView *selPartView;
    UITableView *smartTableView;
    NSMutableArray *selectArr;
    UILabel *workValueLab;
    
    NSMutableArray *currentPickArr;

}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/


- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self createUI];
        [self getDataModel];
    }
    return self;
}

-(void)createUI{
    smartTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, self.frame.size.height)];
    smartTableView.backgroundColor = [UIConfig colorFromHexRGB:@"fbfbfb"];
    smartTableView.delegate =self;
    smartTableView.dataSource = self;
    smartTableView.tableFooterView = [self createFootView];

    [smartTableView registerClass:[DayChooseCell class] forCellReuseIdentifier:@"cell"];

    smartTableView.bounces = NO;
    smartTableView.scrollEnabled = NO;

    [self addSubview:smartTableView];
}

-(UIView *)createFootView{
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, self.frame.size.height - 100)];
    view.backgroundColor = [UIColor clearColor];
    UIImageView *NH3ImgView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"NH3"]];
    NH3ImgView.center = CGPointMake(self.center.x, view.center.y-100);
    [view addSubview:NH3ImgView];
    
    workValueLab = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 40)];
    NSString *workVStr = [NSString stringWithFormat:@"氨气值达到%@开始工作",_smartModeDic.threshold];
    [workValueLab setText:workVStr];
    workValueLab.textAlignment = NSTextAlignmentCenter;
    workValueLab.font = [UIFont systemFontOfSize:16];
    workValueLab.center = CGPointMake(self.center.x, CGRectGetMaxY(NH3ImgView.frame)+35);
    [view addSubview:workValueLab];
    
    
    UILabel *describeLab = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 20)];
    [describeLab setText:@"氨气值立方米/毫克"];
    describeLab.textAlignment = NSTextAlignmentCenter;
    describeLab.font = [UIFont systemFontOfSize:12];
    describeLab.textColor = [UIConfig colorFromHexRGB:@"b2b2b2"];
    describeLab.center = CGPointMake(self.center.x, CGRectGetMaxY(workValueLab.frame)+15);
    [view addSubview:describeLab];
    
    UIButton *SettingBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth -100, 40)];
    [SettingBtn setTitle:@"配置阀值" forState:UIControlStateNormal];
    [SettingBtn setTintColor:WHITECOLOR];
    [SettingBtn setBackgroundImage:[UIImage imageNamed:@"cellBg"] forState:UIControlStateNormal];
    SettingBtn.center = CGPointMake(self.center.x, CGRectGetMaxY(describeLab.frame)+55);
    SettingBtn.layer.masksToBounds = YES;
    [SettingBtn addTarget:self action:@selector(openPickView:) forControlEvents:UIControlEventTouchUpInside];
    SettingBtn.layer.cornerRadius = 5;
    
    [view addSubview:SettingBtn];
    
    
    return view;

}

- (void)getDataModel{

    if (_smartModeDic) {
//        threshold = "1.35,1.05";
//        week = "1,2,3,4,5";
        NSString *weekStr = _smartModeDic.week;
//        NSString *threshold = _smartModeDic.threshold;
        
        NSMutableCharacterSet *set = [NSMutableCharacterSet characterSetWithCharactersInString:@","];
        NSArray *dataArray = [weekStr componentsSeparatedByCharactersInSet:set];
        if (dataArray.count>0) {
            NSMutableArray *daySelectArray = [[NSMutableArray alloc]init];
            for (NSInteger i=1; i<=7; i++) {
                [daySelectArray addObject:@NO];
                
            }
            for (NSString *s in dataArray) {
                NSInteger selectNum = s.integerValue;
                if (selectNum>0&&selectNum <8) {
                    [daySelectArray replaceObjectAtIndex:selectNum-1 withObject:@YES];
                }
            }
            DayChooseCell  *cell = (DayChooseCell *)[smartTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
            [cell setRetState:daySelectArray];
        }
        
        NSString *workVStr = [NSString stringWithFormat:@"氨气值达到%@开始工作",_smartModeDic.threshold];
        NSRange range = [workVStr rangeOfString:_smartModeDic.threshold];
        
        NSMutableAttributedString *workAttr = [[NSMutableAttributedString alloc] initWithString:workVStr];
        
        [workAttr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:
                                                          24] range:[workVStr rangeOfString:_smartModeDic.threshold ]];
        
        [workAttr addAttribute:NSForegroundColorAttributeName value:
         [UIConfig colorFromHexRGB:@"10c5b5"] range:[workVStr rangeOfString:_smartModeDic.threshold ]];


        workValueLab.attributedText = workAttr;

        

//        [workValueLab setText:workVStr];
        
    }

}

#pragma mark -----pickView的行选择之前的数据-----
-(void)selectBeforeDataRow{
    
    currentPickArr = [[NSMutableArray alloc]initWithCapacity:4];
    if (_smartModeDic) {
        //        threshold = "1.35,1.05";
        //        week = "1,2,3,4,5";
        //        NSString *weekStr = _smartModeDic.week;
        NSString *threshold = _smartModeDic.threshold;
        
        NSMutableCharacterSet *set = [NSMutableCharacterSet characterSetWithCharactersInString:@".,"];
        NSArray *dataArray = [threshold componentsSeparatedByCharactersInSet:set];
        currentPickArr = [dataArray mutableCopy];
        if (dataArray.count>0) {
            for (int i=0;i<4; i++) {
                NSInteger selectPart = [dataArray[i] integerValue];
                [selPartView selectRow:selectPart inComponent:i animated:YES];
                
            }
            
        }
    }
}

#pragma mark  --------  打开pickerView --------
-(void)openPickView:(id)sender{
//    HETPublicPickerView *view = [HETPublicPickerView viewWithTitle:@""];
//     NSLog(@"%@",self.smartModeDic);
//    @weakify(self);
//    
//    view.numberOfComponent = ^NSInteger{
//        
//        return 7;
//    };
//    
//    view.numberOfRowsInComponent =^NSInteger(NSInteger componentIndex){
//        @strongify(self);
//        return [@[@[@"0",@"1",@"2",@"3"],@[@"."],@[@"0",@"1",@"2",@"3"],@[@"至"],@[@"0",@"1",@"2",@"3"],@[@"."],@[@"0",@"1",@"2",@"3"]][componentIndex] count];
//        
//    };
//    view.titleForRowAndComponent =^NSString *(NSInteger componentIndex, NSInteger row){
//        @strongify(self);
////        return [self.viewModel sexContentArray][row];
//        return  @[@[@"0",@"1",@"2",@"3"],@[@"."],@[@"0",@"1",@"2",@"3"],@[@"至"],@[@"0",@"1",@"2",@"3"],@[@"."],@[@"0",@"1",@"2",@"3"]][componentIndex][row];
//    };
//    
////    [view defaultSelect:@[@([self.viewModel sexDefaultIndex])] animated:YES];
//    
//    [view showInView:self pickChanged:^(NSArray *indexArray) {
//        @strongify(self);
//       
////        [self.viewModel updateSex:[indexArray[0] integerValue]];
//    }];
    
    
    control=[[UIControl  alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
    control.backgroundColor=[UIColor colorWithRed:0 green:0 blue:0 alpha:0.4];
    [self.window  addSubview:control];
    [control  addTarget:self action:@selector(actionCancel:)   forControlEvents:UIControlEventTouchUpInside];
    
    //Toolbar
    UIToolbar  *toolbar=[[UIToolbar  alloc]  initWithFrame:CGRectMake(0,ScreenHeight*0.6,ScreenWidth,50)];
    toolbar.backgroundColor = WHITECOLOR;
    toolbar.autoresizingMask=UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleWidth;
    
    UIBarButtonItem *itemCancelDone=[[UIBarButtonItem alloc]initWithTitle:@"确定" style:UIBarButtonItemStylePlain  target:self action:@selector(actionConfirm:)];
    
    UIBarButtonItem  *itemCancel=[[UIBarButtonItem  alloc]initWithTitle:@"取消"  style:UIBarButtonItemStylePlain   target:self action:@selector(actionCancel:)];

    
    UIBarButtonItem  *space=[[UIBarButtonItem  alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace  target:nil action:nil];
    [toolbar setItems:[NSArray  arrayWithObjects:space,itemCancel,space,space,space,space,itemCancelDone,space,nil]];
    [control  addSubview:toolbar];
    
    selPartView=[[UIPickerView alloc]initWithFrame:CGRectMake(0, control.frame.size.height*0.6+50, ScreenWidth, ScreenHeight *0.4- 50)];
    selPartView.backgroundColor=[UIColor whiteColor];
    selPartView.delegate=self;
    selPartView.dataSource=self;
    
    NSMutableArray *Arr_10 = [[NSMutableArray alloc]initWithCapacity:10];
    NSMutableArray *Arr_100 = [[NSMutableArray alloc]initWithCapacity:100];
    for(int i=0;i<10;i++){
        [Arr_10 addObject:@(i)];
    
    }
    for(int i=0;i<100;i++){
        if (i<10) {
            [Arr_100 addObject:[NSString stringWithFormat:@"0%d",i]];
        }else{
            [Arr_100 addObject:[NSString stringWithFormat:@"%d",i]];
        }
    }
    selectArr=[[NSMutableArray alloc]initWithCapacity:4];
    [selectArr addObject:Arr_10];
    [selectArr addObject:Arr_100];
    [selectArr addObject:Arr_10];
    [selectArr addObject:Arr_100];
    
    
    //选中行的附属文字说明
    UIView *titleView = [[UIView alloc]initWithFrame:CGRectMake(0, selPartView.frame.size.height*0.43, ScreenWidth, 25)];
    //    titleView.backgroundColor = [UIColor lightGrayColor];
    //    titleView.layer.opacity =0.5;
    UILabel *diandian1 = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth*0.3, 0, 10, 25)];
    diandian1.text=@".";
    //    [diandian1 setBackgroundColor:[UIColor redColor]];
    diandian1.font = [UIFont systemFontOfSize:10];
    [titleView addSubview:diandian1];
    
    CGSize anaSize1=[@"m³mg" sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:10]}];
    UILabel *diandian2 = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth*0.42, 0, anaSize1.width, 25)];
    diandian2.text=@"m³mg";
    diandian2.font = [UIFont systemFontOfSize:10];
    //    [diandian2 setBackgroundColor:[UIColor redColor]];
    [titleView addSubview:diandian2];
    
    
    UILabel *diandian3 = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(diandian2.frame), 0, 10, 25)];
    diandian3.text=@"-";
    //    [diandian3 setBackgroundColor:[UIColor redColor]];
    [titleView addSubview:diandian3];
    
    UILabel *diandian4 = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth*0.7, 0, 10, 25)];
    diandian4.text=@".";
    //    [diandian4 setBackgroundColor:[UIColor redColor]];
    diandian4.font = [UIFont systemFontOfSize:10];
    [titleView addSubview:diandian4];
    
    
    UILabel *diandian5 = [[UILabel alloc]initWithFrame:CGRectMake(ScreenWidth*0.85, 0, anaSize1.width, 25)];
    diandian5.text=@"m³mg";
    diandian5.font = [UIFont systemFontOfSize:10];
    //    [diandian5 setBackgroundColor:[UIColor redColor]];
    [titleView addSubview:diandian5];
    
    
    [selPartView addSubview:titleView];
    [control addSubview:selPartView];
    
    //选择当前选中的数据行
    [self selectBeforeDataRow];



}



-(void)actionCancel:(id)sender
{
    [control removeFromSuperview];
    
}


#pragma mark  -----发送配置请求
-(void)actionConfirm:(id)sender{

    NSLog(@"%@",currentPickArr);//(1,39,6,48)
    
    //把选定的数组解析成特定形式发送 threshold = "1.35,1.05";
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"HH:mm"];
    NSString *startTimeStr = [NSString stringWithFormat:@"%02ld:%02ld",(long)[selPartView selectedRowInComponent:0],(long)[selPartView selectedRowInComponent:1]];
    
    NSString *endTimeStr = [NSString stringWithFormat:@"%02ld:%02ld",(long)[selPartView selectedRowInComponent:2],(long)[selPartView selectedRowInComponent:3]];
    
    NSDate *current_startTime= [dateFormatter dateFromString:startTimeStr ];
    
    NSDate *current_endTime = [dateFormatter dateFromString:endTimeStr ];
    
    if ([current_startTime compare:current_endTime]==NSOrderedAscending) {

        if (currentPickArr.count==4) {
            NSString *thresholdStr = [NSString stringWithFormat:@"%@.%@,%@.%@",currentPickArr[0],currentPickArr[1],currentPickArr[2],currentPickArr[3]];
            
            [self.delegate returnModeSetting:1 week:_smartModeDic.week  threshold:thresholdStr setList:nil];
            
        }
        
        [control removeFromSuperview];
    }else{
        
        [HelpMsg showMessage:@"开始时间大于结束时间,请重新选择!" inView:[[[UIApplication sharedApplication]delegate]window]];
        
    }

    
    



}

#pragma mark ------------UITableViewDelegate------------------
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}
#pragma weekCell的回调
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cell";
   
    DayChooseCell  *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
//    [cell setRetState:<#(NSArray *)#>];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if (indexPath.section == 0) {
        __weak typeof(self)Wself = self;
        cell.click =^(NSString *string){
            NSLog(@"------------------------%@",string);
            Wself.smartModeDic.week = string;
        };
        
        return cell;
    }else{
         return nil;
    }
   

}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return @"工作日期";
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView* myView = [[UIView alloc] init];
    myView.backgroundColor = [UIConfig colorFromHexRGB:@"fbfbfb"];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 90, 22)];
    titleLabel.textColor=[UIConfig colorFromHexRGB:@"848484"];
    titleLabel.backgroundColor = [UIColor clearColor];
    titleLabel.font = [UIFont systemFontOfSize:12];
    [titleLabel setText:@"工作日期"];
    [myView addSubview:titleLabel];
    return myView;
}

#pragma mark  ------------UIPickerViewDelegate,UIPickerViewDataSource------------
//点击
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    //    selectLab.text=[NSString stringWithFormat:@"%@",[selectArr[row] valueForKey:@"partName"]];
    //    selectPart=row;
    //        threshold = "1.35,1.05";
    //        week = "1,2,3,4,5";
//    NSString *threshold = _smartModeDic.threshold;
    if(selectArr.count>0 && currentPickArr.count>0){
        NSLog(@"didselect:%@",selectArr[component][row]);
        [currentPickArr replaceObjectAtIndex:component withObject:selectArr[component][row]];
    }

    
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    //    return 1;
    return selectArr.count;
}

- (NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    NSArray *arr =  selectArr[component];
    return arr.count;
}

//-(CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component{
//    CGFloat width;
//    if (component == 0 ||component == 6 ){
//        width = ScreenWidth *0.25;
//    }else if (component == 1 || component == 2 ||component == 3||component == 4 ||component == 5) {
//        width = ScreenWidth *0.1;
//    }
//
//    return width;
//}

//自定义指定列的每行的视图.
- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    UILabel* pickerLabel = (UILabel*)view;
    
    if (!pickerLabel){
        pickerLabel = [[UILabel alloc] init];
        pickerLabel.adjustsFontSizeToFitWidth = YES;
        [pickerLabel setTextAlignment:NSTextAlignmentRight];
        [pickerLabel setBackgroundColor:[UIColor clearColor]];
        [pickerLabel setTextColor:[UIConfig colorFromHexRGB:@"0dc7a5"]];
        [pickerLabel setFont:[UIFont boldSystemFontOfSize:18]];
    }
    if(component == 0){
        [pickerLabel setTextAlignment:NSTextAlignmentRight];
    }else if(component == 1){
        [pickerLabel setTextAlignment:NSTextAlignmentCenter];
    }else if(component == 2){
        [pickerLabel setTextAlignment:NSTextAlignmentCenter];
    }else if(component == 3){
        [pickerLabel setTextAlignment:NSTextAlignmentLeft];
    }
    // Fill the label text here
    pickerLabel.text=[self pickerView:pickerView titleForRow:row forComponent:component];
    return pickerLabel;
}

//显示的标题,选项名字
- (NSString *) pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    NSArray *arr =  selectArr[component];
    NSString *str = [NSString stringWithFormat:@"%@",arr[row]];
//    NSLog(@"Str:%@",str);
    return str;
    //    return [NSString stringWithFormat:@"%@",[selectArr[row] valueForKey:@"partName"]];
}

@end
