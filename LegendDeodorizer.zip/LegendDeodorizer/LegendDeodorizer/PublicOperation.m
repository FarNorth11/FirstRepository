//
//  PublicOperation.m
//  CSuperAppliances
//
//  Created by starlueng on 16/8/3.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "PublicOperation.h"
#import "JSObjection.h"

#import "HETPublicUIConfig.h"
#import "HETLoginProtocols.h"
#import "HETDeviceBindProtocol.h"
#import "HETPublicSceneProtocol.h"
#import "HETLoginCustomConfig.h"
#import <CoreBluetooth/CoreBluetooth.h>
#import "UINavigationController+FDFullscreenPopGesture.h"
#import "HETDeviceUnbindRequest.h"

NSString *const CSALoginOutShowAcountDefaults      = @"lastAccount";//设备登出后保存的帐号信息


@implementation PublicOperation
+ (instancetype)shareInstance{
    
    static PublicOperation *operation = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        operation = [[PublicOperation alloc]init];
    });
    return operation;
}

- (void)publicSet{
    
    AppDelegate *app =(AppDelegate *)[UIApplication sharedApplication].delegate;
    app.root.tabBar.hidden = YES;
    app.root.button.hidden = YES;

    /**
     *  第三方登录
     */
    [HETLoginCustomConfig socialButtonPosition:^NSArray *(id wechat, id weibo, id qq) {
        
        return @[wechat];
    }];
    [HETLoginCustomConfig bindPushNotification:^(void (^requestBlock)(void)) { }];
    [HETLoginCustomConfig registerAgreenmentProuductorName:@"传奇舟除臭器"];
    //pop返回界面有tabbar，此时做返回撤销操作要隐藏tabbar
    AppDelegate *appdelegate =(AppDelegate *)[UIApplication sharedApplication].delegate;
    [HETPublicUIConfig het_viewWillAppear:^(UIViewController *vc) {
        appdelegate.root.tabBar.hidden = YES;
        vc.view.backgroundColor =[UIConfig colorFromHexRGB:@"efeff4"];
        
    }];
    /**
     *  设置全局返回手势，以及导航栏的颜色
     *
     *  @param vc <#vc description#>
     *
     *  @return <#return value description#>
     */
    [HETPublicUIConfig het_viewDidLoad:^(UIViewController *vc) {
        [vc.navigationController.navigationBar setBarTintColor:[UIConfig colorFromHexRGB:@"4c91fc"] ];
        vc.fd_prefersNavigationBarHidden = NO;
    }];
    
    [HETPublicUIConfig het_viewInteractivePopDisabled:^(UIViewController<HETPublicVCProtocol> *vc) {
        vc.fd_interactivePopDisabled = YES;
    }];
    [HETPublicUIConfig shareConfig].color6 = [UIConfig colorFromHexRGB:@"4c91fc"];
    [HETPublicUIConfig shareConfig].color14 = [UIConfig colorFromHexRGB:@"4c91fc"];
    [HETPublicUIConfig shareConfig].color10 = [UIConfig colorFromHexRGB:@"4c91fc" alpha:1];

    
}
static  NSString  * const appstoreurl = @"http://itunes.apple.com/cn/lookup?id=1123394197";

- (BOOL)isExistNewVersion:(VersionBlock)block{

    //2先获取当前工程项目版本号
    NSDictionary *infoDic=[[NSBundle mainBundle] infoDictionary];
    NSString *currentVersion=[infoDic objectForKey:@"CFBundleShortVersionString"];
    
    //3从网络获取appStore版本号
    NSError *error;
    NSData *response = [NSURLConnection sendSynchronousRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:appstoreurl]] returningResponse:nil error:nil];
    if (response == nil) {
        NSLog(@"你没有连接网络哦");
        if (block) {
            block(@NO);
        }
        return NO;
    }
    NSDictionary *appInfoDic = [NSJSONSerialization JSONObjectWithData:response options:NSJSONReadingMutableLeaves error:&error];
    if (error) {
        NSLog(@"hsUpdateAppError:%@",error);
        if (block) {
            block(@NO);
        }
        
        return NO;
    }
    if (appInfoDic) {
        NSArray *array = [appInfoDic objectForKey:@"results"];
        if (array.count>0) {
            NSDictionary *dic = [array firstObject];
            NSString *appStoreVersion = [dic objectForKey:@"version"];
            //打印版本号
            NSLog(@"当前版本号:%@\n商店版本号:%@",currentVersion,appStoreVersion);
            //4当前版本号小于商店版本号,就更新
            if([appStoreVersion compare:currentVersion] == NSOrderedDescending)
            {
                if (block) {
                    block(dic);
                }
                
                return YES;
                
            }else{
                if (block) {
                    block(@NO);
                }
                
                return NO;
            }
        }else{
            if (block) {
                block(@NO);
            }
            return NO;

        }
        
    }else{
        if (block) {
            block(@NO);
        }
        return NO;
    }
    
}
-(void)login{

    UIApplication *app = [UIApplication sharedApplication];
    AppDelegate *appdelegate = (AppDelegate *)app.delegate;
     UINavigationController *nav = (UINavigationController *)appdelegate.root.selectedViewController;
    UIViewController <HETLoginProtocol>*con = [[JSObjection defaultInjector] getObject:@protocol(HETLoginProtocol)];
    con.canPopToBack = YES;

    

    [con setDefaultAccount:[[NSUserDefaults standardUserDefaults]objectForKey:CSALoginOutShowAcountDefaults]];
    
    if ( [[NSUserDefaults standardUserDefaults]objectForKey:CSALoginOutShowAcountDefaults]) {
        [[NSUserDefaults standardUserDefaults]setObject:[[NSUserDefaults standardUserDefaults]objectForKey:CSALoginOutShowAcountDefaults] forKey:CSALoginOutShowAcountDefaults];
        [[NSUserDefaults standardUserDefaults]synchronize];
    }
    @weakify(con);
    con.loginSuccess = ^{
        
        [[NSUserDefaults standardUserDefaults]setObject:[[HETUserInfo userInfo] userAccount] forKey:CSALoginOutShowAcountDefaults];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
               /**
         *  设备状态改变修改（登录登出，新添设备修改此项）
         *
         */
      
//        [CSAppUserSettings shareInstance].userAcountChange = YES;
        
        @strongify(con);
        [con.navigationController popToViewController:[nav.viewControllers firstObject] animated:NO];
        
    };
    
    [nav pushViewController:con animated:YES];
}
- (void)loginAndPopWith:(loginBlock)success{
    UIApplication *app = [UIApplication sharedApplication];
    AppDelegate *appdelegate =(AppDelegate *) app.delegate;
    UINavigationController *nav = (UINavigationController *)appdelegate.root.selectedViewController;
    UIViewController <HETLoginProtocol>*con = [[JSObjection defaultInjector] getObject:@protocol(HETLoginProtocol)];
    con.canPopToBack = YES;
     [con setDefaultAccount:[[NSUserDefaults standardUserDefaults]objectForKey:CSALoginOutShowAcountDefaults]];
    if ( [[NSUserDefaults standardUserDefaults]objectForKey:CSALoginOutShowAcountDefaults]) {
        [[NSUserDefaults standardUserDefaults]setObject:[[NSUserDefaults standardUserDefaults]objectForKey:CSALoginOutShowAcountDefaults] forKey:CSALoginOutShowAcountDefaults];
        [[NSUserDefaults standardUserDefaults]synchronize];
    }
    @weakify(con);

    con.loginSuccess = ^{
        success();
        
        [[NSUserDefaults standardUserDefaults]setObject:[[HETUserInfo userInfo] userAccount] forKey:CSALoginOutShowAcountDefaults];
        [[NSUserDefaults standardUserDefaults]synchronize];
 
        
        @strongify(con);
        [con.navigationController popViewControllerAnimated:YES];
        
    };
    
    [nav pushViewController:con animated:YES];
}

-(void)bind{
    
    UIApplication *app = [UIApplication sharedApplication];
    AppDelegate *appdelegate = (AppDelegate *)app.delegate;
    UINavigationController *nav = (UINavigationController *)appdelegate.root.selectedViewController;
    
    UIViewController <HETDeviceBindProtocol>*vc=[[JSObjection defaultInjector]getObject:@protocol(HETDeviceBindProtocol) named:@"HETDeviceBindWIFIModule"];
    vc.bindType = 1;
    HETDeviceObject *homeUseObj = [[HETDeviceObject alloc] init];
    homeUseObj.deviceSubtypeId =@"15";
    homeUseObj.deviceTypeId = @"7";
    homeUseObj.deviceIcon = @"DeviceIcon";
    homeUseObj.productId = 2134;
    homeUseObj.productName = @"除臭机";
   
    vc.wifiProtocolType = WIFIPROTOCOLTYPE_KF;
    vc.wifiBindFactory = WIFI_XLW_NL6621;
    vc.deviceTypeArray=[NSArray arrayWithObjects:homeUseObj,nil];//设备大类_设备小类
    @weakify(vc);
    vc.bindSuccess=^(NSDictionary *dict){
        @strongify(vc);
        [vc.navigationController popToViewController:[nav.viewControllers firstObject] animated:NO];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"kNotificationHasLogin" object:nil];
        
    };
    vc.bindFail=^{
        
    };
//    [HETPublicUIConfig het_viewDidLoad:^(UIViewController *vctemp){
//        vctemp.view.backgroundColor = [UIColor whiteColor];
//        vctemp.navigationController.navigationBarHidden=NO;
//        //        [vctemp.tabBarController.tabBar setHidden:YES];
//        //        vctemp.navigationController.navigationBar.translucent=NO;
//    }];
    vc.hidesBottomBarWhenPushed = YES;
    [nav pushViewController:vc animated:YES];

}
-(void)unbind:(NSString*)deviceId{
    HETDeviceUnbindRequest *unbindRequest = [[HETDeviceUnbindRequest alloc] initWithAccessToken:[HETUserInfo userInfo].accessToken deviceId:deviceId];
    [unbindRequest startWithSuccess:^{
        [HelpMsg showAlert:@"解绑成功" msg:nil duration:1.0];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"kNotificationHasLogin" object:nil];
        if (self.bindBlock) {
            self.bindBlock (@"success");
        }
        
        //        AppDelegate *appDeelgate=(AppDelegate *)[[UIApplication sharedApplication] delegate];
        //        MBProgressHUD *hud = [HelpMsg showCustomHudtitleTowindow:nil];
        //        [appDeelgate.leftView GetDeviceList:^{
        //            [hud hide:YES];
        //        } fail:^{
        //            [hud hide:YES];
        //        }];
    } failure:^(NSError *error, NSInteger statusCode) {
        NSLog(@"%@",error);
        if (error.code == 0) {
            [HelpMsg showMessage:@"当前网络不可用" inView:[[UIApplication sharedApplication].delegate window]];
        }
    }];
    
}

@end
