//
//  ManualModeView.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/31.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SmartModel.h"

@class ManualModeView;

@protocol returnModeSettingDelegate <NSObject>

@optional

- (void)returnModeSetting:(NSInteger)modeType week:(NSString *)week threshold:(NSString *) threshold setList:(NSArray *)setList;

@end

@interface ManualModeView : UIView<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,strong)SmartModel *manualModeDic;

@property(weak,nonatomic) id<returnModeSettingDelegate> delegate;

- (void)getDataModel;
@end
