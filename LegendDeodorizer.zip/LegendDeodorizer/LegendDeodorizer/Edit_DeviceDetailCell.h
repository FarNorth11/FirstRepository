//
//  Edit_DeviceDetailCell.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/9.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Edit_DeviceDetailCell : UITableViewCell<UITextFieldDelegate>

@property (nonatomic,strong) UITextField *leftTextField;

@end
