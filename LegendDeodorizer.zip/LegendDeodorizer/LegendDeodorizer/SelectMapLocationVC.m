//
//  SelectMapLocationVC.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/13.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "SelectMapLocationVC.h"
#import "KNLocationConverter.h"
#import "DeviceDetailController.h"
#import "SetDeviceLocationRequest.h"



@interface SelectMapLocationVC ()
{
    MKMapView *_mapView;
    UIView *_centerView;
    UIView *_footView;
    CLLocationManager *locationManager;
    CLLocation *location;
    
    CLLocationCoordinate2D currentPoint;

}

@end

@implementation SelectMapLocationVC


//- (UIStatusBarStyle )preferredStatusBarStyle{
//    return UIStatusBarStyleLightContent;
//}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _mapView =[[MKMapView alloc]initWithFrame:CGRectMake(0, 0 , ScreenWidth, ScreenHeight*0.6-64)];
    _mapView.zoomEnabled = YES;
    _mapView.showsUserLocation = YES;
    _mapView.scrollEnabled = YES;
    _mapView.delegate = self;
    [self.view addSubview:_mapView];
    
    
    
    CGSize titleSize = [UIConfig sizeWithString:@"定位" Font:[UIFont systemFontOfSize:17] maxSize:CGSizeMake(MAXFLOAT, MAXFLOAT)];
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(ScreenWidth_2-titleSize.width/2, 0, titleSize.width, NAVIBARHEIGHT)];
    titleLabel.text = @"定位";
    titleLabel.textColor = [UIColor blackColor];
    titleLabel.font = [UIFont systemFontOfSize:17];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    self.navigationItem.titleView = titleLabel;
    
    
    if([[UIDevice currentDevice].systemVersion floatValue] > 8.0f)
    {
        [self getUserLocation];
    }
    // 长按手势  长按添加大头针
    UILongPressGestureRecognizer *lpgr = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(lpgrClick:)];
    [_mapView addGestureRecognizer:lpgr];
    
    [self.view addSubview:[self createCenterView]];
    [self.view addSubview:[self createFootView]];
    
    
}

- (UIView *)createCenterView{
    _centerView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_mapView.frame), ScreenWidth, ScreenHeight*0.3)];
    _centerView.backgroundColor = [UIColor whiteColor];
    
    
    UILabel *content1 = [[UILabel alloc]initWithFrame:CGRectMake(20, 10, 50, 20)];
    content1.text =@"地址:";
    content1.font = [UIFont systemFontOfSize:14];
    content1.textColor = [UIConfig colorFromHexRGB:@"10c5b5"];
    [_centerView addSubview:content1];
    
    CGSize anaSize1=[@"随便" sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16]}];
    _addressLabel_Name = [[UILabel alloc]initWithFrame:CGRectMake(20, CGRectGetMaxY(content1.frame), ScreenWidth-50, anaSize1.height)];
    _addressLabel_Name.backgroundColor = [UIColor whiteColor];
    _addressLabel_Name.font = [UIFont systemFontOfSize:16];
    _addressLabel_Name.textAlignment = NSTextAlignmentLeft;
    [_centerView addSubview:_addressLabel_Name];
    
    
    _addressLabel_detailName= [[UILabel alloc]initWithFrame:CGRectMake(20, CGRectGetMaxY(_addressLabel_Name.frame), ScreenWidth-20, anaSize1.height)];
    _addressLabel_detailName.backgroundColor = [UIColor whiteColor];
    _addressLabel_detailName.font = [UIFont systemFontOfSize:16];
    _addressLabel_detailName.textAlignment = NSTextAlignmentLeft;
    [_centerView addSubview:_addressLabel_detailName];
    
    
    UILabel *content2 = [[UILabel alloc]initWithFrame:CGRectMake(20, CGRectGetMaxY(_addressLabel_detailName.frame)+20*NewBasicHeight, 70, 20)];
    content2.text =@"经纬度:";
    content2.font = [UIFont systemFontOfSize:14];
    content2.textColor = [UIConfig colorFromHexRGB:@"10c5b5"];
    [_centerView addSubview:content2];
    
    _longitudeLabel= [[UILabel alloc]initWithFrame:CGRectMake(20, CGRectGetMaxY(content2.frame), ScreenWidth-50, anaSize1.height)];
    _longitudeLabel.backgroundColor = [UIColor whiteColor];
    _longitudeLabel.font = [UIFont systemFontOfSize:16];
    _longitudeLabel.textAlignment = NSTextAlignmentLeft;
    [_centerView addSubview:_longitudeLabel];
    
    _latitudeLabel = [[UILabel alloc]initWithFrame:CGRectMake(20, CGRectGetMaxY(_longitudeLabel.frame), ScreenWidth-50, anaSize1.height)];
    _latitudeLabel.backgroundColor = [UIColor whiteColor];
    _latitudeLabel.font = [UIFont systemFontOfSize:16];
    _latitudeLabel.textAlignment = NSTextAlignmentLeft;
    [_centerView addSubview:_latitudeLabel];

    return _centerView;
}


- (UIView *)createFootView{
    _footView = [[UIView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_centerView.frame), ScreenWidth, ScreenHeight*0.1) ];
    _footView.backgroundColor = WHITECOLOR;
    
    //    footView.backgroundColor = [UIConfig colorFromHexRGB:@"fbfbfb"];
    //    UILabel *textLab = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 50, 150)];
    //    textLab.text = @"解除绑定";
    //    textLab.textColor = [UIColor redColor];
    //    textLab.font = [UIFont systemFontOfSize:15];
    //    textLab.center = footView.center;
    //    [footView addSubview:textLab];
    
    CALayer *lineLayer = [[CALayer alloc]init];
    lineLayer.frame = CGRectMake(0, SINGLE_LINE_WIDTH, ScreenWidth, SINGLE_LINE_WIDTH);
    lineLayer.backgroundColor = KCOLOR(@"c7c7c7").CGColor;
    [_footView.layer addSublayer:lineLayer];
    
    UIButton *unBindBtn = [[UIButton alloc]initWithFrame:CGRectMake(25, (ScreenHeight*0.1-40)/2, ScreenWidth-40, 40)];
    [unBindBtn setBackgroundImage:[UIImage imageNamed:@"homeCellBg"] forState:UIControlStateNormal];
    [unBindBtn setTitle:@"确认" forState:UIControlStateNormal];
    [unBindBtn setTitleColor:WHITECOLOR forState:UIControlStateNormal];
    [unBindBtn addTarget:self action:@selector(locationAction:) forControlEvents:UIControlEventTouchUpInside];
    [_footView addSubview:unBindBtn];
    return _footView;
    
}

#pragma mark  ----- 确定
-(void)locationAction:(id)sender{
    
    NSNumber *longitude = @(currentPoint.longitude);
    NSNumber *latitude = @(currentPoint.latitude) ;
    if(longitude!=0&&latitude!=0 &&self.identify!=nil){

        //(NSString * identify,NSString  *currentLoactionStr,NSNumber *deviceLongitude,NSNumber *deviceLatitude)
        //添加 字典，将label的值通过key值设置传递
        NSString *totalAdd = [NSString stringWithFormat:@"%@%@",self.addressLabel_detailName.text,self.addressLabel_Name.text];
        
        NSDictionary *dict =[[NSDictionary alloc]initWithObjectsAndKeys:self.identify,@"identify",totalAdd,@"currentLoactionStr",@(currentPoint.longitude), @"deviceLongitude",@(currentPoint.latitude),@"deviceLatitude",nil];
        
        //创建通知
        //通过通知中心发送通知
        [[NSNotificationCenter defaultCenter] postNotification:[NSNotification notificationWithName:@"editLocation" object:nil userInfo:dict]];
        

        for (id VC in self.navigationController.viewControllers) {
            if ([VC isKindOfClass:[DeviceDetailController class]]) {
                [self.navigationController popToViewController:VC animated:YES];
            }
        }
        
        
        
    }else{
    
        [HelpMsg showMessage:@"设置失败,请选择" inView:[[[UIApplication sharedApplication]delegate]window]];
    }
    


}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//获取当前位置
- (void)getUserLocation
{
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    //kCLLocationAccuracyBest:设备使用电池供电时候最高的精度
    locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters;
    locationManager.distanceFilter = 50.0f;
    if (([[[UIDevice currentDevice] systemVersion] doubleValue] >= 8.0))
    {
        [locationManager requestAlwaysAuthorization];
    }
    //更新位置
    [locationManager startUpdatingLocation];
}
#pragma mark-CLLocationManagerDelegate  位置更新后的回调
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    //停止位置更新
    [locationManager stopUpdatingLocation];
    
    CLLocation *loc = [locations firstObject];
    CLLocationCoordinate2D theCoordinate;
    //位置更新后的经纬度
    theCoordinate.latitude = loc.coordinate.latitude;
    theCoordinate.longitude = loc.coordinate.longitude;
    //设定显示范围
    MKCoordinateSpan theSpan;
    theSpan.latitudeDelta=0.01;
    theSpan.longitudeDelta=0.01;
    //设置地图显示的中心及范围
    MKCoordinateRegion theRegion;
    
    //坐标转换
    //这里获取的是WGS84坐标体系,也就是ios本身的定位
    //要转化成高德地图的GCJ02体系
    CLLocationCoordinate2D GCJCenter = [KNLocationConverter transformFromWGSToGCJ:theCoordinate];
    theRegion.center=GCJCenter;
    currentPoint = GCJCenter;
//    theRegion.center=theCoordinate;
    

    theRegion.span=theSpan;
    [_mapView setRegion:theRegion];
    location = [locations lastObject];

    
    //经度
    
    NSString *str1 = [self stringWithCoordinateString: [NSString stringWithFormat:@"%f",GCJCenter.longitude] islatitude:NO];
    _longitudeLabel.text = str1;
    //纬度
    
    NSString *str2 = [self stringWithCoordinateString: [NSString stringWithFormat:@"%f",GCJCenter.latitude] islatitude:YES];
    _latitudeLabel.text = str2;
    
//        CLGeocoder *geocoder = [[CLGeocoder alloc] init];
//    [geocoder reverseGeocodeLocation:location completionHandler:^(NSArray *array, NSError *error)
//     {
         CLGeocoder *geocoder = [[CLGeocoder alloc] init];
         [geocoder reverseGeocodeLocation:location completionHandler:^(NSArray *array, NSError *error) {
             
             if (array.count > 0)
             {
                 
                 CLPlacemark *placemark = [array objectAtIndex:0];
                 // 将获得的所有信息显示到label上
                 NSDictionary *location =[placemark addressDictionary];
                 NSLog(@"%@",placemark.administrativeArea);
                 // 获取城市
                 NSString *city = placemark.administrativeArea;
                 if (!city) {
                     // 四大直辖市的城市信息无法通过locality获得，只能通过获取省份的方法来获得（如果city为空，则可知为直辖市）
                     city = placemark.administrativeArea;
                 }
                 NSLog(@"当前城市:%@",city);
                 // 设置地图显示的类型及根据范围进行显示  安放大头针
                 MKPointAnnotation *pinAnnotation = [[MKPointAnnotation alloc] init];
//                 pinAnnotation.coordinate = theCoordinate;
                 pinAnnotation.coordinate = GCJCenter;
                 pinAnnotation.title = city;
                 [_mapView addAnnotation:pinAnnotation];
                 
                 
                 //地址信息
                 _addressLabel_Name.text =[NSString stringWithFormat:@"%@",placemark.name];
                 
                 _addressLabel_detailName.text  = [NSString stringWithFormat:@"%@%@%@%@",placemark.administrativeArea,placemark.locality,placemark.subLocality,placemark.thoroughfare];
             }
             else if (error == nil && [array count] == 0)
             {
                 NSLog(@"No results were returned.");
             }
             else if (error != nil)
             {
                 NSLog(@"An error occurred = %@", error);
             }
             
             
         }];
    
//     }];
}

// 每次添加大头针都会调用此方法  可以设置大头针的样式
- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    // 判断大头针位置是否在原点,如果是则不加大头针
    if([annotation isKindOfClass:[mapView.userLocation class]])
        return nil;
    static NSString *annotationName = @"annotation";
    MKPinAnnotationView *anView = (MKPinAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:annotationName];
    if(anView == nil)
    {
        anView = [[MKPinAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:annotationName];
    }
    anView.animatesDrop = YES;
    //    // 显示详细信息
    anView.canShowCallout = YES;
    //    anView.leftCalloutAccessoryView   可以设置左视图
    //    anView.rightCalloutAccessoryView   可以设置右视图
    return anView;
}

//长按添加大头针事件
- (void)lpgrClick:(UILongPressGestureRecognizer *)lpgr
{
    // 判断只在长按的起始点下落大头针
    if(lpgr.state == UIGestureRecognizerStateBegan)
    {
        [_mapView removeAnnotations:_mapView.annotations];
        // 首先获取点
        CGPoint point = [lpgr locationInView:_mapView];
        // 将一个点转化为经纬度坐标
        CLLocationCoordinate2D center = [_mapView convertPoint:point toCoordinateFromView:_mapView];
        MKPointAnnotation *pinAnnotation = [[MKPointAnnotation alloc] init];
        pinAnnotation.coordinate = center;
        pinAnnotation.title = @"长按";
        [_mapView addAnnotation:pinAnnotation];
        
        
        CLGeocoder *geocoder = [[CLGeocoder alloc]init];
        
        CLLocationCoordinate2D GCJCenter = [KNLocationConverter transformFromGCJToWGS:center];
        CLLocation *GCJlocation = [[CLLocation alloc]initWithLatitude:GCJCenter.latitude longitude:GCJCenter.longitude];
        __block NSString *name = nil;
        
        
        currentPoint = GCJCenter;
        //经度
//        _longitudeLabel.text = [NSString stringWithFormat:@"%2f",GCJCenter.longitude] ;
        
        NSString *str1 = [self stringWithCoordinateString: [NSString stringWithFormat:@"%f",GCJCenter.longitude] islatitude:NO];
        _longitudeLabel.text = str1;
        //纬度
//        _latitudeLabel.text = [NSString stringWithFormat:@"%2f",GCJCenter.latitude];
        
        NSString *str2 = [self stringWithCoordinateString: [NSString stringWithFormat:@"%f",GCJCenter.latitude] islatitude:YES];
        _latitudeLabel.text = str2;
        
        [geocoder reverseGeocodeLocation:GCJlocation completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
            for (CLPlacemark *place in placemarks) {
                NSDictionary *location =[place addressDictionary];
                NSLog(@"国家：%@",[location objectForKey:@"Country"]);
                NSLog(@"省：%@",[location objectForKey:@"State"]);
                NSLog(@"区：%@",[location objectForKey:@"SubLocality"]);
                NSLog(@"位置：%@", place.name);
                NSLog(@"国家：%@", place.country);
                NSLog(@"城市：%@", place.locality);
                NSLog(@"区：%@", place.subLocality);
                NSLog(@"街道：%@", place.thoroughfare);
                NSLog(@"子街道：%@", place.subThoroughfare);
                name = place.name;
                _addressLabel_Name.text =[NSString stringWithFormat:@"%@",place.name];
                
                _addressLabel_detailName.text  = [NSString stringWithFormat:@"%@%@%@%@",[location objectForKey:@"State"],place.locality,place.subLocality,place.thoroughfare];
//                LHAnnotation* annotation=[[LHAnnotation alloc]init];
//                
//                annotation.coordinate=CLLocationCoordinate2DMake(touchMapCoordinate.latitude, touchMapCoordinate.longitude);
//                
//                
//                annotation.title=name;
                
                //    annotation.subtitle=@"123";
                
                
            }
        }];
        
    }
}

//计算两个位置之间的距离
- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error{
    NSLog(@"%@",error);
}

//把小数形式的经纬度转换成度分秒  是否是纬度
- (NSString *)stringWithCoordinateString:(NSString *)coordinateString  islatitude:(BOOL)select
{
    /** 将经度或纬度整数部分提取出来 */
    int latNumber = [coordinateString intValue];
    
    /** 取出小数点后面两位(为转化成'分'做准备) */
    NSArray *array = [coordinateString componentsSeparatedByString:@"."];
    /** 小数点后面部分 */
    NSString *lastCompnetString = [array lastObject];
    
    /** 拼接字字符串(将字符串转化为0.xxxx形式) */
    NSString *str1 = [NSString stringWithFormat:@"0.%@", lastCompnetString];
    
    /** 将字符串转换成float类型以便计算 */
    float minuteNum = [str1 floatValue];
    
    /** 将小数点后数字转化为'分'(minuteNum * 60) */
    float minuteNum1 = minuteNum * 60;
    
    /** 将转化后的float类型转化为字符串类型 */
    NSString *latStr = [NSString stringWithFormat:@"%f", minuteNum1];
    
    /** 取整数部分即为纬度或经度'分' */
    int latMinute = [latStr intValue];
    
    //秒
    float second =  minuteNum1 - latMinute;
    float second1 = second *60;
    NSString *latStr_second = [NSString stringWithFormat:@"%f", second1];
    int latMinute_second = [latStr_second intValue];
    
    ///** 将经度或纬度字符串合并为(xx°xx')形式 */
    NSString *string=@"";
    if(select){
    //是纬度
        if(latNumber>0){
            //北纬
            string = [NSString stringWithFormat:@"北纬N%d°%d' %d\" ", latNumber, latMinute,latMinute_second];
        }else{
            //南纬
            string = [NSString stringWithFormat:@"南纬S%d°%d' %d\" ", latNumber, latMinute,latMinute_second];
        }
    }else{
    //是经度
        if(latNumber>0){
            //东经
            string = [NSString stringWithFormat:@"东经E%d°%d' %d\" ", latNumber, latMinute,latMinute_second];
        }else{
            //西经
            string = [NSString stringWithFormat:@"西经W%d°%d' %d\" ", latNumber, latMinute,latMinute_second];
        }
    
    }
    return string;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
