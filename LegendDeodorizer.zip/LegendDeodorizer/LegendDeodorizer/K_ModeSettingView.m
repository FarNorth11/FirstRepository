//
//  K_ModeSettingView.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/5/23.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "K_ModeSettingView.h"
#import "SmartModel.h"

@implementation K_ModeSettingView{
    SmartModel *smartModeDic;
    SmartModel *manualModeDic;
    
    UIScrollView *MyScrollView;
    UIButton *smartModeBtn;
    UIButton *manualModeBtn;
    
}



-(instancetype)initWithFrame:(CGRect)frame ModeDataArr:(NSMutableArray *)modeDataArr
{
    self = [super initWithFrame:frame];
    _modeDataArr = modeDataArr;
    if (self) {
        [self createMainView];
        [self getDataMode];
    }
    return self;
}


-(void)getDataMode{
    if (_modeDataArr.count>0) {
        NSDictionary *dic0 = _modeDataArr[0];
        NSDictionary *dic1 = _modeDataArr[1];
        if (!smartModeDic) {
            smartModeDic = [[SmartModel alloc]init];
            
        }
        if (!manualModeDic) {
            manualModeDic= [[SmartModel alloc]init];
            
        }
        
        [smartModeDic setValuesForKeysWithDictionary:dic0];
        [manualModeDic setValuesForKeysWithDictionary:dic1];
        //        smartModeDic = [[NSMutableDictionary alloc]initWithDictionary:_modeDataArr[0]];
        _smartModeView.smartModeDic = smartModeDic;
        //        manualModeDic = [[NSMutableDictionary alloc]initWithDictionary:_modeDataArr[1]];
        _manualModeView.manualModeDic = manualModeDic;
        
    }
}


-(void)createMainView{
    //顶上两个按钮
    UIView *topBarView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 64)];
    topBarView.backgroundColor = WHITECOLOR;
    [self addSubview:topBarView];
    
    
    smartModeBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth/2, topBarView.frame.size.height)];
    smartModeBtn.tag = 1;
    [smartModeBtn setBackgroundImage:[UIImage imageNamed:@"cellBg"] forState:UIControlStateSelected];
    smartModeBtn.selected = YES;
    [smartModeBtn setTitle:@"智能模式" forState:UIControlStateNormal];
    [smartModeBtn setTitleColor:[UIConfig colorFromHexRGB:@"c7c7c7"] forState:UIControlStateNormal];
    [smartModeBtn setTitleColor:WHITECOLOR forState:UIControlStateSelected];
//    [smartModeBtn addTarget:self action:@selector(BatClick:) forControlEvents:UIControlEventTouchUpInside];
    [topBarView addSubview:smartModeBtn];
    
    manualModeBtn = [[UIButton alloc]initWithFrame:CGRectMake(ScreenWidth/2, 0, ScreenWidth/2, topBarView.frame.size.height)];
    manualModeBtn.tag = 2;
    [manualModeBtn setBackgroundImage:[UIImage imageNamed:@"cellBg"] forState:UIControlStateSelected];
    manualModeBtn.selected = 0;
    [manualModeBtn setTitle:@"手动模式" forState:UIControlStateNormal];
    [manualModeBtn setTitleColor:[UIConfig colorFromHexRGB:@"c7c7c7"] forState:UIControlStateNormal];
    [manualModeBtn setTitleColor:WHITECOLOR forState:UIControlStateSelected];
    [manualModeBtn addTarget:self action:@selector(BatClick:) forControlEvents:UIControlEventTouchUpInside];
    [topBarView addSubview:manualModeBtn];
    
    //下面的scrollView
    MyScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(topBarView.frame), ScreenWidth, self.frame.size.height - topBarView.frame.size.height)];
    MyScrollView.delegate = self;
    MyScrollView.backgroundColor = [UIConfig colorFromHexRGB:@"fbfbfb"];
    // 隐藏水平滚动条
    MyScrollView.showsHorizontalScrollIndicator = NO;
    MyScrollView.showsVerticalScrollIndicator = NO;
    MyScrollView.pagingEnabled = YES;
    MyScrollView.bounces = NO;
    [self addSubview:MyScrollView];
    
//    _smartModeView = [[SmartModeView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, MyScrollView.frame.size.height)];
//    _smartModeView.backgroundColor = [UIColor whiteColor];
//    _smartModeView.smartModeDic = smartModeDic;
//    _smartModeView.delegate = self;
//    [MyScrollView addSubview:_smartModeView];
    
    _smartModeView = [self createSmartView];
    [MyScrollView addSubview:_smartModeView];
    
    
    
    //    manualModeView = [[ManualModeView alloc]initWithFrame:CGRectMake(ScreenWidth, 0, ScreenWidth, MyScrollView.frame.size.height)];
    _manualModeView = [[ManualModeView alloc]init];
    _manualModeView.manualModeDic = manualModeDic;
    _manualModeView.frame =  CGRectMake(ScreenWidth, 0, ScreenWidth, MyScrollView.frame.size.height);
    _manualModeView.backgroundColor = [UIColor whiteColor];
    _manualModeView.delegate = self;
    
    [MyScrollView addSubview:_manualModeView];
    // 设置UIScrollView的滚动范围（内容大小）
    MyScrollView.contentSize = CGSizeMake(ScreenWidth*2, 0);
    
}


#pragma mark  ----UIScrollView------
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    
    NSLog(@"%@",scrollView);
    if(scrollView.contentOffset.x==0){
        //智能模式
        manualModeBtn.selected = NO;
        smartModeBtn.selected = YES;
        
    }else if(scrollView.contentOffset.x==ScreenWidth){
        //手动模式
        manualModeBtn.selected = YES;
        smartModeBtn.selected = NO;
        
    }
    _manualModeView.manualModeDic = manualModeDic;
    _smartModeView.smartModeDic = smartModeDic;
}


-(UIView *)createSmartView{
//    _smartModeView = [[SmartModeView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, MyScrollView.frame.size.height)];
//    _smartModeView.backgroundColor = [UIColor whiteColor];
//    _smartModeView.smartModeDic = smartModeDic;
//    _smartModeView.delegate = self;
    UIView *smartView;
    return smartView;
}


@end
