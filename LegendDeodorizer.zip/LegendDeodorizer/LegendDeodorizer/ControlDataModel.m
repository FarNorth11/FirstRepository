    //
//  ControlDataModel.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/8.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "ControlDataModel.h"
#import <objc/runtime.h>
#import "NSDictionary+SAMAdditions.h"


@implementation ControlDataModel

-(void)SetRunData:(NSDictionary *)RundataDic{
    unsigned int propertyCount = 0;
    objc_property_t *properties = class_copyPropertyList([self class], &propertyCount);
    for (unsigned int i = 0; i < propertyCount; i++) {
        objc_property_t property = properties[i];
        //获取成员的名称
        NSString *propertyName = [[NSString alloc] initWithCString:property_getName(property) encoding:NSUTF8StringEncoding];
        
        //获取成员内容的Ivar
        Ivar iVar = class_getInstanceVariable([self class], [propertyName UTF8String]);
        //其实上面那行获取代码是为了保险起见，基本是获取不到内容的。因为成员的名称默认会在前面加"_" ，
        if (iVar == nil) {
            iVar = class_getInstanceVariable([self class], [[NSString stringWithFormat:@"_%@",propertyName] UTF8String]);
        }
        
        NSString *valueStr ;
        if ([[RundataDic allKeys] containsObject:propertyName]) {
            valueStr  = [NSString stringWithFormat:@"%@",[RundataDic objectForKey:propertyName]];
        }
        else{
            valueStr = nil;
        }
        object_setIvar(self, iVar, valueStr);
    }
}


-(instancetype)initWithData:(NSDictionary *)dic{
    self = [super init];
    if (self) {

        //sam_safeObjectForKey是为了回避出现nil的情况,是SAMCategarys中带的类,会把NULL替换成nil
        self.deviceId = [dic sam_safeObjectForKey:@"deviceId"];
        
        self.power = [[dic sam_safeObjectForKey:@"power"] integerValue];
        self.Atomizerchannel = [[dic sam_safeObjectForKey:@"Atomizerchannel"] integerValue];
        self.Airlevel = [[dic sam_safeObjectForKey:@"Airlevel"]integerValue];
        self.concentration = [[dic sam_safeObjectForKey:@"concentration"] integerValue];
        self.sound = [[dic sam_safeObjectForKey:@"sound"]integerValue ];
        self.mode = [[dic sam_safeObjectForKey:@"mode"] integerValue];
        self.wash = [[dic sam_safeObjectForKey:@"wash"] integerValue];
        self.QueryTiming = [[dic sam_safeObjectForKey:@"QueryTiming"] integerValue];
        self.AddLiquid = [[dic sam_safeObjectForKey:@"AddLiquid"] integerValue];
        
        
        
        
        
        
        
    }
    return self;
}

-(NSInteger)changeModel:(NSInteger)currentModel  withMax:(NSInteger) max{
    if (currentModel<max) {
        currentModel +=1;
    }else{
        currentModel =1;
    }
    return currentModel;
}

@end
