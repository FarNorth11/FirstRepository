//
//  temp.h
//  SmartHome
//
//  Created by luojie on 14-10-20.
//  Copyright (c) 2014年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface MessageView : UILabel

-(id)initWithText:(NSString *)text;

-(void)hideView:(NSNumber *)flag;
@end

