//
//  K_ModeSettingView.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/5/23.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SmartModeView.h"
#import "ManualModeView.h"

typedef void (^ returnModeSetting)(NSInteger modeType,NSString *week,NSString *threshold,NSArray * setList);


@interface K_ModeSettingView : UIView<UIScrollViewDelegate>

-(instancetype)initWithFrame:(CGRect)frame ModeDataArr:(NSMutableArray *)modeDataArr;

@property(nonatomic,strong)SmartModeView *smartModeView;
@property(nonatomic,strong)ManualModeView *manualModeView;
@property (nonatomic, copy) returnModeSetting   block;
@property(nonatomic,strong)NSMutableArray *modeDataArr;
-(void)getDataMode;


@end
