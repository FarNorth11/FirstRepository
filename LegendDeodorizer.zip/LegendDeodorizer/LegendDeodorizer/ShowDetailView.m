//
//  ShowDetailView.m
//  LegendDeodorizer
//
//  Created by Starlueng on 2017/3/31.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "ShowDetailView.h"


@implementation ShowDetailView
{
    
}
@synthesize detailLabel;
-(instancetype)initWithFrame:(CGRect)frame Item:(NSString *)item detail:(SetListModel *)detail TapAction:(tapBlock)tapblock
{
    self = [super initWithFrame:frame];
    if (self) {
        self.block = tapblock;
        UILabel *itemLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 16, frame.size.width, 14)];
        itemLabel.text = item;
        itemLabel.textColor = [UIConfig colorFromHexRGB:@"848484"];
        itemLabel.font = KFONT(12);
        [self addSubview:itemLabel];
        
        detailLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(itemLabel.frame)+6, frame.size.width, 26)];
        detailLabel.font = [UIFont boldSystemFontOfSize:15];
        detailLabel.textColor = [UIConfig colorFromHexRGB:@"424242"];
//        detailLabel.text = [NSString stringWithFormat:@"%@分钟",detail.];
        [self addSubview:detailLabel];
        
        detailLabel.userInteractionEnabled = YES;
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapACtion:)];
        [detailLabel addGestureRecognizer:tap];
    }
    return self;
}
- (void)setIsHightSelect:(BOOL)isHightSelect{
    
    if (isHightSelect) {
        detailLabel.textColor = [UIConfig colorFromHexRGB:@"0dc7a5"];

    }else{
        detailLabel.textColor = [UIConfig colorFromHexRGB:@"424242"];

    }
}

- (void)tapACtion:(UITapGestureRecognizer *)sender{
    UILabel *label = (UILabel *)sender.view;
    if (self.block) {
        self.block(label.text);
    }
}
@end
