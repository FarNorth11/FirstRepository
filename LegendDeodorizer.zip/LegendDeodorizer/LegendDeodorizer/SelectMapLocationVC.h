//
//  SelectMapLocationVC.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/13.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>
#import "RootViewController.h"

//typedef void (^ReturnDeviceLoaction)(NSString * identify,NSString  *currentLoactionStr,NSNumber *deviceLongitude,NSNumber *deviceLatitude);

@interface SelectMapLocationVC : RootViewController<MKMapViewDelegate,CLLocationManagerDelegate>


@property (nonatomic) CLLocationCoordinate2D coordinate;
//@property (nonatomic, copy) ReturnDeviceLoaction   block;
//@property (nonatomic, copy) NSString *title;
//@property (nonatomic, copy) NSString *subtitle;

@property(nonatomic,strong) NSString *identify;//设备ID;
@property (copy, nonatomic)  UILabel *addressLabel_Name;
@property (copy, nonatomic)  UILabel *addressLabel_detailName;
@property (copy, nonatomic)  UILabel *longitudeLabel;//经度
@property (copy, nonatomic)  UILabel *latitudeLabel;//纬度
//@property (copy, nonatomic)  UILabel *distanceLabel;

@end
