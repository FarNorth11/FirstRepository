//
//  GetDeviceLocationRequest.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/5.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "HETRequest.h"

@interface GetDeviceLocationRequest : HETRequest

- (instancetype)initWithAccessToken: (NSString *)accessToken mac:(NSString *)mac;

- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock;
@end
