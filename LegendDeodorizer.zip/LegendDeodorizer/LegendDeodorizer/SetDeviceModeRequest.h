//
//  SetDeviceModeRequest.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/5.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "HETRequest.h"

@interface SetDeviceModeRequest : HETRequest

- (instancetype)initWithAccessToken: (NSString *)accessToken appType:(NSInteger)appType mac:(NSString *)mac modeType:(NSInteger )modeType week:(NSString *)week  threshold:(NSString *)threshold setList:(NSString *)setList;

- (void)startWithSuccess:(HETHttpSuccessBlockDictionaryParameter)successBlock
                 failure:(HETHttpFailureBlock)failureBlock;

@end
