//
//  HTNavigationController.h
//  SmartHome
//
//  Created by Sandy wu on 14-7-4.
//  Copyright (c) 2014年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HTNavigationController : UINavigationController
//- (void)setTabbarItemWithColor:(UIColor *)color AndSelectColor:(UIColor *)selectColor AndTitle:(NSString *)title AndImage:(NSString *)image AndSelctImage:(NSString *)selectImage;
@end
