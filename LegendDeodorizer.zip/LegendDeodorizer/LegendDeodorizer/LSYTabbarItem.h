//
//  LSYTabbarItem.h
//  Common_Refrigerator
//
//  Created by starlueng on 16/1/9.
//  Copyright © 2016年 starlueng. All rights reserved.
//
/**
 *  tabbarItem各个控件的tag
 */
typedef NS_ENUM(NSInteger,tabbarItemTag) {
    /**
     *  智能
     */
    materialItem  =100001,
    /**
     *  发现
     */
    healthItem    =100002,
    /**
     *  我的
     */
    commondItem   =100003,

};
typedef void (^sendBlock) (id);

#import <UIKit/UIKit.h>
@interface LSYTabbarItem : UIView
/**
 *  背景图
 */
@property (nonatomic,strong) UIImageView *BackImageView;

@property (copy,nonatomic) sendBlock myBlock;

- (instancetype)initWithTitles:(NSArray *)titleArray AndImageArray:(NSArray *)imageArray AndSelectArray:(NSArray *)selectArray AndTitleFont:(UIFont *)font AndTitleColor:(UIColor *)color AndSelectColor:(UIColor *)selectColor AndFrame:(CGRect)frame;
@end
