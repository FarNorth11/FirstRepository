//
//  CommonHead.h
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/27.
//  Copyright © 2017年 Het. All rights reserved.
//

#ifndef CommonHead_h
#define CommonHead_h

#define IS_iPhone5 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) : NO)
#define SYSTEM_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)     ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)

#endif /* CommonHead_h */


#define isiPhone6 (([[UIScreen mainScreen] bounds].size.width>320)&&([[UIScreen mainScreen] bounds].size.width<=375))
#define isiPhone6Plus (([[UIScreen mainScreen] bounds].size.width>375)&&([[UIScreen mainScreen] bounds].size.width<=414))

#define isiPhone5 ([[UIScreen mainScreen] bounds].size.height == 568)
#define isiPhone4 ([[UIScreen mainScreen] bounds].size.height <568)

#define  iPhone4Weight 320.0
#define  iPhone4Height 480.0

#define  iPhone5Weight 320.0
#define  iPhone5Height 568.0

#define  iPhone6Weight 375.0
#define  iPhone6Height 667.0

#define  iPhone6PWeight 414.0
#define  iPhone6PHeight 736.0

//获取设备的物理高度
#define ScreenHeight [UIScreen mainScreen].bounds.size.height
//获取设备的物理宽度
#define ScreenWidth [UIScreen mainScreen].bounds.size.width
//获取设备的中心X
#define ScreenWidth_2 ScreenWidth/2
//获取设备的中心Y
#define ScreenHeight_2 ScreenHeight/2

#define DeviceRunXml @"0005.xml"
#define DeviceCfgXml @"0007.xml"
//状态栏高度
#define STATUSBARHEIGHT 20
//导航栏高度
#define NAVIBARHEIGHT 44

#define TABBARHEIGHT 49

#define KFONT(o) [UIFont systemFontOfSize:o]

#define KCOLOR(o) [UIConfig colorFromHexRGB:o]

#define cellSelectColor [UIColor colorWithRed:209/255.0 green:209/255.0 blue:209/255.0 alpha:0.4]

#define  iphone5BasicHeight   (1/iPhone5Height*(isiPhone4?iPhone5Height:ScreenHeight))
#define  iphone5BasicWeight   (1/iPhone5Weight*ScreenWidth)

#define  NewBasicHeight (1/iPhone6Height*(isiPhone6?iPhone6Height:ScreenHeight))
#define  NewBasicWidth (1/iPhone6Weight*ScreenWidth)

#define  BasicHeight  (1/iPhone5Height*(isiPhone4?iPhone5Height:ScreenHeight))
#define  BasicWidth  (1/iPhone5Weight*ScreenWidth)

#define SINGLE_LINE_WIDTH (1 / [UIScreen mainScreen].scale)
#define SINGLE_LINE_ADJUST_OFFSET   ((1 / [UIScreen mainScreen].scale) / 2)

#define IOS7 SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")

#define IOS8 SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"8.0")

#define SmartDeviceTypeTotal    23

#define ServerAPPID 30596   //服务器上的APPID
#define SharePort @"cms.clife.cn"  //分享port

#define CURRENT_LANGUAGE_IS_CHINESE ([[[NSLocale preferredLanguages] objectAtIndex:0] isEqualToString:@"zh-Hans"]||[[[NSLocale preferredLanguages] objectAtIndex:0] isEqualToString:@"zh-Hant"])

#define TrailOfView(view) (view.frame.origin.x+view.frame.size.width)
#define BottomOfView(view) (view.frame.origin.y+view.frame.size.height)


#define WEAKSELF typeof(self) __weak weakSelf = self;
#define STRONGSELF typeof(weakSelf) __strong strongSelf = weakSelf;

#define WHITECOLOR [UIConfig colorFromHexRGB:@"ffffff"]

#define NULLNUMBER @"null"       //不存在的
#define SAFE_STRING(str) (![str isKindOfClass: [NSString class]] ? @"" : str)
#define SAFE_NUMBER(value) (![value isKindOfClass: [NSNumber class]] ? @(-1) : value)

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "UIConfig.h"
#import "HTNavigationController.h"
#import "AppDelegate.h"
#import "UIButton+EXtern.h"
#import "UILabel+EXtern.h"
#import "RACEXTScope.h"
#import "HETSDK.h"
#import "HelpMsg.h"
#import "MessageView.h"

