//
//  MineController.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/27.
//  Copyright © 2017年 Het. All rights reserved.
//

static const NSInteger moreTag           =2;//右侧按钮tag
static const NSInteger backTag           =5;//右侧按钮tag
static const NSInteger  loginOutTag    =100;//登出按钮
#import "MineController.h"
#import "UINavigationController+FDFullscreenPopGesture.h"
#import "SetTableCell.h"
#import "AboutController.h"
#import "UIImageView+WebCache.h"
#import "JSObjection.h"
#import "HETLoginProtocols.h"
#import "HETLoginCustomConfig.h"
#import "HETPublicUIConfig.h"
#import "BaseAlert.h"
#import "HelpMsg.h"
#import "HETUserDefaultsPreference.h"
#import "HETSettingManager.h"
#import "PublicOperation.h"
#import "HETFeedbackOpinionViewController.h"
#import "FeedListViewController.h"
#import "FeedbackViewController.h"

@interface MineController ()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong) UITableView *setTableView;

@property (nonatomic,strong) UIImageView *topView;

@end

@implementation MineController{
    UIImageView *iconImageView;//头像
    UILabel *nameLabel;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.fd_prefersNavigationBarHidden = YES;
    [self.view addSubview:self.setTableView];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    AppDelegate *app =(AppDelegate *)[UIApplication sharedApplication].delegate;
    app.root.tabBar.hidden = NO;
    app.root.button.hidden = NO;
    [self createNaviView];
    [self UpdateHeadView];
    /*
    if (![HETUserInfo userInfo].isLogin) {

    }else{

    }
    */
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark-=====================click====================
- (void)buttonClick:(id)sender{
    if ([sender isKindOfClass:[UIButton class]]) {
        UIButton *button = (UIButton *)sender;
        switch (button.tag) {
            case moreTag:
            {
//                SettingController *setting =[[SettingController alloc]init];
//                //                self.hidesBottomBarWhenPushed = YES;
//                [self.navigationController pushViewController:setting animated:YES];
            }
                break;
            case loginOutTag:
            {
                
                if ([HETUserInfo userInfo].isLogin==YES) {
                    
                    [[BaseAlert shareInstance]alertWithAlertStyle:AlertStyleAlert title:NSLocalizedString(@"退出当前账号", nil) message:NSLocalizedString(@"您确定要退出当前账户吗?", nil) cancelBtnTitle:NSLocalizedString(@"取消", nil) buttonList:@[NSLocalizedString(@"确认退出", nil)] AndSelectButtonAction:^(NSNumber *num) {
                        if ([num integerValue]==1) {
                            AppDelegate *app =(AppDelegate *)[UIApplication sharedApplication].delegate;
                            
                            CATransition *transition = [CATransition animation];
                            
                            transition.duration = 0.3f;
                            
                            transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
                            
                            transition.type = kCATransitionPush;
                            
                            transition.subtype = kCATransitionFromLeft;
                            
                            // transition.delegate = self;
                            
                            [self.view.superview.layer addAnimation:transition forKey:nil];
                            [self clearData];
                            [self UpdateHeadView];
                            @weakify(self);
                            [CATransaction setCompletionBlock:^{
                                @strongify(self);
                                
//                                [self.navigationController popToRootViewControllerAnimated:NO];
//                                app.root.selectedIndex = 0;
                                
                            }];
//                            [[NSNotificationCenter defaultCenter] postNotificationName:@"kNotificationHasLogin" object:nil];
                            [HelpMsg showMessage:@"退出成功" inView:app.window];
                        }
                        
                    }];
                    
                }

            }
                break;
            case backTag:
            {
                AppDelegate *app =(AppDelegate *)[UIApplication sharedApplication].delegate;
                app.root.tabBar.hidden = NO;
                app.root.button.hidden = NO;
                app.root.selectedIndex =0;
            }
                break;
                
            default:{

            }
                break;
                
        }
        
    }else if ([sender isKindOfClass:[UITapGestureRecognizer class]]){
        
        if ([HETUserInfo userInfo].isLogin) {
            [HETPublicUIConfig het_viewDidLoad:^(UIViewController *vc) {
                [vc.navigationController.navigationBar setBarTintColor:[UIConfig colorFromHexRGB:@"4c91fc"] ];
                vc.fd_prefersNavigationBarHidden = NO;
            }];
             [self.navigationController pushViewController:[[UIStoryboard storyboardWithName:@"HETUserInfoInformation" bundle:nil] instantiateViewControllerWithIdentifier:@"HETUserInfoListConroller"] animated:YES];
        }else{
            PublicOperation *publicOp = [PublicOperation shareInstance];
            [publicOp publicSet];
            
            [publicOp loginAndPopWith:^{
                [[NSNotificationCenter defaultCenter] postNotificationName: @"addLoginNotification" object: nil userInfo:nil];

            }];
        
        
        }
        
    }


}

-(void)clearData{
    [[HETUserDefaultsPreference sharedInstance] clearData];
    [HETUserInfo logout];
    [HETUserInfo userInfo].accessToken = @"";
    [_setTableView reloadData];

}

#pragma mark-=====================UI====================
- (void)createNaviView{
    
    UIButton *leftBtn =[UIButton setButtonWithNomalImage:[UIImage imageNamed:@"arrow_back"] AndSelectImage:[UIImage imageNamed:@"arrow_back"] AndFrame:CGRectMake(0, STATUSBARHEIGHT, 60, NAVIBARHEIGHT)];
    
    leftBtn.imageEdgeInsets =UIEdgeInsetsMake(0, 0, 0, 0);
    leftBtn.tag = backTag;
    [leftBtn addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:leftBtn];
    
    UILabel *label =[UILabel setLabelWith:@"我的" AndFont:[UIFont systemFontOfSize:18] AndIsNumberOfLines:NO AndtextColor:WHITECOLOR AndFrame:CGRectMake((ScreenWidth-100)/2, STATUSBARHEIGHT, 100, NAVIBARHEIGHT) AndAlignment:NSTextAlignmentCenter];
    [self.view addSubview:label];
}

- (UIView* )createBottomView{
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 70)];
    
//    CALayer *lineLayer = [[CALayer alloc]init];
//    lineLayer.frame = CGRectMake(0, 31, ScreenWidth, SINGLE_LINE_WIDTH);
//    lineLayer.backgroundColor = KCOLOR(@"c7c7c7").CGColor;
//    [view.layer addSublayer:lineLayer];

    UIButton *logoutBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 50)];
    [logoutBtn setTitle:@"退出登录" forState:UIControlStateNormal];
    [logoutBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    logoutBtn.backgroundColor =[UIColor whiteColor];
    logoutBtn.tag = loginOutTag;
    [logoutBtn addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:logoutBtn];
    return view;
}

- (UITableView *)setTableView{
    if (!_setTableView) {
        _setTableView =[[UITableView alloc]initWithFrame:CGRectMake(0, -STATUSBARHEIGHT, ScreenWidth, ScreenHeight+STATUSBARHEIGHT) style:UITableViewStyleGrouped];
        _setTableView.backgroundColor =[UIConfig colorFromHexRGB:@"efeff4"];
        _setTableView.delegate =self;
        _setTableView.dataSource = self;
        _setTableView.tableHeaderView = [self createHeadView];
//        [_setTableView registerClass:[SetTableCell class] forCellReuseIdentifier:@"cell"];
        /**
         清除多余线
         */
        UIView *footView =[[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, SINGLE_LINE_WIDTH)];
        footView.backgroundColor =[UIConfig colorFromHexRGB:@"c7c8cc"];
        _setTableView.tableFooterView = footView;//   [self createBottomView];
        _setTableView.scrollEnabled = NO;
    }
    return _setTableView;
}

-(UIView *)createHeadView{
    UIView *headview = [[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 320 *NewBasicHeight)];
    headview.backgroundColor = [UIColor whiteColor];
//    headview.layer.borderColor = [UIConfig colorFromHexRGB:@"c7c7c7"].CGColor;
//    headview.layer.borderWidth = SINGLE_LINE_WIDTH;
    [headview addSubview:self.topView];
    
    return headview;
}

/**
 *  刷新头部视图，用户头像和名称
 */
- (void)UpdateHeadView{
    
    if ([HETUserInfo userInfo].isLogin) {
        
        [iconImageView sd_setImageWithURL:[NSURL URLWithString:[HETUserInfo userInfo].avatar] placeholderImage:[UIImage imageNamed:@"logins"]  completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
            
        }];
        nameLabel.text =[HETUserInfo userInfo].userName;
        _setTableView.tableFooterView =[self createBottomView];
    }else{
        
        iconImageView.image =[UIImage imageNamed:@"icon_head"];
        nameLabel.text =@"未登录";
        UIView *footView =[[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, SINGLE_LINE_WIDTH)];
//        footView.backgroundColor =[UIConfig colorFromHexRGB:@"c7c8cc"];
        footView.backgroundColor = [UIColor clearColor];
        _setTableView.tableFooterView =footView;
    }
    
}

- (UIImageView *)topView{
    if (!_topView) {
        _topView =[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, 300 *NewBasicHeight)];
        
        _topView.image =[UIImage imageNamed:@"min_bg"];
        _topView.userInteractionEnabled = YES;

        
        UIView *backView = [[UIView alloc]initWithFrame:CGRectMake((ScreenWidth-110 *NewBasicHeight-4)/2, 110 *NewBasicHeight, 110*NewBasicHeight +4, 110*NewBasicHeight +4)];
        backView.layer.cornerRadius =2 +55 *NewBasicHeight;
        backView.layer.masksToBounds = YES;
        backView.backgroundColor = [UIConfig colorFromHexRGB:@"ffffff" alpha:0.5];
        [_topView addSubview:backView];
        
        iconImageView =[[UIImageView alloc]initWithFrame:CGRectMake(2, 2, 110 *NewBasicHeight, 110 *NewBasicHeight)];
//        iconImageView.image = [UIImage imageNamed:@"icon_head"];
        
        [backView addSubview:iconImageView];
        iconImageView.userInteractionEnabled = YES;
        iconImageView.layer.cornerRadius =55 *NewBasicHeight;
        iconImageView.layer.masksToBounds = YES;
        
        
        
        if (![HETUserInfo userInfo].isLogin) {
            iconImageView.image =[UIImage imageNamed:@"icon_head"];
            _topView.image =[UIImage imageNamed:@"min_bg"];
        }else{
            if ([[HETUserInfo userInfo].avatar hasPrefix:@"http"]) {
                [iconImageView sd_setImageWithURL:[NSURL URLWithString:[HETUserInfo userInfo].avatar] placeholderImage:[UIImage imageNamed:@"logins"]  completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                    
                }];
                
            }else{
                iconImageView.image =[UIImage imageNamed:@"icon_head"];
            }
        }
        UITapGestureRecognizer *tap =[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(buttonClick:)];
        [iconImageView addGestureRecognizer:tap];
        
        nameLabel =[UILabel setLabelWith:@"" AndFont:[UIFont systemFontOfSize:14] AndIsNumberOfLines:YES AndtextColor:WHITECOLOR AndFrame:CGRectMake(0, CGRectGetMaxY(backView.frame)+12 *NewBasicHeight, ScreenWidth, 15) AndAlignment:NSTextAlignmentCenter];
        nameLabel.text=@"未登录";
        [_topView addSubview:nameLabel];
    }
    return _topView;
}
#pragma mark-=====================UITableViewDelegate====================
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UIApplication *app = [UIApplication sharedApplication];
    AppDelegate *appdelegate =(AppDelegate*) app.delegate;
    UINavigationController *nav = (UINavigationController *)appdelegate.root.selectedViewController;
   //将所有vc的导航栏 标题 置为白色
    nav.navigationBar.titleTextAttributes =[NSDictionary dictionaryWithObject:WHITECOLOR forKey:NSForegroundColorAttributeName];
    [nav.navigationController.navigationBar setBarTintColor:[UIConfig colorFromHexRGB:@"4c91fc"] ];
    [HETPublicUIConfig het_viewDidLoad:^(UIViewController *vc) {
        [vc.navigationController.navigationBar setBarTintColor:[UIConfig colorFromHexRGB:@"4c91fc"] ];
        vc.fd_prefersNavigationBarHidden = NO;
    }];
    HETSettingManager <HETSettingProtocol>*con = [[JSObjection defaultInjector] getObject:@protocol(HETSettingProtocol)];
    
    con.backBtnClick =^{
        [self.navigationController popViewControllerAnimated:YES];
    };

    if ([HETUserInfo userInfo].isLogin) {
        if (indexPath.row==0) {
            UIViewController *Account= [con setSettingType:SettingAccountSecurity];
            
            [nav pushViewController:Account animated:YES];
        }else if(indexPath.row ==2){
            AboutController *about = [[AboutController alloc]init];
            [self.navigationController pushViewController:about animated:YES];
        }else if(indexPath.row == 1){
            HETFeedbackOpinionViewController *feedback = [HETFeedbackOpinionViewController new];
            feedback.backBtnClick = ^(){
                [self.navigationController popViewControllerAnimated:true];
            };
            [self.navigationController pushViewController:feedback animated:YES];
            
            /*
      
            UIApplication *app = [UIApplication sharedApplication];
            AppDelegate *appdelegate =(AppDelegate *) app.delegate;
            UINavigationController *nav = (UINavigationController *)appdelegate.root.selectedViewController;
            //将所有vc的导航栏标题置为白色
            nav.navigationBar.titleTextAttributes =[NSDictionary dictionaryWithObject:[UIColor blackColor] forKey:NSForegroundColorAttributeName];
            //                HETSettingManager <HETSettingProtocol>*con = [[JSObjection defaultInjector] getObject:@protocol(HETSettingProtocol)];
            //                con.backBtnClick =^{
            //                    [self.navigationController popViewControllerAnimated:YES];
            //                };
            //[con setSettingType:SettingFeedbackOpinion];
//            if (0) {
//                FeedListViewController *Feedback  = [[FeedListViewController alloc]init];
//                [nav pushViewController:Feedback animated:YES];
//            }else{
                //                    FeedDetailViewController *Feedback= [[FeedDetailViewController alloc]init];
                FeedbackViewController *Feedback = [[FeedbackViewController alloc]init];
                [nav pushViewController:Feedback animated:YES];
//            }
             
             */

            
        }
    }else{
    
    
    }
    

}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    SetTableCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    NSArray *titleArray =@[@"账户安全",@"反馈",@"关于传奇舟"];
    if (cell == nil) {
        cell = [[SetTableCell alloc]initWithStyle:UITableViewCellStyleDefault  reuseIdentifier:@"cell"];
    
    }
    if(indexPath.row ==0){
        CALayer *lineLayer = [[CALayer alloc]init];
        lineLayer.frame = CGRectMake(0, cell.frame.origin.y, ScreenWidth, SINGLE_LINE_WIDTH);
        [cell.contentView.layer addSublayer:lineLayer];
        lineLayer.backgroundColor = KCOLOR(@"c7c7c7").CGColor;

    }
    cell.accessoryType =UITableViewCellAccessoryDisclosureIndicator;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    [cell setcellFrameWith:NO AndRadius:NO AndShowNotice:NO];
    for (NSInteger i=0; i<titleArray.count; i++) {
        if (indexPath.row==i) {
            cell.midLabel.text =titleArray[i];
        }
        
    }
    return cell;

}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
        return 3;

}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}
@end
