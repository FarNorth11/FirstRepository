//
//  RootTabBarViewController.m
//  Common_Refrigerator
//
//  Created by starlueng on 16/1/9.
//  Copyright © 2016年 starlueng. All rights reserved.
//

#import "RootTabBarViewController.h"
#import "HomepageController.h"
#import "MineController.h"
#import "FindController.h"
#import "ModeSettingController.h"
#import "PublicOperation.h"

@interface RootTabBarViewController ()

@end

@implementation RootTabBarViewController
{
    NSInteger slectNum;//当前选中的item
    NSArray *titleArray;//标题数组
}

@synthesize button;
- (void)viewDidLoad {
    [super viewDidLoad];
    slectNum =1;
//    /**
//     *  隐藏系统TabbarItem
//     */
//    [self hiddenTabbarItems];
    /**
     *  添加子视图
     */
    [self addRootViewControllers];
    //      UITabBarControllerDelegate 指定为自己
    self.delegate =self;
    //  添加突出按钮
    [self addCenterButtonWithImage:[UIImage imageNamed:@"addDevice_on"] selectedImage:[UIImage imageNamed:@"addDevice_on"]];


}
- (void)hiddenTabbarItems{
    for (UIView *view in self.view.subviews) {
        if ([view isKindOfClass:[UITabBar class]]) {
            view.hidden =YES;
        }
    }
}
- (void)addRootViewControllers{
    HTNavigationController *HomepagedNavi =[[HTNavigationController alloc]initWithRootViewController:[[HomepageController alloc] init]];
    
    HTNavigationController *modeSet =[[HTNavigationController alloc]initWithRootViewController:[[HomepageController alloc] init]];
    
    HTNavigationController *MaterialNavi =[[HTNavigationController alloc]initWithRootViewController:[[MineController alloc] init]];
    
    self.viewControllers =@[HomepagedNavi,modeSet,MaterialNavi];
    
    self.selectedIndex =0;
    
    HomepagedNavi.tabBarItem = [[UITabBarItem alloc]initWithTitle:@"首页" image:[UIImage imageNamed: @"shouye_off"] selectedImage:[UIImage imageNamed:@"shouye_on"]];
    modeSet.tabBarItem = [[UITabBarItem alloc]initWithTitle:@"添加设备" image:[UIImage imageNamed: @""] selectedImage:[UIImage imageNamed:@""]];
    
    MaterialNavi.tabBarItem =[[UITabBarItem alloc]initWithTitle:@"我的" image:[UIImage imageNamed: @"me_off"] selectedImage:[UIImage imageNamed:@"me_on"]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark- TabBar Delegate

//  换页和button的状态关联上

- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController
{
    if (self.selectedIndex==2) {
//        button.selected=YES;
    }else
    {
//        button.selected=NO;
    }
}

#pragma mark - addCenterButton
// Create a custom UIButton and add it to the center of our tab bar
-(void) addCenterButtonWithImage:(UIImage*)buttonImage selectedImage:(UIImage*)selectedImage
{
    
    
    
    UIView *lineLayer = [[UIView alloc]init];
    lineLayer.frame = CGRectMake(0, 0, ScreenWidth, SINGLE_LINE_WIDTH);
    lineLayer.backgroundColor = KCOLOR(@"c7c7c7");
    [self.tabBar addSubview:lineLayer];
    
    
    
    button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button addTarget:self action:@selector(pressChange:) forControlEvents:UIControlEventTouchUpInside];
    button.autoresizingMask = UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleTopMargin;
    
    //  设定button大小为适应图片
    button.frame = CGRectMake(0.0, 0.0, buttonImage.size.width, buttonImage.size.height+30);
    [button setImage:buttonImage forState:UIControlStateNormal];
    [button setImage:selectedImage forState:UIControlStateSelected];

    //  这个比较恶心  去掉选中button时候的阴影
    button.adjustsImageWhenHighlighted=NO;
    
    
    
    /*
     *  核心代码：设置button的center 和 tabBar的 center 做对齐操作， 同时做出相对的上浮
     */

    CGPoint center = self.tabBar.center;
//    center.y = 2*center.y-ScreenHeight;
    button.center = CGPointMake(self.tabBar.center.x, 0);
    
    
    [self.tabBar addSubview:button];
    
    
    //去掉tabBar顶部线条
    
//    CGRect rect = CGRectMake(0, 0, ScreenWidth, ScreenHeight);
//    
//    UIGraphicsBeginImageContext(rect.size);
//    
//    CGContextRef context = UIGraphicsGetCurrentContext();
//    
//    CGContextSetFillColorWithColor(context, [[UIColor clearColor] CGColor]);
//    
//    CGContextFillRect(context, rect);
//    
//    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
//    
//    UIGraphicsEndImageContext();
//    
//    [self.tabBar setBackgroundImage:img];
//    
//    [self.tabBar setShadowImage:img];
    
    [self.tabBar setBackgroundImage:[UIImage new]];
    
    [self.tabBar setShadowImage:[UIImage new]];
    
    [self.tabBar setBackgroundColor:[UIColor whiteColor]];
//    [self.view addSubview:button];
}

-(void)pressChange:(id)sender
{
//    self.selectedIndex=1;
//    button.selected=YES;
    
    PublicOperation  *publicOp = [PublicOperation shareInstance];
    [publicOp publicSet];
    if ([HETUserInfo userInfo].isLogin) {
        
        [publicOp bind];
       
    }else{
        [publicOp publicSet];
        [publicOp loginAndPopWith:^{
            [[NSNotificationCenter defaultCenter] postNotificationName: @"addLoginNotification" object: nil userInfo:nil];
        }];
        
//        [HelpMsg showMessage:@"请登录" inView:[[UIApplication sharedApplication].delegate window]];
        
    }
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
