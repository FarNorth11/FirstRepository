//
//  LSYTabbarItem.m
//  Common_Refrigerator
//
//  Created by starlueng on 16/1/9.
//  Copyright © 2016年 starlueng. All rights reserved.
//
/**
 *  图片高度和宽度值
 */
static const NSInteger imageHight =20;
#import "LSYTabbarItem.h"

@implementation LSYTabbarItem

- (instancetype)initWithTitles:(NSArray *)titleArray AndImageArray:(NSArray *)imageArray AndSelectArray:(NSArray *)selectArray AndTitleFont:(UIFont *)font AndTitleColor:(UIColor *)color AndSelectColor:(UIColor *)selectColor AndFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        /**
         *  创建界面
         */
        _BackImageView =[[UIImageView alloc]initWithFrame:CGRectMake(-1, 0, frame.size.width+2, frame.size.height)];
        _BackImageView.backgroundColor =[UIConfig colorFromHexRGB:@"f7f7f8"];
        _BackImageView.layer.borderWidth =SINGLE_LINE_WIDTH;
        _BackImageView.layer.borderColor =[UIConfig colorFromHexRGB:@"c7c8cc"].CGColor;
        _BackImageView.userInteractionEnabled = YES;
        [self addSubview:_BackImageView];
        /**
         *  创建Items控件
         */
        assert(imageArray.count==selectArray.count);
        assert(imageArray.count==titleArray.count);
        for (u_int i=0; i<imageArray.count; i++) {
            UIButton * button = [UIButton buttonWithType:UIButtonTypeCustom];
            [button setTitle:titleArray[i] forState:UIControlStateNormal];
            [button setImage:[UIImage imageNamed:imageArray[i]] forState:UIControlStateNormal];
            [button setImage:[UIImage imageNamed:selectArray[i]] forState:UIControlStateSelected];
            [button setTitleColor:color forState:UIControlStateNormal];
            [button setTitleColor:selectColor forState:UIControlStateSelected];
            button.titleLabel.font = font;
            button.tag =materialItem+i;
            
            CGFloat width = frame.size.width/imageArray.count;
            CGFloat hight = frame.size.height;
            button.frame = CGRectMake(width *i, 0, width, hight);
            button.imageEdgeInsets =UIEdgeInsetsMake(5, (width-imageHight)/2, hight-5-imageHight, (width-imageHight)/2);
            button.titleEdgeInsets =UIEdgeInsetsMake(hight-5-imageHight, -27, 5, 0);
            [button addTarget:self action:@selector(changeView:) forControlEvents:UIControlEventTouchUpInside];
            [self addSubview:button];
            button.selected = NO;
        }
        UIButton *button = (UIButton *)[self viewWithTag:materialItem];
        button.selected = YES;
    }
    return self;
    
}
#pragma mark-=======button事件传递==================
- (void)changeView:(UIButton *)sender{
    if (self.myBlock) {
        self.myBlock(sender);
    }
}
@end
