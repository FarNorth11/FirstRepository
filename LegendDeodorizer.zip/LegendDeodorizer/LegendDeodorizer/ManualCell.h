//
//  ManualCell.h
//  LegendDeodorizer
//
//  Created by Starlueng on 2017/3/31.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SetListModel.h"
typedef void (^switchBlock)(id);
typedef void (^timeSetBlock)(NSString *);
typedef void (^settimeBlock)(SetListModel *);
@interface ManualCell : UITableViewCell

@property (copy,nonatomic)switchBlock switchblock;

@property (copy,nonatomic) timeSetBlock timeBlock;

@property (copy,nonatomic) settimeBlock settimeBlock;

- (void)setManualCellData:(SetListModel *)setListModel;
@end
