//
//  DayChooseCell.h
//  LegendDeodorizer
//
//  Created by Starlueng on 2017/3/31.
//  Copyright © 2017年 Het. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^clickBlock)(NSString *);
@interface DayChooseCell : UITableViewCell
//设置选中状态
- (void)setRetState:(NSArray *)selects;
@property (copy,nonatomic)clickBlock click;
@end
