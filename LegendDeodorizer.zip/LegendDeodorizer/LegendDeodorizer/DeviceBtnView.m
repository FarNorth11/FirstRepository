//
//  DeviceBtnView.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/3/29.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "DeviceBtnView.h"

@implementation DeviceBtnView


- (instancetype)initWithFrame:(CGRect)frame withTitle:(NSString *)title imageStr:(NSString *)imageStr
{
    self = [super initWithFrame:frame];
    if (self) {
        _btn=[UIButton buttonWithType:UIButtonTypeCustom];
        _btn.frame = self.bounds;
        [_btn setImage:[UIImage imageNamed:imageStr] forState:UIControlStateNormal];
//        [btn setTitle:title forState:UIControlStateNormal];
        CGFloat height = self.frame.size.height;
        CGFloat width = self.frame.size.width;
        _btn.imageEdgeInsets = UIEdgeInsetsMake((height-75)/2, (width -55)/2, (height -35)/2, (width -55)/2);
//        btn.titleEdgeInsets = UIEdgeInsetsMake((height +64)/2, -60, 0, 0);
        [_btn addTarget:self action:@selector(clickBtn:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_btn];
        
        _label = [[UILabel alloc]initWithFrame:CGRectMake(0, 60, width, 50)];
        _label.textAlignment = NSTextAlignmentCenter;
        _label.text = title;
        _label.font = [UIFont systemFontOfSize:13];
        _label.textColor = [UIColor blackColor];
        [self addSubview:_label];
        
    }
    return self;
}


-(void) clickBtn:(id)btnClick{
    NSLog(@"btn,%@",btnClick);



}

@end
