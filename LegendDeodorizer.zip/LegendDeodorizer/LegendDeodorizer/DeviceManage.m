//
//  DeviceManage.m
//  LegendDeodorizer
//
//  Created by Ben on 2017/4/6.
//  Copyright © 2017年 Het. All rights reserved.
//

#import "DeviceManage.h"
#import "GetGroupListRequest.h"
#import "GroupListModel.h"
#import "GetGroupDeviceListRequest.h"

@implementation DeviceManage{
    HETDeviceListGet     deviceListGetSuccess;
    HETDeviceConfigSet   configSetSuccess;
    HETDeviceError       resultError;
    HETDeviceListByGroup deviceListByGroup;
    NSString    *myHost;

}


+(DeviceManage *)sharedInstance{
    static DeviceManage * userDevicesConfig = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        userDevicesConfig = [[DeviceManage alloc] init];
    });
    return userDevicesConfig;
}


- (instancetype)init{
    self = [super init];
    if (self) {
//        DeviceTypeModel *typeModel = [[DeviceTypeModel alloc] init];
//        typeModel.DeviceMainType = 8;
//        typeModel.DeviceSubType = 23;
//        self.SupportDeviceType = [NSArray arrayWithObjects:typeModel, nil];
    }
    return self;
}


-(void)getDeviceGroupListRequsetSuccess:(void (^)())groupList fail:(void (^)(NSError *, NSInteger))error{
    if (![HETUserInfo userInfo].isLogin) {
        return ;
    }
    resultError = error;
    GetGroupListRequest *getGroupList = [[GetGroupListRequest alloc]initWithAccessToken:[HETUserInfo userInfo].accessToken pageIndex:@(1) pageRows:@(20)];
    self.myDeviceGroupList = [[NSMutableArray alloc]initWithCapacity:8];
    [getGroupList startWithSuccessBlockDictionaryParameter:^(NSDictionary *dictValue) {
        if (dictValue!=nil ) {
            NSArray *groupArr = [dictValue objectForKey:@"list"];
            for (int i=0; i<groupArr.count; i++) {
                [self.myDeviceGroupList  addObject:[[GroupListModel alloc]initWithData:groupArr[i]]];
            }
        }
        NSLog(@"成功");
    } failure:^(NSError *error, NSInteger statusCode) {
        NSLog(@"失败");
        NSLog(@"%@  %d",error,(int)statusCode);
        resultError(error,statusCode);
        if (error.code == 0) {
            [HelpMsg showMessage:@"当前网络不可用" inView:[[UIApplication sharedApplication].delegate window]];
        }
    }];



}

/**
 *  获取设备列表
 *
 *  @param deviceList 设备列表
 *  @param error      出错信息
 */
- (void)getDeviceBindRequestSuccess:(void(^)())deviceList fail:(void(^)(NSError *error, NSInteger statusCode))error{
    if (![HETUserInfo userInfo].isLogin) {
        return ;
    }
    deviceListGetSuccess = deviceList;
    resultError = error;
//    HETDeviceGetBindRequest * getBind = [[HETDeviceGetBindRequest alloc] initWithAccessToken:[HETUserInfo userInfo].accessToken familyId:0 houseId:0 roomId:0];
//    [getBind startWithSuccess:^(NSArray *arrayValue) {
//        NSLog(@"设备列表:%@",arrayValue);
//        [self.myDeviceList removeAllObjects];
//        //过滤设备，只加入当前APP指定的设备类型
//        for (NSDictionary * device in arrayValue) {
//            NSUInteger deviceTypeId = [[device objectForKey:@"deviceTypeId"] intValue];
//            NSUInteger deviceSubTypeId = [[device objectForKey:@"deviceSubtypeId"] intValue];
//            if ([self CheckSupportWithDeviceMainType:deviceTypeId SubType:deviceSubTypeId]) {
//                DeviceModel *model = [[DeviceModel alloc] initWithData:device];
//                if (model.onlineStatus == OnLine) {
//                    [self.myDeviceList insertObject:model atIndex:0];
//                }else{
//                    [self.myDeviceList addObject:model];
//                }
//            }
//        }
//        [self FindLitterRoopDevice]; //该app 不走小循环
//        
//    } failure:^(NSError *error, NSInteger statusCode) {
//        NSLog(@"%@  %d",error,(int)statusCode);
//        resultError(error,statusCode);
//    }];
}


-(void)getDevicelistByGroupGid:(NSInteger)gid Success:(void (^)(NSMutableArray *))deviceList fail:(void (^)(NSError *, NSInteger))error{
    if (![HETUserInfo userInfo].isLogin) {
        return ;
    }
    deviceListByGroup = deviceList;
    resultError = error;
    GetGroupDeviceListRequest *getDevicelistByGroup = [[GetGroupDeviceListRequest  alloc]initWithAccessToken:[HETUserInfo userInfo].accessToken gid:gid pageIndex:@(1) pageRows:@(20)];
    [getDevicelistByGroup startWithSuccess:^(NSDictionary *dictValue) {
        if ( [[dictValue objectForKey:@"list"] isKindOfClass:[NSArray class]]) {
            NSMutableArray *deviceListArr = [NSMutableArray arrayWithArray:[dictValue objectForKey:@"list"]];
            
            deviceListByGroup(deviceListArr);
        }else{
            NSMutableArray *deviceListArr = [[NSMutableArray alloc]init];
             deviceListByGroup(deviceListArr);
        
        }
        
    } failure:^(NSError *error, NSInteger statusCode) {
        NSLog(@"%@  %d",error,(int)statusCode);
        resultError(error,statusCode);
        if (error.code == 0) {
            [HelpMsg showMessage:@"当前网络不可用" inView:[[UIApplication sharedApplication].delegate window]];
        }
    }];
    



}
@end
